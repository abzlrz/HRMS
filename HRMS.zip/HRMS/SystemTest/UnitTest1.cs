﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace SystemTest
{
    [TestClass]
    public class Recruitment
    {
        [TestMethod]
        public void TestMethod1()
        {
        }
    }
}
