﻿using System.Windows.Forms;

namespace Presentation.Maintenance
{
    public partial class UserManager : Form
    {
        public UserManager()
        {
            InitializeComponent();
        }
    }
}
