﻿using System.Windows.Forms;
using Presentation.DialogBox;

namespace Presentation.Modules
{
    public partial class ControlInterviewEvaluation : UserControl
    {
        public ControlInterviewEvaluation()
        {
            InitializeComponent();
        }

        private void OnEvaluateToolStripMenuItemClick(object sender, System.EventArgs e)
        {
            
        }
    }
}
