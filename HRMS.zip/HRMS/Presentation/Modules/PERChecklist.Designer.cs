﻿namespace Presentation.Modules
{
    partial class PERChecklist
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.button1 = new System.Windows.Forms.Button();
            this.btnRegister = new System.Windows.Forms.Button();
            this.tableLayoutPanel3 = new System.Windows.Forms.TableLayoutPanel();
            this.checkAll2 = new System.Windows.Forms.CheckBox();
            this.linkLabel21 = new System.Windows.Forms.LinkLabel();
            this.checkBox38 = new System.Windows.Forms.CheckBox();
            this.checkBox37 = new System.Windows.Forms.CheckBox();
            this.checkBox36 = new System.Windows.Forms.CheckBox();
            this.checkBox35 = new System.Windows.Forms.CheckBox();
            this.checkBox34 = new System.Windows.Forms.CheckBox();
            this.checkBox33 = new System.Windows.Forms.CheckBox();
            this.checkBox32 = new System.Windows.Forms.CheckBox();
            this.checkBox31 = new System.Windows.Forms.CheckBox();
            this.checkBox30 = new System.Windows.Forms.CheckBox();
            this.checkBox29 = new System.Windows.Forms.CheckBox();
            this.checkBox28 = new System.Windows.Forms.CheckBox();
            this.checkBox27 = new System.Windows.Forms.CheckBox();
            this.checkBox26 = new System.Windows.Forms.CheckBox();
            this.checkBox25 = new System.Windows.Forms.CheckBox();
            this.checkBox24 = new System.Windows.Forms.CheckBox();
            this.checkBox23 = new System.Windows.Forms.CheckBox();
            this.checkBox22 = new System.Windows.Forms.CheckBox();
            this.checkBox21 = new System.Windows.Forms.CheckBox();
            this.label84 = new System.Windows.Forms.Label();
            this.label59 = new System.Windows.Forms.Label();
            this.linkLabel38 = new System.Windows.Forms.LinkLabel();
            this.linkLabel37 = new System.Windows.Forms.LinkLabel();
            this.linkLabel36 = new System.Windows.Forms.LinkLabel();
            this.linkLabel35 = new System.Windows.Forms.LinkLabel();
            this.linkLabel34 = new System.Windows.Forms.LinkLabel();
            this.linkLabel33 = new System.Windows.Forms.LinkLabel();
            this.linkLabel32 = new System.Windows.Forms.LinkLabel();
            this.linkLabel31 = new System.Windows.Forms.LinkLabel();
            this.linkLabel30 = new System.Windows.Forms.LinkLabel();
            this.linkLabel29 = new System.Windows.Forms.LinkLabel();
            this.linkLabel28 = new System.Windows.Forms.LinkLabel();
            this.linkLabel27 = new System.Windows.Forms.LinkLabel();
            this.linkLabel26 = new System.Windows.Forms.LinkLabel();
            this.linkLabel25 = new System.Windows.Forms.LinkLabel();
            this.linkLabel24 = new System.Windows.Forms.LinkLabel();
            this.linkLabel23 = new System.Windows.Forms.LinkLabel();
            this.label60 = new System.Windows.Forms.Label();
            this.label61 = new System.Windows.Forms.Label();
            this.label62 = new System.Windows.Forms.Label();
            this.label63 = new System.Windows.Forms.Label();
            this.label64 = new System.Windows.Forms.Label();
            this.label65 = new System.Windows.Forms.Label();
            this.label66 = new System.Windows.Forms.Label();
            this.label67 = new System.Windows.Forms.Label();
            this.label68 = new System.Windows.Forms.Label();
            this.label69 = new System.Windows.Forms.Label();
            this.label70 = new System.Windows.Forms.Label();
            this.label71 = new System.Windows.Forms.Label();
            this.label72 = new System.Windows.Forms.Label();
            this.label73 = new System.Windows.Forms.Label();
            this.label74 = new System.Windows.Forms.Label();
            this.label75 = new System.Windows.Forms.Label();
            this.label76 = new System.Windows.Forms.Label();
            this.label77 = new System.Windows.Forms.Label();
            this.label78 = new System.Windows.Forms.Label();
            this.label79 = new System.Windows.Forms.Label();
            this.label80 = new System.Windows.Forms.Label();
            this.label81 = new System.Windows.Forms.Label();
            this.label82 = new System.Windows.Forms.Label();
            this.label83 = new System.Windows.Forms.Label();
            this.label85 = new System.Windows.Forms.Label();
            this.label86 = new System.Windows.Forms.Label();
            this.label87 = new System.Windows.Forms.Label();
            this.label88 = new System.Windows.Forms.Label();
            this.label89 = new System.Windows.Forms.Label();
            this.label90 = new System.Windows.Forms.Label();
            this.label91 = new System.Windows.Forms.Label();
            this.label92 = new System.Windows.Forms.Label();
            this.label93 = new System.Windows.Forms.Label();
            this.label94 = new System.Windows.Forms.Label();
            this.label95 = new System.Windows.Forms.Label();
            this.label96 = new System.Windows.Forms.Label();
            this.label97 = new System.Windows.Forms.Label();
            this.linkLabel22 = new System.Windows.Forms.LinkLabel();
            this.tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
            this.checkAll1 = new System.Windows.Forms.CheckBox();
            this.checkBox20 = new System.Windows.Forms.CheckBox();
            this.checkBox19 = new System.Windows.Forms.CheckBox();
            this.checkBox18 = new System.Windows.Forms.CheckBox();
            this.checkBox17 = new System.Windows.Forms.CheckBox();
            this.checkBox16 = new System.Windows.Forms.CheckBox();
            this.checkBox15 = new System.Windows.Forms.CheckBox();
            this.checkBox14 = new System.Windows.Forms.CheckBox();
            this.checkBox13 = new System.Windows.Forms.CheckBox();
            this.checkBox12 = new System.Windows.Forms.CheckBox();
            this.checkBox11 = new System.Windows.Forms.CheckBox();
            this.checkBox10 = new System.Windows.Forms.CheckBox();
            this.checkBox9 = new System.Windows.Forms.CheckBox();
            this.checkBox8 = new System.Windows.Forms.CheckBox();
            this.checkBox7 = new System.Windows.Forms.CheckBox();
            this.checkBox6 = new System.Windows.Forms.CheckBox();
            this.checkBox5 = new System.Windows.Forms.CheckBox();
            this.checkBox4 = new System.Windows.Forms.CheckBox();
            this.checkBox3 = new System.Windows.Forms.CheckBox();
            this.checkBox2 = new System.Windows.Forms.CheckBox();
            this.linkLabel20 = new System.Windows.Forms.LinkLabel();
            this.label10 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.label33 = new System.Windows.Forms.Label();
            this.label35 = new System.Windows.Forms.Label();
            this.label37 = new System.Windows.Forms.Label();
            this.label39 = new System.Windows.Forms.Label();
            this.label41 = new System.Windows.Forms.Label();
            this.label43 = new System.Windows.Forms.Label();
            this.label45 = new System.Windows.Forms.Label();
            this.label47 = new System.Windows.Forms.Label();
            this.label49 = new System.Windows.Forms.Label();
            this.label51 = new System.Windows.Forms.Label();
            this.linkLabel19 = new System.Windows.Forms.LinkLabel();
            this.linkLabel18 = new System.Windows.Forms.LinkLabel();
            this.linkLabel17 = new System.Windows.Forms.LinkLabel();
            this.linkLabel16 = new System.Windows.Forms.LinkLabel();
            this.linkLabel15 = new System.Windows.Forms.LinkLabel();
            this.linkLabel14 = new System.Windows.Forms.LinkLabel();
            this.linkLabel13 = new System.Windows.Forms.LinkLabel();
            this.linkLabel12 = new System.Windows.Forms.LinkLabel();
            this.linkLabel11 = new System.Windows.Forms.LinkLabel();
            this.linkLabel10 = new System.Windows.Forms.LinkLabel();
            this.linkLabel9 = new System.Windows.Forms.LinkLabel();
            this.linkLabel8 = new System.Windows.Forms.LinkLabel();
            this.linkLabel7 = new System.Windows.Forms.LinkLabel();
            this.linkLabel6 = new System.Windows.Forms.LinkLabel();
            this.linkLabel5 = new System.Windows.Forms.LinkLabel();
            this.linkLabel4 = new System.Windows.Forms.LinkLabel();
            this.linkLabel3 = new System.Windows.Forms.LinkLabel();
            this.linkLabel2 = new System.Windows.Forms.LinkLabel();
            this.label48 = new System.Windows.Forms.Label();
            this.label46 = new System.Windows.Forms.Label();
            this.label44 = new System.Windows.Forms.Label();
            this.label42 = new System.Windows.Forms.Label();
            this.label40 = new System.Windows.Forms.Label();
            this.label38 = new System.Windows.Forms.Label();
            this.label36 = new System.Windows.Forms.Label();
            this.label34 = new System.Windows.Forms.Label();
            this.label32 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label50 = new System.Windows.Forms.Label();
            this.label52 = new System.Windows.Forms.Label();
            this.label53 = new System.Windows.Forms.Label();
            this.label54 = new System.Windows.Forms.Label();
            this.label55 = new System.Windows.Forms.Label();
            this.label56 = new System.Windows.Forms.Label();
            this.label57 = new System.Windows.Forms.Label();
            this.label58 = new System.Windows.Forms.Label();
            this.linkLabel1 = new System.Windows.Forms.LinkLabel();
            this.checkBox1 = new System.Windows.Forms.CheckBox();
            this.gbxAppInfo = new System.Windows.Forms.GroupBox();
            this.applicantInfo = new System.Windows.Forms.TableLayoutPanel();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.panel4 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.contextMenuStrip = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.checklistToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tableLayoutPanel1.SuspendLayout();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.tableLayoutPanel3.SuspendLayout();
            this.tableLayoutPanel2.SuspendLayout();
            this.gbxAppInfo.SuspendLayout();
            this.applicantInfo.SuspendLayout();
            this.panel4.SuspendLayout();
            this.contextMenuStrip.SuspendLayout();
            this.SuspendLayout();
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.OutsetDouble;
            this.tableLayoutPanel1.ColumnCount = 1;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.Controls.Add(this.panel1, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.panel4, 0, 0);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 2;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 25F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 200F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(1075, 400);
            this.tableLayoutPanel1.TabIndex = 1;
            // 
            // panel1
            // 
            this.panel1.AutoScroll = true;
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Controls.Add(this.tableLayoutPanel3);
            this.panel1.Controls.Add(this.tableLayoutPanel2);
            this.panel1.Controls.Add(this.gbxAppInfo);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(4, 32);
            this.panel1.Margin = new System.Windows.Forms.Padding(1);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1067, 364);
            this.panel1.TabIndex = 1;
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.button1);
            this.panel2.Controls.Add(this.btnRegister);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel2.Location = new System.Drawing.Point(0, 690);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1050, 58);
            this.panel2.TabIndex = 84;
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.LimeGreen;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button1.Location = new System.Drawing.Point(841, 17);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(92, 27);
            this.button1.TabIndex = 86;
            this.button1.Text = "Save";
            this.button1.UseVisualStyleBackColor = false;
            // 
            // btnRegister
            // 
            this.btnRegister.BackColor = System.Drawing.Color.Orange;
            this.btnRegister.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnRegister.Location = new System.Drawing.Point(939, 17);
            this.btnRegister.Name = "btnRegister";
            this.btnRegister.Size = new System.Drawing.Size(92, 27);
            this.btnRegister.TabIndex = 85;
            this.btnRegister.Text = "Cancel";
            this.btnRegister.UseVisualStyleBackColor = false;
            // 
            // tableLayoutPanel3
            // 
            this.tableLayoutPanel3.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Inset;
            this.tableLayoutPanel3.ColumnCount = 4;
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 27F));
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 265F));
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 50F));
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 24F));
            this.tableLayoutPanel3.Controls.Add(this.checkAll2, 3, 0);
            this.tableLayoutPanel3.Controls.Add(this.linkLabel21, 2, 18);
            this.tableLayoutPanel3.Controls.Add(this.checkBox38, 3, 18);
            this.tableLayoutPanel3.Controls.Add(this.checkBox37, 3, 17);
            this.tableLayoutPanel3.Controls.Add(this.checkBox36, 3, 16);
            this.tableLayoutPanel3.Controls.Add(this.checkBox35, 3, 15);
            this.tableLayoutPanel3.Controls.Add(this.checkBox34, 3, 14);
            this.tableLayoutPanel3.Controls.Add(this.checkBox33, 3, 13);
            this.tableLayoutPanel3.Controls.Add(this.checkBox32, 3, 12);
            this.tableLayoutPanel3.Controls.Add(this.checkBox31, 3, 11);
            this.tableLayoutPanel3.Controls.Add(this.checkBox30, 3, 10);
            this.tableLayoutPanel3.Controls.Add(this.checkBox29, 3, 9);
            this.tableLayoutPanel3.Controls.Add(this.checkBox28, 3, 8);
            this.tableLayoutPanel3.Controls.Add(this.checkBox27, 3, 7);
            this.tableLayoutPanel3.Controls.Add(this.checkBox26, 3, 6);
            this.tableLayoutPanel3.Controls.Add(this.checkBox25, 3, 5);
            this.tableLayoutPanel3.Controls.Add(this.checkBox24, 3, 4);
            this.tableLayoutPanel3.Controls.Add(this.checkBox23, 3, 3);
            this.tableLayoutPanel3.Controls.Add(this.checkBox22, 3, 2);
            this.tableLayoutPanel3.Controls.Add(this.checkBox21, 3, 1);
            this.tableLayoutPanel3.Controls.Add(this.label84, 0, 18);
            this.tableLayoutPanel3.Controls.Add(this.label59, 0, 18);
            this.tableLayoutPanel3.Controls.Add(this.linkLabel38, 2, 17);
            this.tableLayoutPanel3.Controls.Add(this.linkLabel37, 2, 16);
            this.tableLayoutPanel3.Controls.Add(this.linkLabel36, 2, 15);
            this.tableLayoutPanel3.Controls.Add(this.linkLabel35, 2, 14);
            this.tableLayoutPanel3.Controls.Add(this.linkLabel34, 2, 13);
            this.tableLayoutPanel3.Controls.Add(this.linkLabel33, 2, 12);
            this.tableLayoutPanel3.Controls.Add(this.linkLabel32, 2, 11);
            this.tableLayoutPanel3.Controls.Add(this.linkLabel31, 2, 10);
            this.tableLayoutPanel3.Controls.Add(this.linkLabel30, 2, 9);
            this.tableLayoutPanel3.Controls.Add(this.linkLabel29, 2, 8);
            this.tableLayoutPanel3.Controls.Add(this.linkLabel28, 2, 7);
            this.tableLayoutPanel3.Controls.Add(this.linkLabel27, 2, 6);
            this.tableLayoutPanel3.Controls.Add(this.linkLabel26, 2, 5);
            this.tableLayoutPanel3.Controls.Add(this.linkLabel25, 2, 4);
            this.tableLayoutPanel3.Controls.Add(this.linkLabel24, 2, 3);
            this.tableLayoutPanel3.Controls.Add(this.linkLabel23, 2, 2);
            this.tableLayoutPanel3.Controls.Add(this.label60, 1, 17);
            this.tableLayoutPanel3.Controls.Add(this.label61, 0, 17);
            this.tableLayoutPanel3.Controls.Add(this.label62, 1, 16);
            this.tableLayoutPanel3.Controls.Add(this.label63, 0, 16);
            this.tableLayoutPanel3.Controls.Add(this.label64, 1, 15);
            this.tableLayoutPanel3.Controls.Add(this.label65, 0, 15);
            this.tableLayoutPanel3.Controls.Add(this.label66, 1, 14);
            this.tableLayoutPanel3.Controls.Add(this.label67, 0, 14);
            this.tableLayoutPanel3.Controls.Add(this.label68, 1, 13);
            this.tableLayoutPanel3.Controls.Add(this.label69, 0, 13);
            this.tableLayoutPanel3.Controls.Add(this.label70, 1, 12);
            this.tableLayoutPanel3.Controls.Add(this.label71, 0, 12);
            this.tableLayoutPanel3.Controls.Add(this.label72, 1, 11);
            this.tableLayoutPanel3.Controls.Add(this.label73, 0, 11);
            this.tableLayoutPanel3.Controls.Add(this.label74, 1, 10);
            this.tableLayoutPanel3.Controls.Add(this.label75, 0, 10);
            this.tableLayoutPanel3.Controls.Add(this.label76, 1, 9);
            this.tableLayoutPanel3.Controls.Add(this.label77, 0, 9);
            this.tableLayoutPanel3.Controls.Add(this.label78, 1, 8);
            this.tableLayoutPanel3.Controls.Add(this.label79, 0, 8);
            this.tableLayoutPanel3.Controls.Add(this.label80, 1, 7);
            this.tableLayoutPanel3.Controls.Add(this.label81, 1, 6);
            this.tableLayoutPanel3.Controls.Add(this.label82, 1, 5);
            this.tableLayoutPanel3.Controls.Add(this.label83, 1, 4);
            this.tableLayoutPanel3.Controls.Add(this.label85, 1, 3);
            this.tableLayoutPanel3.Controls.Add(this.label86, 1, 2);
            this.tableLayoutPanel3.Controls.Add(this.label87, 1, 1);
            this.tableLayoutPanel3.Controls.Add(this.label88, 2, 0);
            this.tableLayoutPanel3.Controls.Add(this.label89, 0, 0);
            this.tableLayoutPanel3.Controls.Add(this.label90, 1, 0);
            this.tableLayoutPanel3.Controls.Add(this.label91, 0, 1);
            this.tableLayoutPanel3.Controls.Add(this.label92, 0, 2);
            this.tableLayoutPanel3.Controls.Add(this.label93, 0, 3);
            this.tableLayoutPanel3.Controls.Add(this.label94, 0, 4);
            this.tableLayoutPanel3.Controls.Add(this.label95, 0, 5);
            this.tableLayoutPanel3.Controls.Add(this.label96, 0, 6);
            this.tableLayoutPanel3.Controls.Add(this.label97, 0, 7);
            this.tableLayoutPanel3.Controls.Add(this.linkLabel22, 2, 1);
            this.tableLayoutPanel3.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tableLayoutPanel3.Location = new System.Drawing.Point(426, 226);
            this.tableLayoutPanel3.Name = "tableLayoutPanel3";
            this.tableLayoutPanel3.RowCount = 19;
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel3.Size = new System.Drawing.Size(372, 423);
            this.tableLayoutPanel3.TabIndex = 83;
            // 
            // checkAll2
            // 
            this.checkAll2.AutoSize = true;
            this.checkAll2.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.checkAll2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.checkAll2.Location = new System.Drawing.Point(353, 5);
            this.checkAll2.Name = "checkAll2";
            this.checkAll2.Size = new System.Drawing.Size(18, 14);
            this.checkAll2.TabIndex = 148;
            this.checkAll2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.checkAll2.UseVisualStyleBackColor = false;
            // 
            // linkLabel21
            // 
            this.linkLabel21.AutoSize = true;
            this.linkLabel21.Dock = System.Windows.Forms.DockStyle.Fill;
            this.linkLabel21.Location = new System.Drawing.Point(301, 398);
            this.linkLabel21.Name = "linkLabel21";
            this.linkLabel21.Size = new System.Drawing.Size(44, 23);
            this.linkLabel21.TabIndex = 147;
            this.linkLabel21.TabStop = true;
            this.linkLabel21.Text = "File";
            this.linkLabel21.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // checkBox38
            // 
            this.checkBox38.AutoSize = true;
            this.checkBox38.Dock = System.Windows.Forms.DockStyle.Fill;
            this.checkBox38.Location = new System.Drawing.Point(353, 401);
            this.checkBox38.Name = "checkBox38";
            this.checkBox38.Size = new System.Drawing.Size(18, 17);
            this.checkBox38.TabIndex = 146;
            this.checkBox38.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.checkBox38.UseVisualStyleBackColor = true;
            // 
            // checkBox37
            // 
            this.checkBox37.AutoSize = true;
            this.checkBox37.Dock = System.Windows.Forms.DockStyle.Fill;
            this.checkBox37.Location = new System.Drawing.Point(353, 379);
            this.checkBox37.Name = "checkBox37";
            this.checkBox37.Size = new System.Drawing.Size(18, 14);
            this.checkBox37.TabIndex = 145;
            this.checkBox37.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.checkBox37.UseVisualStyleBackColor = true;
            // 
            // checkBox36
            // 
            this.checkBox36.AutoSize = true;
            this.checkBox36.Dock = System.Windows.Forms.DockStyle.Fill;
            this.checkBox36.Location = new System.Drawing.Point(353, 357);
            this.checkBox36.Name = "checkBox36";
            this.checkBox36.Size = new System.Drawing.Size(18, 14);
            this.checkBox36.TabIndex = 144;
            this.checkBox36.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.checkBox36.UseVisualStyleBackColor = true;
            // 
            // checkBox35
            // 
            this.checkBox35.AutoSize = true;
            this.checkBox35.Dock = System.Windows.Forms.DockStyle.Fill;
            this.checkBox35.Location = new System.Drawing.Point(353, 335);
            this.checkBox35.Name = "checkBox35";
            this.checkBox35.Size = new System.Drawing.Size(18, 14);
            this.checkBox35.TabIndex = 143;
            this.checkBox35.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.checkBox35.UseVisualStyleBackColor = true;
            // 
            // checkBox34
            // 
            this.checkBox34.AutoSize = true;
            this.checkBox34.Dock = System.Windows.Forms.DockStyle.Fill;
            this.checkBox34.Location = new System.Drawing.Point(353, 313);
            this.checkBox34.Name = "checkBox34";
            this.checkBox34.Size = new System.Drawing.Size(18, 14);
            this.checkBox34.TabIndex = 142;
            this.checkBox34.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.checkBox34.UseVisualStyleBackColor = true;
            // 
            // checkBox33
            // 
            this.checkBox33.AutoSize = true;
            this.checkBox33.Dock = System.Windows.Forms.DockStyle.Fill;
            this.checkBox33.Location = new System.Drawing.Point(353, 291);
            this.checkBox33.Name = "checkBox33";
            this.checkBox33.Size = new System.Drawing.Size(18, 14);
            this.checkBox33.TabIndex = 141;
            this.checkBox33.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.checkBox33.UseVisualStyleBackColor = true;
            // 
            // checkBox32
            // 
            this.checkBox32.AutoSize = true;
            this.checkBox32.Dock = System.Windows.Forms.DockStyle.Fill;
            this.checkBox32.Location = new System.Drawing.Point(353, 269);
            this.checkBox32.Name = "checkBox32";
            this.checkBox32.Size = new System.Drawing.Size(18, 14);
            this.checkBox32.TabIndex = 140;
            this.checkBox32.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.checkBox32.UseVisualStyleBackColor = true;
            // 
            // checkBox31
            // 
            this.checkBox31.AutoSize = true;
            this.checkBox31.Dock = System.Windows.Forms.DockStyle.Fill;
            this.checkBox31.Location = new System.Drawing.Point(353, 247);
            this.checkBox31.Name = "checkBox31";
            this.checkBox31.Size = new System.Drawing.Size(18, 14);
            this.checkBox31.TabIndex = 139;
            this.checkBox31.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.checkBox31.UseVisualStyleBackColor = true;
            // 
            // checkBox30
            // 
            this.checkBox30.AutoSize = true;
            this.checkBox30.Dock = System.Windows.Forms.DockStyle.Fill;
            this.checkBox30.Location = new System.Drawing.Point(353, 225);
            this.checkBox30.Name = "checkBox30";
            this.checkBox30.Size = new System.Drawing.Size(18, 14);
            this.checkBox30.TabIndex = 138;
            this.checkBox30.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.checkBox30.UseVisualStyleBackColor = true;
            // 
            // checkBox29
            // 
            this.checkBox29.AutoSize = true;
            this.checkBox29.Dock = System.Windows.Forms.DockStyle.Fill;
            this.checkBox29.Location = new System.Drawing.Point(353, 203);
            this.checkBox29.Name = "checkBox29";
            this.checkBox29.Size = new System.Drawing.Size(18, 14);
            this.checkBox29.TabIndex = 137;
            this.checkBox29.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.checkBox29.UseVisualStyleBackColor = true;
            // 
            // checkBox28
            // 
            this.checkBox28.AutoSize = true;
            this.checkBox28.Dock = System.Windows.Forms.DockStyle.Fill;
            this.checkBox28.Location = new System.Drawing.Point(353, 181);
            this.checkBox28.Name = "checkBox28";
            this.checkBox28.Size = new System.Drawing.Size(18, 14);
            this.checkBox28.TabIndex = 136;
            this.checkBox28.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.checkBox28.UseVisualStyleBackColor = true;
            // 
            // checkBox27
            // 
            this.checkBox27.AutoSize = true;
            this.checkBox27.Dock = System.Windows.Forms.DockStyle.Fill;
            this.checkBox27.Location = new System.Drawing.Point(353, 159);
            this.checkBox27.Name = "checkBox27";
            this.checkBox27.Size = new System.Drawing.Size(18, 14);
            this.checkBox27.TabIndex = 135;
            this.checkBox27.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.checkBox27.UseVisualStyleBackColor = true;
            // 
            // checkBox26
            // 
            this.checkBox26.AutoSize = true;
            this.checkBox26.Dock = System.Windows.Forms.DockStyle.Fill;
            this.checkBox26.Location = new System.Drawing.Point(353, 137);
            this.checkBox26.Name = "checkBox26";
            this.checkBox26.Size = new System.Drawing.Size(18, 14);
            this.checkBox26.TabIndex = 134;
            this.checkBox26.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.checkBox26.UseVisualStyleBackColor = true;
            // 
            // checkBox25
            // 
            this.checkBox25.AutoSize = true;
            this.checkBox25.Dock = System.Windows.Forms.DockStyle.Fill;
            this.checkBox25.Location = new System.Drawing.Point(353, 115);
            this.checkBox25.Name = "checkBox25";
            this.checkBox25.Size = new System.Drawing.Size(18, 14);
            this.checkBox25.TabIndex = 133;
            this.checkBox25.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.checkBox25.UseVisualStyleBackColor = true;
            // 
            // checkBox24
            // 
            this.checkBox24.AutoSize = true;
            this.checkBox24.Dock = System.Windows.Forms.DockStyle.Fill;
            this.checkBox24.Location = new System.Drawing.Point(353, 93);
            this.checkBox24.Name = "checkBox24";
            this.checkBox24.Size = new System.Drawing.Size(18, 14);
            this.checkBox24.TabIndex = 132;
            this.checkBox24.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.checkBox24.UseVisualStyleBackColor = true;
            // 
            // checkBox23
            // 
            this.checkBox23.AutoSize = true;
            this.checkBox23.Dock = System.Windows.Forms.DockStyle.Fill;
            this.checkBox23.Location = new System.Drawing.Point(353, 71);
            this.checkBox23.Name = "checkBox23";
            this.checkBox23.Size = new System.Drawing.Size(18, 14);
            this.checkBox23.TabIndex = 131;
            this.checkBox23.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.checkBox23.UseVisualStyleBackColor = true;
            // 
            // checkBox22
            // 
            this.checkBox22.AutoSize = true;
            this.checkBox22.Dock = System.Windows.Forms.DockStyle.Fill;
            this.checkBox22.Location = new System.Drawing.Point(353, 49);
            this.checkBox22.Name = "checkBox22";
            this.checkBox22.Size = new System.Drawing.Size(18, 14);
            this.checkBox22.TabIndex = 130;
            this.checkBox22.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.checkBox22.UseVisualStyleBackColor = true;
            // 
            // checkBox21
            // 
            this.checkBox21.AutoSize = true;
            this.checkBox21.Dock = System.Windows.Forms.DockStyle.Fill;
            this.checkBox21.Location = new System.Drawing.Point(353, 27);
            this.checkBox21.Name = "checkBox21";
            this.checkBox21.Size = new System.Drawing.Size(18, 14);
            this.checkBox21.TabIndex = 129;
            this.checkBox21.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.checkBox21.UseVisualStyleBackColor = true;
            // 
            // label84
            // 
            this.label84.AutoSize = true;
            this.label84.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label84.Location = new System.Drawing.Point(5, 398);
            this.label84.Name = "label84";
            this.label84.Size = new System.Drawing.Size(21, 23);
            this.label84.TabIndex = 98;
            this.label84.Text = "18";
            this.label84.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label59
            // 
            this.label59.AutoSize = true;
            this.label59.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label59.Location = new System.Drawing.Point(34, 398);
            this.label59.Name = "label59";
            this.label59.Size = new System.Drawing.Size(259, 23);
            this.label59.TabIndex = 97;
            this.label59.Text = "Data Privacy Consent";
            this.label59.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // linkLabel38
            // 
            this.linkLabel38.AutoSize = true;
            this.linkLabel38.Dock = System.Windows.Forms.DockStyle.Fill;
            this.linkLabel38.Location = new System.Drawing.Point(301, 376);
            this.linkLabel38.Name = "linkLabel38";
            this.linkLabel38.Size = new System.Drawing.Size(44, 20);
            this.linkLabel38.TabIndex = 94;
            this.linkLabel38.TabStop = true;
            this.linkLabel38.Text = "File";
            this.linkLabel38.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // linkLabel37
            // 
            this.linkLabel37.AutoSize = true;
            this.linkLabel37.Dock = System.Windows.Forms.DockStyle.Fill;
            this.linkLabel37.Location = new System.Drawing.Point(301, 354);
            this.linkLabel37.Name = "linkLabel37";
            this.linkLabel37.Size = new System.Drawing.Size(44, 20);
            this.linkLabel37.TabIndex = 93;
            this.linkLabel37.TabStop = true;
            this.linkLabel37.Text = "File";
            this.linkLabel37.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // linkLabel36
            // 
            this.linkLabel36.AutoSize = true;
            this.linkLabel36.Dock = System.Windows.Forms.DockStyle.Fill;
            this.linkLabel36.Location = new System.Drawing.Point(301, 332);
            this.linkLabel36.Name = "linkLabel36";
            this.linkLabel36.Size = new System.Drawing.Size(44, 20);
            this.linkLabel36.TabIndex = 92;
            this.linkLabel36.TabStop = true;
            this.linkLabel36.Text = "File";
            this.linkLabel36.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // linkLabel35
            // 
            this.linkLabel35.AutoSize = true;
            this.linkLabel35.Dock = System.Windows.Forms.DockStyle.Fill;
            this.linkLabel35.Location = new System.Drawing.Point(301, 310);
            this.linkLabel35.Name = "linkLabel35";
            this.linkLabel35.Size = new System.Drawing.Size(44, 20);
            this.linkLabel35.TabIndex = 91;
            this.linkLabel35.TabStop = true;
            this.linkLabel35.Text = "File";
            this.linkLabel35.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // linkLabel34
            // 
            this.linkLabel34.AutoSize = true;
            this.linkLabel34.Dock = System.Windows.Forms.DockStyle.Fill;
            this.linkLabel34.Location = new System.Drawing.Point(301, 288);
            this.linkLabel34.Name = "linkLabel34";
            this.linkLabel34.Size = new System.Drawing.Size(44, 20);
            this.linkLabel34.TabIndex = 90;
            this.linkLabel34.TabStop = true;
            this.linkLabel34.Text = "File";
            this.linkLabel34.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // linkLabel33
            // 
            this.linkLabel33.AutoSize = true;
            this.linkLabel33.Dock = System.Windows.Forms.DockStyle.Fill;
            this.linkLabel33.Location = new System.Drawing.Point(301, 266);
            this.linkLabel33.Name = "linkLabel33";
            this.linkLabel33.Size = new System.Drawing.Size(44, 20);
            this.linkLabel33.TabIndex = 89;
            this.linkLabel33.TabStop = true;
            this.linkLabel33.Text = "File";
            this.linkLabel33.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // linkLabel32
            // 
            this.linkLabel32.AutoSize = true;
            this.linkLabel32.Dock = System.Windows.Forms.DockStyle.Fill;
            this.linkLabel32.Location = new System.Drawing.Point(301, 244);
            this.linkLabel32.Name = "linkLabel32";
            this.linkLabel32.Size = new System.Drawing.Size(44, 20);
            this.linkLabel32.TabIndex = 88;
            this.linkLabel32.TabStop = true;
            this.linkLabel32.Text = "File";
            this.linkLabel32.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // linkLabel31
            // 
            this.linkLabel31.AutoSize = true;
            this.linkLabel31.Dock = System.Windows.Forms.DockStyle.Fill;
            this.linkLabel31.Location = new System.Drawing.Point(301, 222);
            this.linkLabel31.Name = "linkLabel31";
            this.linkLabel31.Size = new System.Drawing.Size(44, 20);
            this.linkLabel31.TabIndex = 87;
            this.linkLabel31.TabStop = true;
            this.linkLabel31.Text = "File";
            this.linkLabel31.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // linkLabel30
            // 
            this.linkLabel30.AutoSize = true;
            this.linkLabel30.Dock = System.Windows.Forms.DockStyle.Fill;
            this.linkLabel30.Location = new System.Drawing.Point(301, 200);
            this.linkLabel30.Name = "linkLabel30";
            this.linkLabel30.Size = new System.Drawing.Size(44, 20);
            this.linkLabel30.TabIndex = 86;
            this.linkLabel30.TabStop = true;
            this.linkLabel30.Text = "File";
            this.linkLabel30.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // linkLabel29
            // 
            this.linkLabel29.AutoSize = true;
            this.linkLabel29.Dock = System.Windows.Forms.DockStyle.Fill;
            this.linkLabel29.Location = new System.Drawing.Point(301, 178);
            this.linkLabel29.Name = "linkLabel29";
            this.linkLabel29.Size = new System.Drawing.Size(44, 20);
            this.linkLabel29.TabIndex = 85;
            this.linkLabel29.TabStop = true;
            this.linkLabel29.Text = "File";
            this.linkLabel29.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // linkLabel28
            // 
            this.linkLabel28.AutoSize = true;
            this.linkLabel28.Dock = System.Windows.Forms.DockStyle.Fill;
            this.linkLabel28.Location = new System.Drawing.Point(301, 156);
            this.linkLabel28.Name = "linkLabel28";
            this.linkLabel28.Size = new System.Drawing.Size(44, 20);
            this.linkLabel28.TabIndex = 84;
            this.linkLabel28.TabStop = true;
            this.linkLabel28.Text = "File";
            this.linkLabel28.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // linkLabel27
            // 
            this.linkLabel27.AutoSize = true;
            this.linkLabel27.Dock = System.Windows.Forms.DockStyle.Fill;
            this.linkLabel27.Location = new System.Drawing.Point(301, 134);
            this.linkLabel27.Name = "linkLabel27";
            this.linkLabel27.Size = new System.Drawing.Size(44, 20);
            this.linkLabel27.TabIndex = 83;
            this.linkLabel27.TabStop = true;
            this.linkLabel27.Text = "File";
            this.linkLabel27.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // linkLabel26
            // 
            this.linkLabel26.AutoSize = true;
            this.linkLabel26.Dock = System.Windows.Forms.DockStyle.Fill;
            this.linkLabel26.Location = new System.Drawing.Point(301, 112);
            this.linkLabel26.Name = "linkLabel26";
            this.linkLabel26.Size = new System.Drawing.Size(44, 20);
            this.linkLabel26.TabIndex = 82;
            this.linkLabel26.TabStop = true;
            this.linkLabel26.Text = "File";
            this.linkLabel26.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // linkLabel25
            // 
            this.linkLabel25.AutoSize = true;
            this.linkLabel25.Dock = System.Windows.Forms.DockStyle.Fill;
            this.linkLabel25.Location = new System.Drawing.Point(301, 90);
            this.linkLabel25.Name = "linkLabel25";
            this.linkLabel25.Size = new System.Drawing.Size(44, 20);
            this.linkLabel25.TabIndex = 81;
            this.linkLabel25.TabStop = true;
            this.linkLabel25.Text = "File";
            this.linkLabel25.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // linkLabel24
            // 
            this.linkLabel24.AutoSize = true;
            this.linkLabel24.Dock = System.Windows.Forms.DockStyle.Fill;
            this.linkLabel24.Location = new System.Drawing.Point(301, 68);
            this.linkLabel24.Name = "linkLabel24";
            this.linkLabel24.Size = new System.Drawing.Size(44, 20);
            this.linkLabel24.TabIndex = 80;
            this.linkLabel24.TabStop = true;
            this.linkLabel24.Text = "File";
            this.linkLabel24.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // linkLabel23
            // 
            this.linkLabel23.AutoSize = true;
            this.linkLabel23.Dock = System.Windows.Forms.DockStyle.Fill;
            this.linkLabel23.Location = new System.Drawing.Point(301, 46);
            this.linkLabel23.Name = "linkLabel23";
            this.linkLabel23.Size = new System.Drawing.Size(44, 20);
            this.linkLabel23.TabIndex = 79;
            this.linkLabel23.TabStop = true;
            this.linkLabel23.Text = "File";
            this.linkLabel23.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label60
            // 
            this.label60.AutoSize = true;
            this.label60.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label60.Location = new System.Drawing.Point(34, 376);
            this.label60.Name = "label60";
            this.label60.Size = new System.Drawing.Size(259, 20);
            this.label60.TabIndex = 77;
            this.label60.Text = "Locker Accountability && Usage Policy";
            this.label60.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label61
            // 
            this.label61.AutoSize = true;
            this.label61.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label61.Location = new System.Drawing.Point(5, 376);
            this.label61.Name = "label61";
            this.label61.Size = new System.Drawing.Size(21, 20);
            this.label61.TabIndex = 76;
            this.label61.Text = "17";
            this.label61.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label62
            // 
            this.label62.AutoSize = true;
            this.label62.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label62.Location = new System.Drawing.Point(34, 354);
            this.label62.Name = "label62";
            this.label62.Size = new System.Drawing.Size(259, 20);
            this.label62.TabIndex = 75;
            this.label62.Text = "Identification Card && ID Badge";
            this.label62.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label63
            // 
            this.label63.AutoSize = true;
            this.label63.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label63.Location = new System.Drawing.Point(5, 354);
            this.label63.Name = "label63";
            this.label63.Size = new System.Drawing.Size(21, 20);
            this.label63.TabIndex = 74;
            this.label63.Text = "16";
            this.label63.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label64
            // 
            this.label64.AutoSize = true;
            this.label64.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label64.Location = new System.Drawing.Point(34, 332);
            this.label64.Name = "label64";
            this.label64.Size = new System.Drawing.Size(259, 20);
            this.label64.TabIndex = 73;
            this.label64.Text = "Acceptable Use Policy";
            this.label64.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label65
            // 
            this.label65.AutoSize = true;
            this.label65.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label65.Location = new System.Drawing.Point(5, 332);
            this.label65.Name = "label65";
            this.label65.Size = new System.Drawing.Size(21, 20);
            this.label65.TabIndex = 72;
            this.label65.Text = "15";
            this.label65.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label66
            // 
            this.label66.AutoSize = true;
            this.label66.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label66.Location = new System.Drawing.Point(34, 310);
            this.label66.Name = "label66";
            this.label66.Size = new System.Drawing.Size(259, 20);
            this.label66.TabIndex = 71;
            this.label66.Text = "Consent && Waiver for Call Recording";
            this.label66.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label67
            // 
            this.label67.AutoSize = true;
            this.label67.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label67.Location = new System.Drawing.Point(5, 310);
            this.label67.Name = "label67";
            this.label67.Size = new System.Drawing.Size(21, 20);
            this.label67.TabIndex = 70;
            this.label67.Text = "14";
            this.label67.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label68
            // 
            this.label68.AutoSize = true;
            this.label68.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label68.Location = new System.Drawing.Point(34, 288);
            this.label68.Name = "label68";
            this.label68.Size = new System.Drawing.Size(259, 20);
            this.label68.TabIndex = 69;
            this.label68.Text = "Confidentiality Agreement";
            this.label68.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label69
            // 
            this.label69.AutoSize = true;
            this.label69.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label69.Location = new System.Drawing.Point(5, 288);
            this.label69.Name = "label69";
            this.label69.Size = new System.Drawing.Size(21, 20);
            this.label69.TabIndex = 68;
            this.label69.Text = "13";
            this.label69.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label70
            // 
            this.label70.AutoSize = true;
            this.label70.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label70.Location = new System.Drawing.Point(34, 266);
            this.label70.Name = "label70";
            this.label70.Size = new System.Drawing.Size(259, 20);
            this.label70.TabIndex = 67;
            this.label70.Text = "Acceptance of Code of Conduct";
            this.label70.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label71
            // 
            this.label71.AutoSize = true;
            this.label71.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label71.Location = new System.Drawing.Point(5, 266);
            this.label71.Name = "label71";
            this.label71.Size = new System.Drawing.Size(21, 20);
            this.label71.TabIndex = 66;
            this.label71.Text = "12";
            this.label71.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label72
            // 
            this.label72.AutoSize = true;
            this.label72.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label72.Location = new System.Drawing.Point(34, 244);
            this.label72.Name = "label72";
            this.label72.Size = new System.Drawing.Size(259, 20);
            this.label72.TabIndex = 65;
            this.label72.Text = "Acceptance of Code of Discipline";
            this.label72.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label73
            // 
            this.label73.AutoSize = true;
            this.label73.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label73.Location = new System.Drawing.Point(5, 244);
            this.label73.Name = "label73";
            this.label73.Size = new System.Drawing.Size(21, 20);
            this.label73.TabIndex = 64;
            this.label73.Text = "11";
            this.label73.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label74
            // 
            this.label74.AutoSize = true;
            this.label74.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label74.Location = new System.Drawing.Point(34, 222);
            this.label74.Name = "label74";
            this.label74.Size = new System.Drawing.Size(259, 20);
            this.label74.TabIndex = 63;
            this.label74.Text = "NSO Marriage Certificate (4 copies)";
            this.label74.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label75
            // 
            this.label75.AutoSize = true;
            this.label75.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label75.Location = new System.Drawing.Point(5, 222);
            this.label75.Name = "label75";
            this.label75.Size = new System.Drawing.Size(21, 20);
            this.label75.TabIndex = 62;
            this.label75.Text = "10";
            this.label75.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label76
            // 
            this.label76.AutoSize = true;
            this.label76.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label76.Location = new System.Drawing.Point(34, 200);
            this.label76.Name = "label76";
            this.label76.Size = new System.Drawing.Size(259, 20);
            this.label76.TabIndex = 61;
            this.label76.Text = "NSO Dependent/s\' Birth Certificate (4 copies)";
            this.label76.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label77
            // 
            this.label77.AutoSize = true;
            this.label77.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label77.Location = new System.Drawing.Point(5, 200);
            this.label77.Name = "label77";
            this.label77.Size = new System.Drawing.Size(21, 20);
            this.label77.TabIndex = 60;
            this.label77.Text = "9";
            this.label77.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label78
            // 
            this.label78.AutoSize = true;
            this.label78.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label78.Location = new System.Drawing.Point(34, 178);
            this.label78.Name = "label78";
            this.label78.Size = new System.Drawing.Size(259, 20);
            this.label78.TabIndex = 59;
            this.label78.Text = "Cedula";
            this.label78.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label79
            // 
            this.label79.AutoSize = true;
            this.label79.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label79.Location = new System.Drawing.Point(5, 178);
            this.label79.Name = "label79";
            this.label79.Size = new System.Drawing.Size(21, 20);
            this.label79.TabIndex = 58;
            this.label79.Text = "8";
            this.label79.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label80
            // 
            this.label80.AutoSize = true;
            this.label80.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label80.Location = new System.Drawing.Point(34, 156);
            this.label80.Name = "label80";
            this.label80.Size = new System.Drawing.Size(259, 20);
            this.label80.TabIndex = 57;
            this.label80.Text = "Occupational Permit";
            this.label80.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label81
            // 
            this.label81.AutoSize = true;
            this.label81.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label81.Location = new System.Drawing.Point(34, 134);
            this.label81.Name = "label81";
            this.label81.Size = new System.Drawing.Size(259, 20);
            this.label81.TabIndex = 56;
            this.label81.Text = "BIR 2316 or BIR 2316 with waiver";
            this.label81.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label82
            // 
            this.label82.AutoSize = true;
            this.label82.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label82.Location = new System.Drawing.Point(34, 112);
            this.label82.Name = "label82";
            this.label82.Size = new System.Drawing.Size(259, 20);
            this.label82.TabIndex = 55;
            this.label82.Text = "BIR 2305";
            this.label82.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label83
            // 
            this.label83.AutoSize = true;
            this.label83.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label83.Location = new System.Drawing.Point(34, 90);
            this.label83.Name = "label83";
            this.label83.Size = new System.Drawing.Size(259, 20);
            this.label83.TabIndex = 54;
            this.label83.Text = "BIR 1905";
            this.label83.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label85
            // 
            this.label85.AutoSize = true;
            this.label85.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label85.Location = new System.Drawing.Point(34, 68);
            this.label85.Name = "label85";
            this.label85.Size = new System.Drawing.Size(259, 20);
            this.label85.TabIndex = 53;
            this.label85.Text = "Bank Forms";
            this.label85.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label86
            // 
            this.label86.AutoSize = true;
            this.label86.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label86.Location = new System.Drawing.Point(34, 46);
            this.label86.Name = "label86";
            this.label86.Size = new System.Drawing.Size(259, 20);
            this.label86.TabIndex = 52;
            this.label86.Text = "HMO/AXA Form";
            this.label86.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label87
            // 
            this.label87.AutoSize = true;
            this.label87.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label87.Location = new System.Drawing.Point(34, 24);
            this.label87.Name = "label87";
            this.label87.Size = new System.Drawing.Size(259, 20);
            this.label87.TabIndex = 51;
            this.label87.Text = "Payroll Data Form";
            this.label87.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label88
            // 
            this.label88.AutoSize = true;
            this.label88.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.label88.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label88.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label88.Location = new System.Drawing.Point(298, 2);
            this.label88.Margin = new System.Windows.Forms.Padding(0);
            this.label88.Name = "label88";
            this.label88.Size = new System.Drawing.Size(50, 20);
            this.label88.TabIndex = 2;
            this.label88.Text = "@@";
            this.label88.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label89
            // 
            this.label89.AutoSize = true;
            this.label89.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.label89.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label89.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label89.Location = new System.Drawing.Point(2, 2);
            this.label89.Margin = new System.Windows.Forms.Padding(0);
            this.label89.Name = "label89";
            this.label89.Size = new System.Drawing.Size(27, 20);
            this.label89.TabIndex = 1;
            this.label89.Text = "#";
            this.label89.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label90
            // 
            this.label90.AutoSize = true;
            this.label90.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.label90.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label90.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label90.Location = new System.Drawing.Point(31, 2);
            this.label90.Margin = new System.Windows.Forms.Padding(0);
            this.label90.Name = "label90";
            this.label90.Size = new System.Drawing.Size(265, 20);
            this.label90.TabIndex = 0;
            this.label90.Text = "Secondary Requirements";
            this.label90.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label91
            // 
            this.label91.AutoSize = true;
            this.label91.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label91.Location = new System.Drawing.Point(5, 24);
            this.label91.Name = "label91";
            this.label91.Size = new System.Drawing.Size(21, 20);
            this.label91.TabIndex = 44;
            this.label91.Text = "1";
            this.label91.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label92
            // 
            this.label92.AutoSize = true;
            this.label92.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label92.Location = new System.Drawing.Point(5, 46);
            this.label92.Name = "label92";
            this.label92.Size = new System.Drawing.Size(21, 20);
            this.label92.TabIndex = 45;
            this.label92.Text = "2";
            this.label92.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label93
            // 
            this.label93.AutoSize = true;
            this.label93.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label93.Location = new System.Drawing.Point(5, 68);
            this.label93.Name = "label93";
            this.label93.Size = new System.Drawing.Size(21, 20);
            this.label93.TabIndex = 46;
            this.label93.Text = "3";
            this.label93.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label94
            // 
            this.label94.AutoSize = true;
            this.label94.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label94.Location = new System.Drawing.Point(5, 90);
            this.label94.Name = "label94";
            this.label94.Size = new System.Drawing.Size(21, 20);
            this.label94.TabIndex = 47;
            this.label94.Text = "4";
            this.label94.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label95
            // 
            this.label95.AutoSize = true;
            this.label95.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label95.Location = new System.Drawing.Point(5, 112);
            this.label95.Name = "label95";
            this.label95.Size = new System.Drawing.Size(21, 20);
            this.label95.TabIndex = 48;
            this.label95.Text = "5";
            this.label95.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label96
            // 
            this.label96.AutoSize = true;
            this.label96.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label96.Location = new System.Drawing.Point(5, 134);
            this.label96.Name = "label96";
            this.label96.Size = new System.Drawing.Size(21, 20);
            this.label96.TabIndex = 49;
            this.label96.Text = "6";
            this.label96.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label97
            // 
            this.label97.AutoSize = true;
            this.label97.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label97.Location = new System.Drawing.Point(5, 156);
            this.label97.Name = "label97";
            this.label97.Size = new System.Drawing.Size(21, 20);
            this.label97.TabIndex = 50;
            this.label97.Text = "7";
            this.label97.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // linkLabel22
            // 
            this.linkLabel22.AutoSize = true;
            this.linkLabel22.Dock = System.Windows.Forms.DockStyle.Fill;
            this.linkLabel22.Location = new System.Drawing.Point(301, 24);
            this.linkLabel22.Name = "linkLabel22";
            this.linkLabel22.Size = new System.Drawing.Size(44, 20);
            this.linkLabel22.TabIndex = 78;
            this.linkLabel22.TabStop = true;
            this.linkLabel22.Text = "File";
            this.linkLabel22.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tableLayoutPanel2
            // 
            this.tableLayoutPanel2.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Inset;
            this.tableLayoutPanel2.ColumnCount = 4;
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 27F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 264F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 51F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 25F));
            this.tableLayoutPanel2.Controls.Add(this.checkAll1, 3, 0);
            this.tableLayoutPanel2.Controls.Add(this.checkBox20, 3, 20);
            this.tableLayoutPanel2.Controls.Add(this.checkBox19, 3, 19);
            this.tableLayoutPanel2.Controls.Add(this.checkBox18, 3, 18);
            this.tableLayoutPanel2.Controls.Add(this.checkBox17, 3, 17);
            this.tableLayoutPanel2.Controls.Add(this.checkBox16, 3, 16);
            this.tableLayoutPanel2.Controls.Add(this.checkBox15, 3, 15);
            this.tableLayoutPanel2.Controls.Add(this.checkBox14, 3, 14);
            this.tableLayoutPanel2.Controls.Add(this.checkBox13, 3, 13);
            this.tableLayoutPanel2.Controls.Add(this.checkBox12, 3, 12);
            this.tableLayoutPanel2.Controls.Add(this.checkBox11, 3, 11);
            this.tableLayoutPanel2.Controls.Add(this.checkBox10, 3, 10);
            this.tableLayoutPanel2.Controls.Add(this.checkBox9, 3, 9);
            this.tableLayoutPanel2.Controls.Add(this.checkBox8, 3, 8);
            this.tableLayoutPanel2.Controls.Add(this.checkBox7, 3, 7);
            this.tableLayoutPanel2.Controls.Add(this.checkBox6, 3, 6);
            this.tableLayoutPanel2.Controls.Add(this.checkBox5, 3, 5);
            this.tableLayoutPanel2.Controls.Add(this.checkBox4, 3, 4);
            this.tableLayoutPanel2.Controls.Add(this.checkBox3, 3, 3);
            this.tableLayoutPanel2.Controls.Add(this.checkBox2, 3, 2);
            this.tableLayoutPanel2.Controls.Add(this.linkLabel20, 2, 20);
            this.tableLayoutPanel2.Controls.Add(this.label10, 0, 20);
            this.tableLayoutPanel2.Controls.Add(this.label21, 1, 3);
            this.tableLayoutPanel2.Controls.Add(this.label22, 1, 4);
            this.tableLayoutPanel2.Controls.Add(this.label23, 1, 5);
            this.tableLayoutPanel2.Controls.Add(this.label24, 1, 6);
            this.tableLayoutPanel2.Controls.Add(this.label25, 1, 7);
            this.tableLayoutPanel2.Controls.Add(this.label27, 1, 8);
            this.tableLayoutPanel2.Controls.Add(this.label29, 1, 9);
            this.tableLayoutPanel2.Controls.Add(this.label31, 1, 10);
            this.tableLayoutPanel2.Controls.Add(this.label33, 1, 11);
            this.tableLayoutPanel2.Controls.Add(this.label35, 1, 12);
            this.tableLayoutPanel2.Controls.Add(this.label37, 1, 13);
            this.tableLayoutPanel2.Controls.Add(this.label39, 1, 14);
            this.tableLayoutPanel2.Controls.Add(this.label41, 1, 15);
            this.tableLayoutPanel2.Controls.Add(this.label43, 1, 16);
            this.tableLayoutPanel2.Controls.Add(this.label45, 1, 17);
            this.tableLayoutPanel2.Controls.Add(this.label47, 1, 18);
            this.tableLayoutPanel2.Controls.Add(this.label49, 1, 19);
            this.tableLayoutPanel2.Controls.Add(this.label51, 1, 20);
            this.tableLayoutPanel2.Controls.Add(this.linkLabel19, 2, 19);
            this.tableLayoutPanel2.Controls.Add(this.linkLabel18, 2, 18);
            this.tableLayoutPanel2.Controls.Add(this.linkLabel17, 2, 17);
            this.tableLayoutPanel2.Controls.Add(this.linkLabel16, 2, 16);
            this.tableLayoutPanel2.Controls.Add(this.linkLabel15, 2, 15);
            this.tableLayoutPanel2.Controls.Add(this.linkLabel14, 2, 14);
            this.tableLayoutPanel2.Controls.Add(this.linkLabel13, 2, 13);
            this.tableLayoutPanel2.Controls.Add(this.linkLabel12, 2, 12);
            this.tableLayoutPanel2.Controls.Add(this.linkLabel11, 2, 11);
            this.tableLayoutPanel2.Controls.Add(this.linkLabel10, 2, 10);
            this.tableLayoutPanel2.Controls.Add(this.linkLabel9, 2, 9);
            this.tableLayoutPanel2.Controls.Add(this.linkLabel8, 2, 8);
            this.tableLayoutPanel2.Controls.Add(this.linkLabel7, 2, 7);
            this.tableLayoutPanel2.Controls.Add(this.linkLabel6, 2, 6);
            this.tableLayoutPanel2.Controls.Add(this.linkLabel5, 2, 5);
            this.tableLayoutPanel2.Controls.Add(this.linkLabel4, 2, 4);
            this.tableLayoutPanel2.Controls.Add(this.linkLabel3, 2, 3);
            this.tableLayoutPanel2.Controls.Add(this.linkLabel2, 2, 2);
            this.tableLayoutPanel2.Controls.Add(this.label48, 0, 19);
            this.tableLayoutPanel2.Controls.Add(this.label46, 0, 18);
            this.tableLayoutPanel2.Controls.Add(this.label44, 0, 17);
            this.tableLayoutPanel2.Controls.Add(this.label42, 0, 16);
            this.tableLayoutPanel2.Controls.Add(this.label40, 0, 15);
            this.tableLayoutPanel2.Controls.Add(this.label38, 0, 14);
            this.tableLayoutPanel2.Controls.Add(this.label36, 0, 13);
            this.tableLayoutPanel2.Controls.Add(this.label34, 0, 12);
            this.tableLayoutPanel2.Controls.Add(this.label32, 0, 11);
            this.tableLayoutPanel2.Controls.Add(this.label30, 0, 10);
            this.tableLayoutPanel2.Controls.Add(this.label28, 0, 9);
            this.tableLayoutPanel2.Controls.Add(this.label26, 0, 8);
            this.tableLayoutPanel2.Controls.Add(this.label20, 1, 2);
            this.tableLayoutPanel2.Controls.Add(this.label18, 1, 1);
            this.tableLayoutPanel2.Controls.Add(this.label14, 2, 0);
            this.tableLayoutPanel2.Controls.Add(this.label19, 0, 0);
            this.tableLayoutPanel2.Controls.Add(this.label50, 1, 0);
            this.tableLayoutPanel2.Controls.Add(this.label52, 0, 1);
            this.tableLayoutPanel2.Controls.Add(this.label53, 0, 2);
            this.tableLayoutPanel2.Controls.Add(this.label54, 0, 3);
            this.tableLayoutPanel2.Controls.Add(this.label55, 0, 4);
            this.tableLayoutPanel2.Controls.Add(this.label56, 0, 5);
            this.tableLayoutPanel2.Controls.Add(this.label57, 0, 6);
            this.tableLayoutPanel2.Controls.Add(this.label58, 0, 7);
            this.tableLayoutPanel2.Controls.Add(this.linkLabel1, 2, 1);
            this.tableLayoutPanel2.Controls.Add(this.checkBox1, 3, 1);
            this.tableLayoutPanel2.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tableLayoutPanel2.Location = new System.Drawing.Point(28, 226);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            this.tableLayoutPanel2.RowCount = 21;
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel2.Size = new System.Drawing.Size(373, 464);
            this.tableLayoutPanel2.TabIndex = 5;
            // 
            // checkAll1
            // 
            this.checkAll1.AutoSize = true;
            this.checkAll1.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.checkAll1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.checkAll1.Location = new System.Drawing.Point(353, 5);
            this.checkAll1.Name = "checkAll1";
            this.checkAll1.Size = new System.Drawing.Size(19, 14);
            this.checkAll1.TabIndex = 148;
            this.checkAll1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.checkAll1.UseVisualStyleBackColor = false;
            // 
            // checkBox20
            // 
            this.checkBox20.AutoSize = true;
            this.checkBox20.Dock = System.Windows.Forms.DockStyle.Fill;
            this.checkBox20.Location = new System.Drawing.Point(353, 445);
            this.checkBox20.Name = "checkBox20";
            this.checkBox20.Size = new System.Drawing.Size(19, 14);
            this.checkBox20.TabIndex = 147;
            this.checkBox20.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.checkBox20.UseVisualStyleBackColor = true;
            // 
            // checkBox19
            // 
            this.checkBox19.AutoSize = true;
            this.checkBox19.Dock = System.Windows.Forms.DockStyle.Fill;
            this.checkBox19.Location = new System.Drawing.Point(353, 423);
            this.checkBox19.Name = "checkBox19";
            this.checkBox19.Size = new System.Drawing.Size(19, 14);
            this.checkBox19.TabIndex = 146;
            this.checkBox19.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.checkBox19.UseVisualStyleBackColor = true;
            // 
            // checkBox18
            // 
            this.checkBox18.AutoSize = true;
            this.checkBox18.Dock = System.Windows.Forms.DockStyle.Fill;
            this.checkBox18.Location = new System.Drawing.Point(353, 401);
            this.checkBox18.Name = "checkBox18";
            this.checkBox18.Size = new System.Drawing.Size(19, 14);
            this.checkBox18.TabIndex = 145;
            this.checkBox18.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.checkBox18.UseVisualStyleBackColor = true;
            // 
            // checkBox17
            // 
            this.checkBox17.AutoSize = true;
            this.checkBox17.Dock = System.Windows.Forms.DockStyle.Fill;
            this.checkBox17.Location = new System.Drawing.Point(353, 379);
            this.checkBox17.Name = "checkBox17";
            this.checkBox17.Size = new System.Drawing.Size(19, 14);
            this.checkBox17.TabIndex = 144;
            this.checkBox17.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.checkBox17.UseVisualStyleBackColor = true;
            // 
            // checkBox16
            // 
            this.checkBox16.AutoSize = true;
            this.checkBox16.Dock = System.Windows.Forms.DockStyle.Fill;
            this.checkBox16.Location = new System.Drawing.Point(353, 357);
            this.checkBox16.Name = "checkBox16";
            this.checkBox16.Size = new System.Drawing.Size(19, 14);
            this.checkBox16.TabIndex = 143;
            this.checkBox16.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.checkBox16.UseVisualStyleBackColor = true;
            // 
            // checkBox15
            // 
            this.checkBox15.AutoSize = true;
            this.checkBox15.Dock = System.Windows.Forms.DockStyle.Fill;
            this.checkBox15.Location = new System.Drawing.Point(353, 335);
            this.checkBox15.Name = "checkBox15";
            this.checkBox15.Size = new System.Drawing.Size(19, 14);
            this.checkBox15.TabIndex = 142;
            this.checkBox15.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.checkBox15.UseVisualStyleBackColor = true;
            // 
            // checkBox14
            // 
            this.checkBox14.AutoSize = true;
            this.checkBox14.Dock = System.Windows.Forms.DockStyle.Fill;
            this.checkBox14.Location = new System.Drawing.Point(353, 313);
            this.checkBox14.Name = "checkBox14";
            this.checkBox14.Size = new System.Drawing.Size(19, 14);
            this.checkBox14.TabIndex = 141;
            this.checkBox14.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.checkBox14.UseVisualStyleBackColor = true;
            // 
            // checkBox13
            // 
            this.checkBox13.AutoSize = true;
            this.checkBox13.Dock = System.Windows.Forms.DockStyle.Fill;
            this.checkBox13.Location = new System.Drawing.Point(353, 291);
            this.checkBox13.Name = "checkBox13";
            this.checkBox13.Size = new System.Drawing.Size(19, 14);
            this.checkBox13.TabIndex = 140;
            this.checkBox13.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.checkBox13.UseVisualStyleBackColor = true;
            // 
            // checkBox12
            // 
            this.checkBox12.AutoSize = true;
            this.checkBox12.Dock = System.Windows.Forms.DockStyle.Fill;
            this.checkBox12.Location = new System.Drawing.Point(353, 269);
            this.checkBox12.Name = "checkBox12";
            this.checkBox12.Size = new System.Drawing.Size(19, 14);
            this.checkBox12.TabIndex = 139;
            this.checkBox12.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.checkBox12.UseVisualStyleBackColor = true;
            // 
            // checkBox11
            // 
            this.checkBox11.AutoSize = true;
            this.checkBox11.Dock = System.Windows.Forms.DockStyle.Fill;
            this.checkBox11.Location = new System.Drawing.Point(353, 247);
            this.checkBox11.Name = "checkBox11";
            this.checkBox11.Size = new System.Drawing.Size(19, 14);
            this.checkBox11.TabIndex = 138;
            this.checkBox11.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.checkBox11.UseVisualStyleBackColor = true;
            // 
            // checkBox10
            // 
            this.checkBox10.AutoSize = true;
            this.checkBox10.Dock = System.Windows.Forms.DockStyle.Fill;
            this.checkBox10.Location = new System.Drawing.Point(353, 225);
            this.checkBox10.Name = "checkBox10";
            this.checkBox10.Size = new System.Drawing.Size(19, 14);
            this.checkBox10.TabIndex = 137;
            this.checkBox10.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.checkBox10.UseVisualStyleBackColor = true;
            // 
            // checkBox9
            // 
            this.checkBox9.AutoSize = true;
            this.checkBox9.Dock = System.Windows.Forms.DockStyle.Fill;
            this.checkBox9.Location = new System.Drawing.Point(353, 203);
            this.checkBox9.Name = "checkBox9";
            this.checkBox9.Size = new System.Drawing.Size(19, 14);
            this.checkBox9.TabIndex = 136;
            this.checkBox9.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.checkBox9.UseVisualStyleBackColor = true;
            // 
            // checkBox8
            // 
            this.checkBox8.AutoSize = true;
            this.checkBox8.Dock = System.Windows.Forms.DockStyle.Fill;
            this.checkBox8.Location = new System.Drawing.Point(353, 181);
            this.checkBox8.Name = "checkBox8";
            this.checkBox8.Size = new System.Drawing.Size(19, 14);
            this.checkBox8.TabIndex = 135;
            this.checkBox8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.checkBox8.UseVisualStyleBackColor = true;
            // 
            // checkBox7
            // 
            this.checkBox7.AutoSize = true;
            this.checkBox7.Dock = System.Windows.Forms.DockStyle.Fill;
            this.checkBox7.Location = new System.Drawing.Point(353, 159);
            this.checkBox7.Name = "checkBox7";
            this.checkBox7.Size = new System.Drawing.Size(19, 14);
            this.checkBox7.TabIndex = 134;
            this.checkBox7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.checkBox7.UseVisualStyleBackColor = true;
            // 
            // checkBox6
            // 
            this.checkBox6.AutoSize = true;
            this.checkBox6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.checkBox6.Location = new System.Drawing.Point(353, 137);
            this.checkBox6.Name = "checkBox6";
            this.checkBox6.Size = new System.Drawing.Size(19, 14);
            this.checkBox6.TabIndex = 133;
            this.checkBox6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.checkBox6.UseVisualStyleBackColor = true;
            // 
            // checkBox5
            // 
            this.checkBox5.AutoSize = true;
            this.checkBox5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.checkBox5.Location = new System.Drawing.Point(353, 115);
            this.checkBox5.Name = "checkBox5";
            this.checkBox5.Size = new System.Drawing.Size(19, 14);
            this.checkBox5.TabIndex = 132;
            this.checkBox5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.checkBox5.UseVisualStyleBackColor = true;
            // 
            // checkBox4
            // 
            this.checkBox4.AutoSize = true;
            this.checkBox4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.checkBox4.Location = new System.Drawing.Point(353, 93);
            this.checkBox4.Name = "checkBox4";
            this.checkBox4.Size = new System.Drawing.Size(19, 14);
            this.checkBox4.TabIndex = 131;
            this.checkBox4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.checkBox4.UseVisualStyleBackColor = true;
            // 
            // checkBox3
            // 
            this.checkBox3.AutoSize = true;
            this.checkBox3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.checkBox3.Location = new System.Drawing.Point(353, 71);
            this.checkBox3.Name = "checkBox3";
            this.checkBox3.Size = new System.Drawing.Size(19, 14);
            this.checkBox3.TabIndex = 130;
            this.checkBox3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.checkBox3.UseVisualStyleBackColor = true;
            // 
            // checkBox2
            // 
            this.checkBox2.AutoSize = true;
            this.checkBox2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.checkBox2.Location = new System.Drawing.Point(353, 49);
            this.checkBox2.Name = "checkBox2";
            this.checkBox2.Size = new System.Drawing.Size(19, 14);
            this.checkBox2.TabIndex = 129;
            this.checkBox2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.checkBox2.UseVisualStyleBackColor = true;
            // 
            // linkLabel20
            // 
            this.linkLabel20.AutoSize = true;
            this.linkLabel20.Dock = System.Windows.Forms.DockStyle.Fill;
            this.linkLabel20.Location = new System.Drawing.Point(300, 442);
            this.linkLabel20.Name = "linkLabel20";
            this.linkLabel20.Size = new System.Drawing.Size(45, 20);
            this.linkLabel20.TabIndex = 126;
            this.linkLabel20.TabStop = true;
            this.linkLabel20.Text = "File";
            this.linkLabel20.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label10.Location = new System.Drawing.Point(5, 442);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(21, 20);
            this.label10.TabIndex = 125;
            this.label10.Text = "20";
            this.label10.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label21.Location = new System.Drawing.Point(34, 68);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(258, 20);
            this.label21.TabIndex = 124;
            this.label21.Text = "Proof of PhilHealth/PMRF";
            this.label21.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label22.Location = new System.Drawing.Point(34, 90);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(258, 20);
            this.label22.TabIndex = 123;
            this.label22.Text = "Proof of Pag-Ibig";
            this.label22.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label23.Location = new System.Drawing.Point(34, 112);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(258, 20);
            this.label23.TabIndex = 122;
            this.label23.Text = "2 Valid ID\'s";
            this.label23.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label24.Location = new System.Drawing.Point(34, 134);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(258, 20);
            this.label24.TabIndex = 121;
            this.label24.Text = "ID Pictures (6 pieces 1 x 1 with nameplate)";
            this.label24.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label25.Location = new System.Drawing.Point(34, 156);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(258, 20);
            this.label25.TabIndex = 120;
            this.label25.Text = "NBI Clearance (Receipt is not acceptable)";
            this.label25.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label27.Location = new System.Drawing.Point(34, 178);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(258, 20);
            this.label27.TabIndex = 119;
            this.label27.Text = "COE (Proof of Employment)";
            this.label27.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label29.Location = new System.Drawing.Point(34, 200);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(258, 20);
            this.label29.TabIndex = 118;
            this.label29.Text = "TOR/Diploma (School Records)";
            this.label29.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label31.Location = new System.Drawing.Point(34, 222);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(258, 20);
            this.label31.TabIndex = 117;
            this.label31.Text = "NSO Birth Certificate (4 copies)";
            this.label31.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label33.Location = new System.Drawing.Point(34, 244);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(258, 20);
            this.label33.TabIndex = 116;
            this.label33.Text = "New Hire Acknowledgement";
            this.label33.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label35.Location = new System.Drawing.Point(34, 266);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(258, 20);
            this.label35.TabIndex = 115;
            this.label35.Text = "NDA";
            this.label35.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label37.Location = new System.Drawing.Point(34, 288);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(258, 20);
            this.label37.TabIndex = 114;
            this.label37.Text = "Interview/Assesment Docs";
            this.label37.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label39.Location = new System.Drawing.Point(34, 310);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(258, 20);
            this.label39.TabIndex = 113;
            this.label39.Text = "Resume/CV";
            this.label39.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label41.Location = new System.Drawing.Point(34, 332);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(258, 20);
            this.label41.TabIndex = 112;
            this.label41.Text = "Background Investigation Check Form";
            this.label41.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label43
            // 
            this.label43.AutoSize = true;
            this.label43.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label43.Location = new System.Drawing.Point(34, 354);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(258, 20);
            this.label43.TabIndex = 111;
            this.label43.Text = "Background Investigation Result";
            this.label43.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label45
            // 
            this.label45.AutoSize = true;
            this.label45.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label45.Location = new System.Drawing.Point(34, 376);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(258, 20);
            this.label45.TabIndex = 110;
            this.label45.Text = "Employee Information Form";
            this.label45.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label47
            // 
            this.label47.AutoSize = true;
            this.label47.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label47.Location = new System.Drawing.Point(34, 398);
            this.label47.Name = "label47";
            this.label47.Size = new System.Drawing.Size(258, 20);
            this.label47.TabIndex = 108;
            this.label47.Text = "Job Description";
            this.label47.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label49
            // 
            this.label49.AutoSize = true;
            this.label49.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label49.Location = new System.Drawing.Point(34, 420);
            this.label49.Name = "label49";
            this.label49.Size = new System.Drawing.Size(258, 20);
            this.label49.TabIndex = 107;
            this.label49.Text = "Employee Contract";
            this.label49.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label51
            // 
            this.label51.AutoSize = true;
            this.label51.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label51.Location = new System.Drawing.Point(34, 442);
            this.label51.Name = "label51";
            this.label51.Size = new System.Drawing.Size(258, 20);
            this.label51.TabIndex = 106;
            this.label51.Text = "PEME Slip";
            this.label51.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // linkLabel19
            // 
            this.linkLabel19.AutoSize = true;
            this.linkLabel19.Dock = System.Windows.Forms.DockStyle.Fill;
            this.linkLabel19.Location = new System.Drawing.Point(300, 420);
            this.linkLabel19.Name = "linkLabel19";
            this.linkLabel19.Size = new System.Drawing.Size(45, 20);
            this.linkLabel19.TabIndex = 100;
            this.linkLabel19.TabStop = true;
            this.linkLabel19.Text = "File";
            this.linkLabel19.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // linkLabel18
            // 
            this.linkLabel18.AutoSize = true;
            this.linkLabel18.Dock = System.Windows.Forms.DockStyle.Fill;
            this.linkLabel18.Location = new System.Drawing.Point(300, 398);
            this.linkLabel18.Name = "linkLabel18";
            this.linkLabel18.Size = new System.Drawing.Size(45, 20);
            this.linkLabel18.TabIndex = 99;
            this.linkLabel18.TabStop = true;
            this.linkLabel18.Text = "File";
            this.linkLabel18.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // linkLabel17
            // 
            this.linkLabel17.AutoSize = true;
            this.linkLabel17.Dock = System.Windows.Forms.DockStyle.Fill;
            this.linkLabel17.Location = new System.Drawing.Point(300, 376);
            this.linkLabel17.Name = "linkLabel17";
            this.linkLabel17.Size = new System.Drawing.Size(45, 20);
            this.linkLabel17.TabIndex = 98;
            this.linkLabel17.TabStop = true;
            this.linkLabel17.Text = "File";
            this.linkLabel17.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // linkLabel16
            // 
            this.linkLabel16.AutoSize = true;
            this.linkLabel16.Dock = System.Windows.Forms.DockStyle.Fill;
            this.linkLabel16.Location = new System.Drawing.Point(300, 354);
            this.linkLabel16.Name = "linkLabel16";
            this.linkLabel16.Size = new System.Drawing.Size(45, 20);
            this.linkLabel16.TabIndex = 97;
            this.linkLabel16.TabStop = true;
            this.linkLabel16.Text = "File";
            this.linkLabel16.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // linkLabel15
            // 
            this.linkLabel15.AutoSize = true;
            this.linkLabel15.Dock = System.Windows.Forms.DockStyle.Fill;
            this.linkLabel15.Location = new System.Drawing.Point(300, 332);
            this.linkLabel15.Name = "linkLabel15";
            this.linkLabel15.Size = new System.Drawing.Size(45, 20);
            this.linkLabel15.TabIndex = 96;
            this.linkLabel15.TabStop = true;
            this.linkLabel15.Text = "File";
            this.linkLabel15.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // linkLabel14
            // 
            this.linkLabel14.AutoSize = true;
            this.linkLabel14.Dock = System.Windows.Forms.DockStyle.Fill;
            this.linkLabel14.Location = new System.Drawing.Point(300, 310);
            this.linkLabel14.Name = "linkLabel14";
            this.linkLabel14.Size = new System.Drawing.Size(45, 20);
            this.linkLabel14.TabIndex = 95;
            this.linkLabel14.TabStop = true;
            this.linkLabel14.Text = "File";
            this.linkLabel14.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // linkLabel13
            // 
            this.linkLabel13.AutoSize = true;
            this.linkLabel13.Dock = System.Windows.Forms.DockStyle.Fill;
            this.linkLabel13.Location = new System.Drawing.Point(300, 288);
            this.linkLabel13.Name = "linkLabel13";
            this.linkLabel13.Size = new System.Drawing.Size(45, 20);
            this.linkLabel13.TabIndex = 94;
            this.linkLabel13.TabStop = true;
            this.linkLabel13.Text = "File";
            this.linkLabel13.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // linkLabel12
            // 
            this.linkLabel12.AutoSize = true;
            this.linkLabel12.Dock = System.Windows.Forms.DockStyle.Fill;
            this.linkLabel12.Location = new System.Drawing.Point(300, 266);
            this.linkLabel12.Name = "linkLabel12";
            this.linkLabel12.Size = new System.Drawing.Size(45, 20);
            this.linkLabel12.TabIndex = 93;
            this.linkLabel12.TabStop = true;
            this.linkLabel12.Text = "File";
            this.linkLabel12.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // linkLabel11
            // 
            this.linkLabel11.AutoSize = true;
            this.linkLabel11.Dock = System.Windows.Forms.DockStyle.Fill;
            this.linkLabel11.Location = new System.Drawing.Point(300, 244);
            this.linkLabel11.Name = "linkLabel11";
            this.linkLabel11.Size = new System.Drawing.Size(45, 20);
            this.linkLabel11.TabIndex = 92;
            this.linkLabel11.TabStop = true;
            this.linkLabel11.Text = "File";
            this.linkLabel11.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // linkLabel10
            // 
            this.linkLabel10.AutoSize = true;
            this.linkLabel10.Dock = System.Windows.Forms.DockStyle.Fill;
            this.linkLabel10.Location = new System.Drawing.Point(300, 222);
            this.linkLabel10.Name = "linkLabel10";
            this.linkLabel10.Size = new System.Drawing.Size(45, 20);
            this.linkLabel10.TabIndex = 91;
            this.linkLabel10.TabStop = true;
            this.linkLabel10.Text = "File";
            this.linkLabel10.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // linkLabel9
            // 
            this.linkLabel9.AutoSize = true;
            this.linkLabel9.Dock = System.Windows.Forms.DockStyle.Fill;
            this.linkLabel9.Location = new System.Drawing.Point(300, 200);
            this.linkLabel9.Name = "linkLabel9";
            this.linkLabel9.Size = new System.Drawing.Size(45, 20);
            this.linkLabel9.TabIndex = 90;
            this.linkLabel9.TabStop = true;
            this.linkLabel9.Text = "File";
            this.linkLabel9.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // linkLabel8
            // 
            this.linkLabel8.AutoSize = true;
            this.linkLabel8.Dock = System.Windows.Forms.DockStyle.Fill;
            this.linkLabel8.Location = new System.Drawing.Point(300, 178);
            this.linkLabel8.Name = "linkLabel8";
            this.linkLabel8.Size = new System.Drawing.Size(45, 20);
            this.linkLabel8.TabIndex = 89;
            this.linkLabel8.TabStop = true;
            this.linkLabel8.Text = "File";
            this.linkLabel8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // linkLabel7
            // 
            this.linkLabel7.AutoSize = true;
            this.linkLabel7.Dock = System.Windows.Forms.DockStyle.Fill;
            this.linkLabel7.Location = new System.Drawing.Point(300, 156);
            this.linkLabel7.Name = "linkLabel7";
            this.linkLabel7.Size = new System.Drawing.Size(45, 20);
            this.linkLabel7.TabIndex = 88;
            this.linkLabel7.TabStop = true;
            this.linkLabel7.Text = "File";
            this.linkLabel7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // linkLabel6
            // 
            this.linkLabel6.AutoSize = true;
            this.linkLabel6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.linkLabel6.Location = new System.Drawing.Point(300, 134);
            this.linkLabel6.Name = "linkLabel6";
            this.linkLabel6.Size = new System.Drawing.Size(45, 20);
            this.linkLabel6.TabIndex = 87;
            this.linkLabel6.TabStop = true;
            this.linkLabel6.Text = "File";
            this.linkLabel6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // linkLabel5
            // 
            this.linkLabel5.AutoSize = true;
            this.linkLabel5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.linkLabel5.Location = new System.Drawing.Point(300, 112);
            this.linkLabel5.Name = "linkLabel5";
            this.linkLabel5.Size = new System.Drawing.Size(45, 20);
            this.linkLabel5.TabIndex = 86;
            this.linkLabel5.TabStop = true;
            this.linkLabel5.Text = "File";
            this.linkLabel5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // linkLabel4
            // 
            this.linkLabel4.AutoSize = true;
            this.linkLabel4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.linkLabel4.Location = new System.Drawing.Point(300, 90);
            this.linkLabel4.Name = "linkLabel4";
            this.linkLabel4.Size = new System.Drawing.Size(45, 20);
            this.linkLabel4.TabIndex = 85;
            this.linkLabel4.TabStop = true;
            this.linkLabel4.Text = "File";
            this.linkLabel4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // linkLabel3
            // 
            this.linkLabel3.AutoSize = true;
            this.linkLabel3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.linkLabel3.Location = new System.Drawing.Point(300, 68);
            this.linkLabel3.Name = "linkLabel3";
            this.linkLabel3.Size = new System.Drawing.Size(45, 20);
            this.linkLabel3.TabIndex = 84;
            this.linkLabel3.TabStop = true;
            this.linkLabel3.Text = "File";
            this.linkLabel3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // linkLabel2
            // 
            this.linkLabel2.AutoSize = true;
            this.linkLabel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.linkLabel2.Location = new System.Drawing.Point(300, 46);
            this.linkLabel2.Name = "linkLabel2";
            this.linkLabel2.Size = new System.Drawing.Size(45, 20);
            this.linkLabel2.TabIndex = 83;
            this.linkLabel2.TabStop = true;
            this.linkLabel2.Text = "File";
            this.linkLabel2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label48
            // 
            this.label48.AutoSize = true;
            this.label48.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label48.Location = new System.Drawing.Point(5, 420);
            this.label48.Name = "label48";
            this.label48.Size = new System.Drawing.Size(21, 20);
            this.label48.TabIndex = 80;
            this.label48.Text = "19";
            this.label48.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label46
            // 
            this.label46.AutoSize = true;
            this.label46.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label46.Location = new System.Drawing.Point(5, 398);
            this.label46.Name = "label46";
            this.label46.Size = new System.Drawing.Size(21, 20);
            this.label46.TabIndex = 78;
            this.label46.Text = "18";
            this.label46.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.label44.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label44.Location = new System.Drawing.Point(5, 376);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(21, 20);
            this.label44.TabIndex = 76;
            this.label44.Text = "17";
            this.label44.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label42
            // 
            this.label42.AutoSize = true;
            this.label42.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label42.Location = new System.Drawing.Point(5, 354);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(21, 20);
            this.label42.TabIndex = 74;
            this.label42.Text = "16";
            this.label42.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label40.Location = new System.Drawing.Point(5, 332);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(21, 20);
            this.label40.TabIndex = 72;
            this.label40.Text = "15";
            this.label40.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label38.Location = new System.Drawing.Point(5, 310);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(21, 20);
            this.label38.TabIndex = 70;
            this.label38.Text = "14";
            this.label38.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label36.Location = new System.Drawing.Point(5, 288);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(21, 20);
            this.label36.TabIndex = 68;
            this.label36.Text = "13";
            this.label36.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label34.Location = new System.Drawing.Point(5, 266);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(21, 20);
            this.label34.TabIndex = 66;
            this.label34.Text = "12";
            this.label34.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label32.Location = new System.Drawing.Point(5, 244);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(21, 20);
            this.label32.TabIndex = 64;
            this.label32.Text = "11";
            this.label32.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label30.Location = new System.Drawing.Point(5, 222);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(21, 20);
            this.label30.TabIndex = 62;
            this.label30.Text = "10";
            this.label30.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label28.Location = new System.Drawing.Point(5, 200);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(21, 20);
            this.label28.TabIndex = 60;
            this.label28.Text = "9";
            this.label28.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label26.Location = new System.Drawing.Point(5, 178);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(21, 20);
            this.label26.TabIndex = 58;
            this.label26.Text = "8";
            this.label26.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label20.Location = new System.Drawing.Point(34, 46);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(258, 20);
            this.label20.TabIndex = 52;
            this.label20.Text = "Proof of SSS";
            this.label20.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label18.Location = new System.Drawing.Point(34, 24);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(258, 20);
            this.label18.TabIndex = 51;
            this.label18.Text = "Proof of TIN/BIR 1902";
            this.label18.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.label14.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label14.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(297, 2);
            this.label14.Margin = new System.Windows.Forms.Padding(0);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(51, 20);
            this.label14.TabIndex = 2;
            this.label14.Text = "@@";
            this.label14.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.label19.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label19.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.Location = new System.Drawing.Point(2, 2);
            this.label19.Margin = new System.Windows.Forms.Padding(0);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(27, 20);
            this.label19.TabIndex = 1;
            this.label19.Text = "#";
            this.label19.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label50
            // 
            this.label50.AutoSize = true;
            this.label50.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.label50.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label50.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label50.Location = new System.Drawing.Point(31, 2);
            this.label50.Margin = new System.Windows.Forms.Padding(0);
            this.label50.Name = "label50";
            this.label50.Size = new System.Drawing.Size(264, 20);
            this.label50.TabIndex = 0;
            this.label50.Text = "Primary Requirements";
            this.label50.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label52
            // 
            this.label52.AutoSize = true;
            this.label52.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label52.Location = new System.Drawing.Point(5, 24);
            this.label52.Name = "label52";
            this.label52.Size = new System.Drawing.Size(21, 20);
            this.label52.TabIndex = 44;
            this.label52.Text = "1";
            this.label52.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label53
            // 
            this.label53.AutoSize = true;
            this.label53.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label53.Location = new System.Drawing.Point(5, 46);
            this.label53.Name = "label53";
            this.label53.Size = new System.Drawing.Size(21, 20);
            this.label53.TabIndex = 45;
            this.label53.Text = "2";
            this.label53.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label54
            // 
            this.label54.AutoSize = true;
            this.label54.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label54.Location = new System.Drawing.Point(5, 68);
            this.label54.Name = "label54";
            this.label54.Size = new System.Drawing.Size(21, 20);
            this.label54.TabIndex = 46;
            this.label54.Text = "3";
            this.label54.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label55
            // 
            this.label55.AutoSize = true;
            this.label55.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label55.Location = new System.Drawing.Point(5, 90);
            this.label55.Name = "label55";
            this.label55.Size = new System.Drawing.Size(21, 20);
            this.label55.TabIndex = 47;
            this.label55.Text = "4";
            this.label55.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label56
            // 
            this.label56.AutoSize = true;
            this.label56.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label56.Location = new System.Drawing.Point(5, 112);
            this.label56.Name = "label56";
            this.label56.Size = new System.Drawing.Size(21, 20);
            this.label56.TabIndex = 48;
            this.label56.Text = "5";
            this.label56.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label57
            // 
            this.label57.AutoSize = true;
            this.label57.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label57.Location = new System.Drawing.Point(5, 134);
            this.label57.Name = "label57";
            this.label57.Size = new System.Drawing.Size(21, 20);
            this.label57.TabIndex = 49;
            this.label57.Text = "6";
            this.label57.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label58
            // 
            this.label58.AutoSize = true;
            this.label58.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label58.Location = new System.Drawing.Point(5, 156);
            this.label58.Name = "label58";
            this.label58.Size = new System.Drawing.Size(21, 20);
            this.label58.TabIndex = 50;
            this.label58.Text = "7";
            this.label58.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // linkLabel1
            // 
            this.linkLabel1.AutoSize = true;
            this.linkLabel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.linkLabel1.Location = new System.Drawing.Point(300, 24);
            this.linkLabel1.Name = "linkLabel1";
            this.linkLabel1.Size = new System.Drawing.Size(45, 20);
            this.linkLabel1.TabIndex = 82;
            this.linkLabel1.TabStop = true;
            this.linkLabel1.Text = "File";
            this.linkLabel1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // checkBox1
            // 
            this.checkBox1.AutoSize = true;
            this.checkBox1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.checkBox1.Location = new System.Drawing.Point(353, 27);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Size = new System.Drawing.Size(19, 14);
            this.checkBox1.TabIndex = 128;
            this.checkBox1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.checkBox1.UseVisualStyleBackColor = true;
            // 
            // gbxAppInfo
            // 
            this.gbxAppInfo.Controls.Add(this.applicantInfo);
            this.gbxAppInfo.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gbxAppInfo.Location = new System.Drawing.Point(28, 18);
            this.gbxAppInfo.Name = "gbxAppInfo";
            this.gbxAppInfo.Size = new System.Drawing.Size(770, 202);
            this.gbxAppInfo.TabIndex = 4;
            this.gbxAppInfo.TabStop = false;
            this.gbxAppInfo.Text = "Info";
            // 
            // applicantInfo
            // 
            this.applicantInfo.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Inset;
            this.applicantInfo.ColumnCount = 2;
            this.applicantInfo.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 22.39221F));
            this.applicantInfo.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 77.60779F));
            this.applicantInfo.Controls.Add(this.label9, 0, 6);
            this.applicantInfo.Controls.Add(this.label8, 0, 6);
            this.applicantInfo.Controls.Add(this.label2, 0, 0);
            this.applicantInfo.Controls.Add(this.label3, 0, 1);
            this.applicantInfo.Controls.Add(this.label4, 0, 2);
            this.applicantInfo.Controls.Add(this.label5, 0, 3);
            this.applicantInfo.Controls.Add(this.label6, 0, 4);
            this.applicantInfo.Controls.Add(this.label7, 0, 5);
            this.applicantInfo.Controls.Add(this.label11, 1, 0);
            this.applicantInfo.Controls.Add(this.label12, 1, 1);
            this.applicantInfo.Controls.Add(this.label13, 1, 2);
            this.applicantInfo.Controls.Add(this.label15, 1, 3);
            this.applicantInfo.Controls.Add(this.label16, 1, 4);
            this.applicantInfo.Controls.Add(this.label17, 1, 5);
            this.applicantInfo.Location = new System.Drawing.Point(25, 24);
            this.applicantInfo.Margin = new System.Windows.Forms.Padding(1);
            this.applicantInfo.Name = "applicantInfo";
            this.applicantInfo.RowCount = 7;
            this.applicantInfo.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.applicantInfo.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.applicantInfo.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.applicantInfo.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.applicantInfo.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.applicantInfo.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.applicantInfo.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.applicantInfo.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.applicantInfo.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.applicantInfo.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.applicantInfo.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.applicantInfo.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.applicantInfo.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.applicantInfo.Size = new System.Drawing.Size(721, 156);
            this.applicantInfo.TabIndex = 0;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label9.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(5, 134);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(154, 20);
            this.label9.TabIndex = 67;
            this.label9.Text = "Pag-Ibig:";
            this.label9.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.BackColor = System.Drawing.Color.White;
            this.label8.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label8.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(164, 134);
            this.label8.Margin = new System.Windows.Forms.Padding(0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(555, 20);
            this.label8.TabIndex = 66;
            this.label8.Text = "<----->";
            this.label8.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label2.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(5, 2);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(154, 20);
            this.label2.TabIndex = 51;
            this.label2.Text = "Employee ID:";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label3.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(5, 24);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(154, 20);
            this.label3.TabIndex = 52;
            this.label3.Text = "Employee Name:";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label4.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(5, 46);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(154, 20);
            this.label4.TabIndex = 53;
            this.label4.Text = "Date of Hire:";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label5.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(5, 68);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(154, 20);
            this.label5.TabIndex = 54;
            this.label5.Text = "Program:";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label6.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(5, 90);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(154, 20);
            this.label6.TabIndex = 55;
            this.label6.Text = "SSS:";
            this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label7.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(5, 112);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(154, 20);
            this.label7.TabIndex = 56;
            this.label7.Text = "TIN:";
            this.label7.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.BackColor = System.Drawing.Color.White;
            this.label11.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label11.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(164, 2);
            this.label11.Margin = new System.Windows.Forms.Padding(0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(555, 20);
            this.label11.TabIndex = 60;
            this.label11.Text = "<----->";
            this.label11.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.BackColor = System.Drawing.Color.White;
            this.label12.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label12.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(164, 24);
            this.label12.Margin = new System.Windows.Forms.Padding(0);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(555, 20);
            this.label12.TabIndex = 61;
            this.label12.Text = "<----->";
            this.label12.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.BackColor = System.Drawing.Color.White;
            this.label13.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label13.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(164, 46);
            this.label13.Margin = new System.Windows.Forms.Padding(0);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(555, 20);
            this.label13.TabIndex = 62;
            this.label13.Text = "<----->";
            this.label13.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.BackColor = System.Drawing.Color.White;
            this.label15.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label15.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(164, 68);
            this.label15.Margin = new System.Windows.Forms.Padding(0);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(555, 20);
            this.label15.TabIndex = 63;
            this.label15.Text = "<----->";
            this.label15.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.BackColor = System.Drawing.Color.White;
            this.label16.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label16.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(164, 90);
            this.label16.Margin = new System.Windows.Forms.Padding(0);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(555, 20);
            this.label16.TabIndex = 64;
            this.label16.Text = "<----->";
            this.label16.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.BackColor = System.Drawing.Color.White;
            this.label17.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label17.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.Location = new System.Drawing.Point(164, 112);
            this.label17.Margin = new System.Windows.Forms.Padding(0);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(555, 20);
            this.label17.TabIndex = 65;
            this.label17.Text = "<----->";
            this.label17.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.panel4.Controls.Add(this.label1);
            this.panel4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel4.Location = new System.Drawing.Point(4, 4);
            this.panel4.Margin = new System.Windows.Forms.Padding(1);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(1067, 23);
            this.panel4.TabIndex = 2;
            // 
            // label1
            // 
            this.label1.BackColor = System.Drawing.Color.Teal;
            this.label1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(0, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(1067, 23);
            this.label1.TabIndex = 1;
            this.label1.Text = "Employee PER Checklist";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // contextMenuStrip
            // 
            this.contextMenuStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.checklistToolStripMenuItem});
            this.contextMenuStrip.Name = "contextMenuStrip";
            this.contextMenuStrip.Size = new System.Drawing.Size(123, 26);
            // 
            // checklistToolStripMenuItem
            // 
            this.checklistToolStripMenuItem.Name = "checklistToolStripMenuItem";
            this.checklistToolStripMenuItem.Size = new System.Drawing.Size(122, 22);
            this.checklistToolStripMenuItem.Text = "Checklist";
            // 
            // PERChecklist
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.tableLayoutPanel1);
            this.Name = "PERChecklist";
            this.Size = new System.Drawing.Size(1075, 400);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.tableLayoutPanel3.ResumeLayout(false);
            this.tableLayoutPanel3.PerformLayout();
            this.tableLayoutPanel2.ResumeLayout(false);
            this.tableLayoutPanel2.PerformLayout();
            this.gbxAppInfo.ResumeLayout(false);
            this.applicantInfo.ResumeLayout(false);
            this.applicantInfo.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.contextMenuStrip.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip;
        private System.Windows.Forms.ToolStripMenuItem checklistToolStripMenuItem;
        private System.Windows.Forms.GroupBox gbxAppInfo;
        private System.Windows.Forms.TableLayoutPanel applicantInfo;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel2;
        private System.Windows.Forms.CheckBox checkAll1;
        private System.Windows.Forms.CheckBox checkBox20;
        private System.Windows.Forms.CheckBox checkBox19;
        private System.Windows.Forms.CheckBox checkBox18;
        private System.Windows.Forms.CheckBox checkBox17;
        private System.Windows.Forms.CheckBox checkBox16;
        private System.Windows.Forms.CheckBox checkBox15;
        private System.Windows.Forms.CheckBox checkBox14;
        private System.Windows.Forms.CheckBox checkBox13;
        private System.Windows.Forms.CheckBox checkBox12;
        private System.Windows.Forms.CheckBox checkBox11;
        private System.Windows.Forms.CheckBox checkBox10;
        private System.Windows.Forms.CheckBox checkBox9;
        private System.Windows.Forms.CheckBox checkBox8;
        private System.Windows.Forms.CheckBox checkBox7;
        private System.Windows.Forms.CheckBox checkBox6;
        private System.Windows.Forms.CheckBox checkBox5;
        private System.Windows.Forms.CheckBox checkBox4;
        private System.Windows.Forms.CheckBox checkBox3;
        private System.Windows.Forms.CheckBox checkBox2;
        private System.Windows.Forms.LinkLabel linkLabel20;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.Label label45;
        private System.Windows.Forms.Label label47;
        private System.Windows.Forms.Label label49;
        private System.Windows.Forms.Label label51;
        private System.Windows.Forms.LinkLabel linkLabel19;
        private System.Windows.Forms.LinkLabel linkLabel18;
        private System.Windows.Forms.LinkLabel linkLabel17;
        private System.Windows.Forms.LinkLabel linkLabel16;
        private System.Windows.Forms.LinkLabel linkLabel15;
        private System.Windows.Forms.LinkLabel linkLabel14;
        private System.Windows.Forms.LinkLabel linkLabel13;
        private System.Windows.Forms.LinkLabel linkLabel12;
        private System.Windows.Forms.LinkLabel linkLabel11;
        private System.Windows.Forms.LinkLabel linkLabel10;
        private System.Windows.Forms.LinkLabel linkLabel9;
        private System.Windows.Forms.LinkLabel linkLabel8;
        private System.Windows.Forms.LinkLabel linkLabel7;
        private System.Windows.Forms.LinkLabel linkLabel6;
        private System.Windows.Forms.LinkLabel linkLabel5;
        private System.Windows.Forms.LinkLabel linkLabel4;
        private System.Windows.Forms.LinkLabel linkLabel3;
        private System.Windows.Forms.LinkLabel linkLabel2;
        private System.Windows.Forms.Label label48;
        private System.Windows.Forms.Label label46;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label50;
        private System.Windows.Forms.Label label52;
        private System.Windows.Forms.Label label53;
        private System.Windows.Forms.Label label54;
        private System.Windows.Forms.Label label55;
        private System.Windows.Forms.Label label56;
        private System.Windows.Forms.Label label57;
        private System.Windows.Forms.Label label58;
        private System.Windows.Forms.LinkLabel linkLabel1;
        private System.Windows.Forms.CheckBox checkBox1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel3;
        private System.Windows.Forms.CheckBox checkAll2;
        private System.Windows.Forms.LinkLabel linkLabel21;
        private System.Windows.Forms.CheckBox checkBox38;
        private System.Windows.Forms.CheckBox checkBox37;
        private System.Windows.Forms.CheckBox checkBox36;
        private System.Windows.Forms.CheckBox checkBox35;
        private System.Windows.Forms.CheckBox checkBox34;
        private System.Windows.Forms.CheckBox checkBox33;
        private System.Windows.Forms.CheckBox checkBox32;
        private System.Windows.Forms.CheckBox checkBox31;
        private System.Windows.Forms.CheckBox checkBox30;
        private System.Windows.Forms.CheckBox checkBox29;
        private System.Windows.Forms.CheckBox checkBox28;
        private System.Windows.Forms.CheckBox checkBox27;
        private System.Windows.Forms.CheckBox checkBox26;
        private System.Windows.Forms.CheckBox checkBox25;
        private System.Windows.Forms.CheckBox checkBox24;
        private System.Windows.Forms.CheckBox checkBox23;
        private System.Windows.Forms.CheckBox checkBox22;
        private System.Windows.Forms.CheckBox checkBox21;
        private System.Windows.Forms.Label label84;
        private System.Windows.Forms.Label label59;
        private System.Windows.Forms.LinkLabel linkLabel38;
        private System.Windows.Forms.LinkLabel linkLabel37;
        private System.Windows.Forms.LinkLabel linkLabel36;
        private System.Windows.Forms.LinkLabel linkLabel35;
        private System.Windows.Forms.LinkLabel linkLabel34;
        private System.Windows.Forms.LinkLabel linkLabel33;
        private System.Windows.Forms.LinkLabel linkLabel32;
        private System.Windows.Forms.LinkLabel linkLabel31;
        private System.Windows.Forms.LinkLabel linkLabel30;
        private System.Windows.Forms.LinkLabel linkLabel29;
        private System.Windows.Forms.LinkLabel linkLabel28;
        private System.Windows.Forms.LinkLabel linkLabel27;
        private System.Windows.Forms.LinkLabel linkLabel26;
        private System.Windows.Forms.LinkLabel linkLabel25;
        private System.Windows.Forms.LinkLabel linkLabel24;
        private System.Windows.Forms.LinkLabel linkLabel23;
        private System.Windows.Forms.Label label60;
        private System.Windows.Forms.Label label61;
        private System.Windows.Forms.Label label62;
        private System.Windows.Forms.Label label63;
        private System.Windows.Forms.Label label64;
        private System.Windows.Forms.Label label65;
        private System.Windows.Forms.Label label66;
        private System.Windows.Forms.Label label67;
        private System.Windows.Forms.Label label68;
        private System.Windows.Forms.Label label69;
        private System.Windows.Forms.Label label70;
        private System.Windows.Forms.Label label71;
        private System.Windows.Forms.Label label72;
        private System.Windows.Forms.Label label73;
        private System.Windows.Forms.Label label74;
        private System.Windows.Forms.Label label75;
        private System.Windows.Forms.Label label76;
        private System.Windows.Forms.Label label77;
        private System.Windows.Forms.Label label78;
        private System.Windows.Forms.Label label79;
        private System.Windows.Forms.Label label80;
        private System.Windows.Forms.Label label81;
        private System.Windows.Forms.Label label82;
        private System.Windows.Forms.Label label83;
        private System.Windows.Forms.Label label85;
        private System.Windows.Forms.Label label86;
        private System.Windows.Forms.Label label87;
        private System.Windows.Forms.Label label88;
        private System.Windows.Forms.Label label89;
        private System.Windows.Forms.Label label90;
        private System.Windows.Forms.Label label91;
        private System.Windows.Forms.Label label92;
        private System.Windows.Forms.Label label93;
        private System.Windows.Forms.Label label94;
        private System.Windows.Forms.Label label95;
        private System.Windows.Forms.Label label96;
        private System.Windows.Forms.Label label97;
        private System.Windows.Forms.LinkLabel linkLabel22;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button btnRegister;
    }
}
