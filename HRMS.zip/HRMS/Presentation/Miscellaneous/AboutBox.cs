﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Linq;
using System.Reflection;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Presentation.Miscellaneous
{
    partial class AboutBox : Form
    {
        public AboutBox()
        {
            InitializeComponent();
        }
    }
}
