﻿namespace Presentation.DialogBox
{
    partial class EvaluateApplicant
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.gbxAppInfo = new System.Windows.Forms.GroupBox();
            this.applicantInfo = new System.Windows.Forms.TableLayoutPanel();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.tableLayoutPanel3 = new System.Windows.Forms.TableLayoutPanel();
            this.comboBox7 = new System.Windows.Forms.ComboBox();
            this.comboBox6 = new System.Windows.Forms.ComboBox();
            this.comboBox5 = new System.Windows.Forms.ComboBox();
            this.comboBox4 = new System.Windows.Forms.ComboBox();
            this.comboBox3 = new System.Windows.Forms.ComboBox();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.label33 = new System.Windows.Forms.Label();
            this.label34 = new System.Windows.Forms.Label();
            this.label36 = new System.Windows.Forms.Label();
            this.label37 = new System.Windows.Forms.Label();
            this.label38 = new System.Windows.Forms.Label();
            this.comboBox2 = new System.Windows.Forms.ComboBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.btnCancel1 = new System.Windows.Forms.Button();
            this.btnNext = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.button4 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.comboBox30 = new System.Windows.Forms.ComboBox();
            this.label32 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.comboBox29 = new System.Windows.Forms.ComboBox();
            this.label30 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.comboBox28 = new System.Windows.Forms.ComboBox();
            this.label28 = new System.Windows.Forms.Label();
            this.comboBox27 = new System.Windows.Forms.ComboBox();
            this.label27 = new System.Windows.Forms.Label();
            this.comboBox26 = new System.Windows.Forms.ComboBox();
            this.label26 = new System.Windows.Forms.Label();
            this.comboBox25 = new System.Windows.Forms.ComboBox();
            this.label7 = new System.Windows.Forms.Label();
            this.comboBox24 = new System.Windows.Forms.ComboBox();
            this.label24 = new System.Windows.Forms.Label();
            this.comboBox23 = new System.Windows.Forms.ComboBox();
            this.label23 = new System.Windows.Forms.Label();
            this.comboBox22 = new System.Windows.Forms.ComboBox();
            this.label22 = new System.Windows.Forms.Label();
            this.comboBox21 = new System.Windows.Forms.ComboBox();
            this.label21 = new System.Windows.Forms.Label();
            this.comboBox20 = new System.Windows.Forms.ComboBox();
            this.label20 = new System.Windows.Forms.Label();
            this.comboBox19 = new System.Windows.Forms.ComboBox();
            this.label19 = new System.Windows.Forms.Label();
            this.comboBox18 = new System.Windows.Forms.ComboBox();
            this.label18 = new System.Windows.Forms.Label();
            this.comboBox17 = new System.Windows.Forms.ComboBox();
            this.label17 = new System.Windows.Forms.Label();
            this.comboBox16 = new System.Windows.Forms.ComboBox();
            this.label16 = new System.Windows.Forms.Label();
            this.comboBox15 = new System.Windows.Forms.ComboBox();
            this.label15 = new System.Windows.Forms.Label();
            this.comboBox14 = new System.Windows.Forms.ComboBox();
            this.label14 = new System.Windows.Forms.Label();
            this.comboBox13 = new System.Windows.Forms.ComboBox();
            this.label8 = new System.Windows.Forms.Label();
            this.comboBox12 = new System.Windows.Forms.ComboBox();
            this.label9 = new System.Windows.Forms.Label();
            this.comboBox11 = new System.Windows.Forms.ComboBox();
            this.comboBox10 = new System.Windows.Forms.ComboBox();
            this.comboBox9 = new System.Windows.Forms.ComboBox();
            this.comboBox8 = new System.Windows.Forms.ComboBox();
            this.btnReset = new System.Windows.Forms.Button();
            this.btnBack = new System.Windows.Forms.Button();
            this.gbxAppInfo.SuspendLayout();
            this.applicantInfo.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.tableLayoutPanel3.SuspendLayout();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.tableLayoutPanel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // gbxAppInfo
            // 
            this.gbxAppInfo.Controls.Add(this.applicantInfo);
            this.gbxAppInfo.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gbxAppInfo.Location = new System.Drawing.Point(12, 12);
            this.gbxAppInfo.Name = "gbxAppInfo";
            this.gbxAppInfo.Size = new System.Drawing.Size(498, 111);
            this.gbxAppInfo.TabIndex = 3;
            this.gbxAppInfo.TabStop = false;
            this.gbxAppInfo.Text = "Info";
            // 
            // applicantInfo
            // 
            this.applicantInfo.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Inset;
            this.applicantInfo.ColumnCount = 2;
            this.applicantInfo.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 36.0179F));
            this.applicantInfo.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 63.9821F));
            this.applicantInfo.Controls.Add(this.label1, 0, 0);
            this.applicantInfo.Controls.Add(this.label2, 0, 1);
            this.applicantInfo.Controls.Add(this.label3, 0, 2);
            this.applicantInfo.Controls.Add(this.label11, 1, 0);
            this.applicantInfo.Controls.Add(this.label12, 1, 1);
            this.applicantInfo.Controls.Add(this.label13, 1, 2);
            this.applicantInfo.Location = new System.Drawing.Point(25, 24);
            this.applicantInfo.Margin = new System.Windows.Forms.Padding(1);
            this.applicantInfo.Name = "applicantInfo";
            this.applicantInfo.RowCount = 3;
            this.applicantInfo.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.applicantInfo.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.applicantInfo.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.applicantInfo.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.applicantInfo.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.applicantInfo.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.applicantInfo.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.applicantInfo.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.applicantInfo.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.applicantInfo.Size = new System.Drawing.Size(448, 68);
            this.applicantInfo.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(5, 2);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(153, 20);
            this.label1.TabIndex = 51;
            this.label1.Text = "Name:";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label2.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(5, 24);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(153, 20);
            this.label2.TabIndex = 52;
            this.label2.Text = "Application Date:";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label3.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(5, 46);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(153, 20);
            this.label3.TabIndex = 53;
            this.label3.Text = "Gender:";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.BackColor = System.Drawing.Color.White;
            this.label11.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label11.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(163, 2);
            this.label11.Margin = new System.Windows.Forms.Padding(0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(283, 20);
            this.label11.TabIndex = 60;
            this.label11.Text = "<----->";
            this.label11.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.BackColor = System.Drawing.Color.White;
            this.label12.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label12.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(163, 24);
            this.label12.Margin = new System.Windows.Forms.Padding(0);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(283, 20);
            this.label12.TabIndex = 61;
            this.label12.Text = "<----->";
            this.label12.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.BackColor = System.Drawing.Color.White;
            this.label13.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label13.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(163, 46);
            this.label13.Margin = new System.Windows.Forms.Padding(0);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(283, 20);
            this.label13.TabIndex = 62;
            this.label13.Text = "<----->";
            this.label13.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.tableLayoutPanel3);
            this.groupBox2.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox2.Location = new System.Drawing.Point(12, 129);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(498, 208);
            this.groupBox2.TabIndex = 6;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Application Details";
            // 
            // tableLayoutPanel3
            // 
            this.tableLayoutPanel3.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Inset;
            this.tableLayoutPanel3.ColumnCount = 2;
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 36.0179F));
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 63.9821F));
            this.tableLayoutPanel3.Controls.Add(this.comboBox7, 1, 6);
            this.tableLayoutPanel3.Controls.Add(this.comboBox6, 1, 5);
            this.tableLayoutPanel3.Controls.Add(this.comboBox5, 1, 4);
            this.tableLayoutPanel3.Controls.Add(this.comboBox4, 1, 3);
            this.tableLayoutPanel3.Controls.Add(this.comboBox3, 1, 2);
            this.tableLayoutPanel3.Controls.Add(this.comboBox1, 0, 0);
            this.tableLayoutPanel3.Controls.Add(this.label4, 0, 6);
            this.tableLayoutPanel3.Controls.Add(this.label25, 0, 0);
            this.tableLayoutPanel3.Controls.Add(this.label33, 0, 1);
            this.tableLayoutPanel3.Controls.Add(this.label34, 0, 2);
            this.tableLayoutPanel3.Controls.Add(this.label36, 0, 3);
            this.tableLayoutPanel3.Controls.Add(this.label37, 0, 4);
            this.tableLayoutPanel3.Controls.Add(this.label38, 0, 5);
            this.tableLayoutPanel3.Controls.Add(this.comboBox2, 1, 1);
            this.tableLayoutPanel3.Location = new System.Drawing.Point(25, 24);
            this.tableLayoutPanel3.Margin = new System.Windows.Forms.Padding(1);
            this.tableLayoutPanel3.Name = "tableLayoutPanel3";
            this.tableLayoutPanel3.RowCount = 7;
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 21F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 21F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 21F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 21F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 21F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 21F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 21F));
            this.tableLayoutPanel3.Size = new System.Drawing.Size(448, 163);
            this.tableLayoutPanel3.TabIndex = 1;
            // 
            // comboBox7
            // 
            this.comboBox7.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.comboBox7.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.comboBox7.Dock = System.Windows.Forms.DockStyle.Fill;
            this.comboBox7.FormattingEnabled = true;
            this.comboBox7.Location = new System.Drawing.Point(163, 140);
            this.comboBox7.Margin = new System.Windows.Forms.Padding(0);
            this.comboBox7.Name = "comboBox7";
            this.comboBox7.Size = new System.Drawing.Size(283, 21);
            this.comboBox7.TabIndex = 83;
            // 
            // comboBox6
            // 
            this.comboBox6.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.comboBox6.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.comboBox6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.comboBox6.FormattingEnabled = true;
            this.comboBox6.Location = new System.Drawing.Point(163, 117);
            this.comboBox6.Margin = new System.Windows.Forms.Padding(0);
            this.comboBox6.Name = "comboBox6";
            this.comboBox6.Size = new System.Drawing.Size(283, 21);
            this.comboBox6.TabIndex = 82;
            // 
            // comboBox5
            // 
            this.comboBox5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.comboBox5.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox5.FormattingEnabled = true;
            this.comboBox5.Location = new System.Drawing.Point(163, 94);
            this.comboBox5.Margin = new System.Windows.Forms.Padding(0);
            this.comboBox5.Name = "comboBox5";
            this.comboBox5.Size = new System.Drawing.Size(283, 21);
            this.comboBox5.TabIndex = 81;
            // 
            // comboBox4
            // 
            this.comboBox4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.comboBox4.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox4.FormattingEnabled = true;
            this.comboBox4.Location = new System.Drawing.Point(163, 71);
            this.comboBox4.Margin = new System.Windows.Forms.Padding(0);
            this.comboBox4.Name = "comboBox4";
            this.comboBox4.Size = new System.Drawing.Size(283, 21);
            this.comboBox4.TabIndex = 80;
            // 
            // comboBox3
            // 
            this.comboBox3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.comboBox3.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox3.FormattingEnabled = true;
            this.comboBox3.Location = new System.Drawing.Point(163, 48);
            this.comboBox3.Margin = new System.Windows.Forms.Padding(0);
            this.comboBox3.Name = "comboBox3";
            this.comboBox3.Size = new System.Drawing.Size(283, 21);
            this.comboBox3.TabIndex = 79;
            // 
            // comboBox1
            // 
            this.comboBox1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.comboBox1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox1.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Items.AddRange(new object[] {
            "yes",
            "no",
            "maybe"});
            this.comboBox1.Location = new System.Drawing.Point(163, 2);
            this.comboBox1.Margin = new System.Windows.Forms.Padding(0);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(283, 21);
            this.comboBox1.TabIndex = 77;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label4.Location = new System.Drawing.Point(5, 140);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(153, 21);
            this.label4.TabIndex = 76;
            this.label4.Text = "Hiring Manager Name:";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label25.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label25.Location = new System.Drawing.Point(5, 2);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(153, 21);
            this.label25.TabIndex = 51;
            this.label25.Text = "Job Title:";
            this.label25.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label33.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label33.Location = new System.Drawing.Point(5, 25);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(153, 21);
            this.label33.TabIndex = 52;
            this.label33.Text = "Bucket:";
            this.label33.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label34.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label34.Location = new System.Drawing.Point(5, 48);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(153, 21);
            this.label34.TabIndex = 53;
            this.label34.Text = "Titan Title:";
            this.label34.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label36.Location = new System.Drawing.Point(5, 71);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(153, 21);
            this.label36.TabIndex = 63;
            this.label36.Text = "Language Requirement:";
            this.label36.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label37.Location = new System.Drawing.Point(5, 94);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(153, 21);
            this.label37.TabIndex = 64;
            this.label37.Text = "Arvato Level:";
            this.label37.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label38.Location = new System.Drawing.Point(5, 117);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(153, 21);
            this.label38.TabIndex = 65;
            this.label38.Text = "Hiring Manager ID:";
            this.label38.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // comboBox2
            // 
            this.comboBox2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.comboBox2.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox2.FormattingEnabled = true;
            this.comboBox2.Location = new System.Drawing.Point(163, 25);
            this.comboBox2.Margin = new System.Windows.Forms.Padding(0);
            this.comboBox2.Name = "comboBox2";
            this.comboBox2.Size = new System.Drawing.Size(283, 21);
            this.comboBox2.TabIndex = 78;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.btnCancel1);
            this.panel1.Controls.Add(this.btnNext);
            this.panel1.Controls.Add(this.gbxAppInfo);
            this.panel1.Controls.Add(this.groupBox2);
            this.panel1.Location = new System.Drawing.Point(1, 2);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(524, 606);
            this.panel1.TabIndex = 7;
            // 
            // btnCancel1
            // 
            this.btnCancel1.BackColor = System.Drawing.Color.LightCoral;
            this.btnCancel1.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnCancel1.Location = new System.Drawing.Point(420, 573);
            this.btnCancel1.Name = "btnCancel1";
            this.btnCancel1.Size = new System.Drawing.Size(75, 23);
            this.btnCancel1.TabIndex = 8;
            this.btnCancel1.Text = "Cancel";
            this.btnCancel1.UseVisualStyleBackColor = false;
            // 
            // btnNext
            // 
            this.btnNext.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.btnNext.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnNext.Location = new System.Drawing.Point(339, 573);
            this.btnNext.Name = "btnNext";
            this.btnNext.Size = new System.Drawing.Size(75, 23);
            this.btnNext.TabIndex = 7;
            this.btnNext.Text = "Next";
            this.btnNext.UseVisualStyleBackColor = false;
            this.btnNext.Click += new System.EventHandler(this.OnNextClick);
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.button4);
            this.panel2.Controls.Add(this.button3);
            this.panel2.Controls.Add(this.button2);
            this.panel2.Controls.Add(this.groupBox1);
            this.panel2.Controls.Add(this.btnReset);
            this.panel2.Controls.Add(this.btnBack);
            this.panel2.Location = new System.Drawing.Point(1, 1);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(524, 604);
            this.panel2.TabIndex = 7;
            // 
            // button4
            // 
            this.button4.BackColor = System.Drawing.Color.Gold;
            this.button4.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button4.Location = new System.Drawing.Point(258, 574);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(75, 23);
            this.button4.TabIndex = 95;
            this.button4.Text = "To Shortlist";
            this.button4.UseVisualStyleBackColor = false;
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.Color.LimeGreen;
            this.button3.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button3.Location = new System.Drawing.Point(339, 574);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(75, 23);
            this.button3.TabIndex = 94;
            this.button3.Text = "Accept";
            this.button3.UseVisualStyleBackColor = false;
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.Maroon;
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button2.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.button2.Location = new System.Drawing.Point(420, 574);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 23);
            this.button2.TabIndex = 93;
            this.button2.Text = "Reject";
            this.button2.UseVisualStyleBackColor = false;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.tableLayoutPanel1);
            this.groupBox1.Location = new System.Drawing.Point(12, 13);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(498, 555);
            this.groupBox1.TabIndex = 7;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Evaluation";
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Inset;
            this.tableLayoutPanel1.ColumnCount = 2;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 68.08943F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 159F));
            this.tableLayoutPanel1.Controls.Add(this.comboBox30, 1, 22);
            this.tableLayoutPanel1.Controls.Add(this.label32, 0, 22);
            this.tableLayoutPanel1.Controls.Add(this.label5, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.label31, 0, 21);
            this.tableLayoutPanel1.Controls.Add(this.comboBox29, 1, 21);
            this.tableLayoutPanel1.Controls.Add(this.label30, 0, 20);
            this.tableLayoutPanel1.Controls.Add(this.label6, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.label29, 0, 19);
            this.tableLayoutPanel1.Controls.Add(this.comboBox28, 1, 20);
            this.tableLayoutPanel1.Controls.Add(this.label28, 0, 18);
            this.tableLayoutPanel1.Controls.Add(this.comboBox27, 1, 19);
            this.tableLayoutPanel1.Controls.Add(this.label27, 0, 17);
            this.tableLayoutPanel1.Controls.Add(this.comboBox26, 1, 18);
            this.tableLayoutPanel1.Controls.Add(this.label26, 0, 16);
            this.tableLayoutPanel1.Controls.Add(this.comboBox25, 1, 17);
            this.tableLayoutPanel1.Controls.Add(this.label7, 0, 15);
            this.tableLayoutPanel1.Controls.Add(this.comboBox24, 1, 16);
            this.tableLayoutPanel1.Controls.Add(this.label24, 0, 14);
            this.tableLayoutPanel1.Controls.Add(this.comboBox23, 1, 15);
            this.tableLayoutPanel1.Controls.Add(this.label23, 0, 13);
            this.tableLayoutPanel1.Controls.Add(this.comboBox22, 1, 14);
            this.tableLayoutPanel1.Controls.Add(this.label22, 0, 12);
            this.tableLayoutPanel1.Controls.Add(this.comboBox21, 1, 13);
            this.tableLayoutPanel1.Controls.Add(this.label21, 0, 11);
            this.tableLayoutPanel1.Controls.Add(this.comboBox20, 1, 12);
            this.tableLayoutPanel1.Controls.Add(this.label20, 0, 10);
            this.tableLayoutPanel1.Controls.Add(this.comboBox19, 1, 11);
            this.tableLayoutPanel1.Controls.Add(this.label19, 0, 9);
            this.tableLayoutPanel1.Controls.Add(this.comboBox18, 1, 10);
            this.tableLayoutPanel1.Controls.Add(this.label18, 0, 8);
            this.tableLayoutPanel1.Controls.Add(this.comboBox17, 1, 9);
            this.tableLayoutPanel1.Controls.Add(this.label17, 0, 7);
            this.tableLayoutPanel1.Controls.Add(this.comboBox16, 1, 8);
            this.tableLayoutPanel1.Controls.Add(this.label16, 0, 6);
            this.tableLayoutPanel1.Controls.Add(this.comboBox15, 1, 7);
            this.tableLayoutPanel1.Controls.Add(this.label15, 0, 5);
            this.tableLayoutPanel1.Controls.Add(this.comboBox14, 1, 6);
            this.tableLayoutPanel1.Controls.Add(this.label14, 0, 4);
            this.tableLayoutPanel1.Controls.Add(this.comboBox13, 1, 5);
            this.tableLayoutPanel1.Controls.Add(this.label8, 0, 3);
            this.tableLayoutPanel1.Controls.Add(this.comboBox12, 1, 4);
            this.tableLayoutPanel1.Controls.Add(this.label9, 0, 2);
            this.tableLayoutPanel1.Controls.Add(this.comboBox11, 1, 3);
            this.tableLayoutPanel1.Controls.Add(this.comboBox10, 1, 2);
            this.tableLayoutPanel1.Controls.Add(this.comboBox9, 1, 1);
            this.tableLayoutPanel1.Controls.Add(this.comboBox8, 1, 0);
            this.tableLayoutPanel1.Location = new System.Drawing.Point(13, 26);
            this.tableLayoutPanel1.Margin = new System.Windows.Forms.Padding(1);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 23;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 21F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 21F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 21F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(470, 513);
            this.tableLayoutPanel1.TabIndex = 3;
            // 
            // comboBox30
            // 
            this.comboBox30.Dock = System.Windows.Forms.DockStyle.Fill;
            this.comboBox30.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox30.FormattingEnabled = true;
            this.comboBox30.Items.AddRange(new object[] {
            "Poor",
            "Fair",
            "Proficient",
            "Very Good",
            "Excellent"});
            this.comboBox30.Location = new System.Drawing.Point(309, 489);
            this.comboBox30.Margin = new System.Windows.Forms.Padding(0);
            this.comboBox30.Name = "comboBox30";
            this.comboBox30.Size = new System.Drawing.Size(159, 21);
            this.comboBox30.TabIndex = 106;
            this.comboBox30.Tag = "required";
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label32.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label32.Location = new System.Drawing.Point(5, 489);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(299, 22);
            this.label32.TabIndex = 105;
            this.label32.Text = "Asked Good Work Questions:";
            this.label32.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label5.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(5, 25);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(299, 21);
            this.label5.TabIndex = 44;
            this.label5.Text = "Made Good First Impression:";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label31.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label31.Location = new System.Drawing.Point(5, 467);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(299, 20);
            this.label31.TabIndex = 104;
            this.label31.Text = "Organization/Planning Skills:";
            this.label31.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // comboBox29
            // 
            this.comboBox29.Dock = System.Windows.Forms.DockStyle.Fill;
            this.comboBox29.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox29.FormattingEnabled = true;
            this.comboBox29.Items.AddRange(new object[] {
            "Poor",
            "Fair",
            "Proficient",
            "Very Good",
            "Excellent"});
            this.comboBox29.Location = new System.Drawing.Point(309, 467);
            this.comboBox29.Margin = new System.Windows.Forms.Padding(0);
            this.comboBox29.Name = "comboBox29";
            this.comboBox29.Size = new System.Drawing.Size(159, 21);
            this.comboBox29.TabIndex = 42;
            this.comboBox29.Tag = "required";
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label30.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label30.Location = new System.Drawing.Point(5, 445);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(299, 20);
            this.label30.TabIndex = 103;
            this.label30.Text = "Judgement, Decision Making:";
            this.label30.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label6.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(5, 2);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(299, 21);
            this.label6.TabIndex = 43;
            this.label6.Text = "Greeting to Committee:";
            this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label29.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label29.Location = new System.Drawing.Point(5, 423);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(299, 20);
            this.label29.TabIndex = 102;
            this.label29.Text = "Self Motivation && Goals:";
            this.label29.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // comboBox28
            // 
            this.comboBox28.Dock = System.Windows.Forms.DockStyle.Fill;
            this.comboBox28.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox28.FormattingEnabled = true;
            this.comboBox28.Items.AddRange(new object[] {
            "Poor",
            "Fair",
            "Proficient",
            "Very Good",
            "Excellent"});
            this.comboBox28.Location = new System.Drawing.Point(309, 445);
            this.comboBox28.Margin = new System.Windows.Forms.Padding(0);
            this.comboBox28.Name = "comboBox28";
            this.comboBox28.Size = new System.Drawing.Size(159, 21);
            this.comboBox28.TabIndex = 41;
            this.comboBox28.Tag = "required";
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label28.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label28.Location = new System.Drawing.Point(5, 401);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(299, 20);
            this.label28.TabIndex = 101;
            this.label28.Text = "Coping Ability (Stress, Conflict, Time Demands):";
            this.label28.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // comboBox27
            // 
            this.comboBox27.Dock = System.Windows.Forms.DockStyle.Fill;
            this.comboBox27.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox27.FormattingEnabled = true;
            this.comboBox27.Items.AddRange(new object[] {
            "Poor",
            "Fair",
            "Proficient",
            "Very Good",
            "Excellent"});
            this.comboBox27.Location = new System.Drawing.Point(309, 423);
            this.comboBox27.Margin = new System.Windows.Forms.Padding(0);
            this.comboBox27.Name = "comboBox27";
            this.comboBox27.Size = new System.Drawing.Size(159, 21);
            this.comboBox27.TabIndex = 40;
            this.comboBox27.Tag = "required";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label27.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label27.Location = new System.Drawing.Point(5, 379);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(299, 20);
            this.label27.TabIndex = 100;
            this.label27.Text = "Leadership Skills:";
            this.label27.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // comboBox26
            // 
            this.comboBox26.Dock = System.Windows.Forms.DockStyle.Fill;
            this.comboBox26.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox26.FormattingEnabled = true;
            this.comboBox26.Items.AddRange(new object[] {
            "Poor",
            "Fair",
            "Proficient",
            "Very Good",
            "Excellent"});
            this.comboBox26.Location = new System.Drawing.Point(309, 401);
            this.comboBox26.Margin = new System.Windows.Forms.Padding(0);
            this.comboBox26.Name = "comboBox26";
            this.comboBox26.Size = new System.Drawing.Size(159, 21);
            this.comboBox26.TabIndex = 39;
            this.comboBox26.Tag = "required";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label26.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label26.Location = new System.Drawing.Point(5, 357);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(299, 20);
            this.label26.TabIndex = 99;
            this.label26.Text = "Listening Skills:";
            this.label26.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // comboBox25
            // 
            this.comboBox25.Dock = System.Windows.Forms.DockStyle.Fill;
            this.comboBox25.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox25.FormattingEnabled = true;
            this.comboBox25.Items.AddRange(new object[] {
            "Poor",
            "Fair",
            "Proficient",
            "Very Good",
            "Excellent"});
            this.comboBox25.Location = new System.Drawing.Point(309, 379);
            this.comboBox25.Margin = new System.Windows.Forms.Padding(0);
            this.comboBox25.Name = "comboBox25";
            this.comboBox25.Size = new System.Drawing.Size(159, 21);
            this.comboBox25.TabIndex = 38;
            this.comboBox25.Tag = "required";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label7.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(5, 335);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(299, 20);
            this.label7.TabIndex = 98;
            this.label7.Text = "Non-verbal (Posture, Hand Gesture, Didn\'t Fidget):";
            this.label7.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // comboBox24
            // 
            this.comboBox24.Dock = System.Windows.Forms.DockStyle.Fill;
            this.comboBox24.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox24.FormattingEnabled = true;
            this.comboBox24.Items.AddRange(new object[] {
            "Poor",
            "Fair",
            "Proficient",
            "Very Good",
            "Excellent"});
            this.comboBox24.Location = new System.Drawing.Point(309, 357);
            this.comboBox24.Margin = new System.Windows.Forms.Padding(0);
            this.comboBox24.Name = "comboBox24";
            this.comboBox24.Size = new System.Drawing.Size(159, 21);
            this.comboBox24.TabIndex = 37;
            this.comboBox24.Tag = "required";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label24.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label24.Location = new System.Drawing.Point(5, 313);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(299, 20);
            this.label24.TabIndex = 97;
            this.label24.Text = "Communication Skills:";
            this.label24.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // comboBox23
            // 
            this.comboBox23.Dock = System.Windows.Forms.DockStyle.Fill;
            this.comboBox23.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox23.FormattingEnabled = true;
            this.comboBox23.Items.AddRange(new object[] {
            "Poor",
            "Fair",
            "Proficient",
            "Very Good",
            "Excellent"});
            this.comboBox23.Location = new System.Drawing.Point(309, 335);
            this.comboBox23.Margin = new System.Windows.Forms.Padding(0);
            this.comboBox23.Name = "comboBox23";
            this.comboBox23.Size = new System.Drawing.Size(159, 21);
            this.comboBox23.TabIndex = 36;
            this.comboBox23.Tag = "required";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label23.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label23.Location = new System.Drawing.Point(5, 291);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(299, 20);
            this.label23.TabIndex = 96;
            this.label23.Text = "Customer Service Skills:";
            this.label23.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // comboBox22
            // 
            this.comboBox22.Dock = System.Windows.Forms.DockStyle.Fill;
            this.comboBox22.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox22.FormattingEnabled = true;
            this.comboBox22.Items.AddRange(new object[] {
            "Poor",
            "Fair",
            "Proficient",
            "Very Good",
            "Excellent"});
            this.comboBox22.Location = new System.Drawing.Point(309, 313);
            this.comboBox22.Margin = new System.Windows.Forms.Padding(0);
            this.comboBox22.Name = "comboBox22";
            this.comboBox22.Size = new System.Drawing.Size(159, 21);
            this.comboBox22.TabIndex = 35;
            this.comboBox22.Tag = "required";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label22.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label22.Location = new System.Drawing.Point(5, 269);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(299, 20);
            this.label22.TabIndex = 95;
            this.label22.Text = "Team Skills:";
            this.label22.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // comboBox21
            // 
            this.comboBox21.Dock = System.Windows.Forms.DockStyle.Fill;
            this.comboBox21.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox21.FormattingEnabled = true;
            this.comboBox21.Items.AddRange(new object[] {
            "Poor",
            "Fair",
            "Proficient",
            "Very Good",
            "Excellent"});
            this.comboBox21.Location = new System.Drawing.Point(309, 291);
            this.comboBox21.Margin = new System.Windows.Forms.Padding(0);
            this.comboBox21.Name = "comboBox21";
            this.comboBox21.Size = new System.Drawing.Size(159, 21);
            this.comboBox21.TabIndex = 34;
            this.comboBox21.Tag = "required";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label21.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label21.Location = new System.Drawing.Point(5, 247);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(299, 20);
            this.label21.TabIndex = 94;
            this.label21.Text = "Answers Focus on Strengths:";
            this.label21.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // comboBox20
            // 
            this.comboBox20.Dock = System.Windows.Forms.DockStyle.Fill;
            this.comboBox20.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox20.FormattingEnabled = true;
            this.comboBox20.Items.AddRange(new object[] {
            "Poor",
            "Fair",
            "Proficient",
            "Very Good",
            "Excellent"});
            this.comboBox20.Location = new System.Drawing.Point(309, 269);
            this.comboBox20.Margin = new System.Windows.Forms.Padding(0);
            this.comboBox20.Name = "comboBox20";
            this.comboBox20.Size = new System.Drawing.Size(159, 21);
            this.comboBox20.TabIndex = 33;
            this.comboBox20.Tag = "required";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label20.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.Location = new System.Drawing.Point(5, 225);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(299, 20);
            this.label20.TabIndex = 93;
            this.label20.Text = "Answered Questions Well:";
            this.label20.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // comboBox19
            // 
            this.comboBox19.Dock = System.Windows.Forms.DockStyle.Fill;
            this.comboBox19.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox19.FormattingEnabled = true;
            this.comboBox19.Items.AddRange(new object[] {
            "Poor",
            "Fair",
            "Proficient",
            "Very Good",
            "Excellent"});
            this.comboBox19.Location = new System.Drawing.Point(309, 247);
            this.comboBox19.Margin = new System.Windows.Forms.Padding(0);
            this.comboBox19.Name = "comboBox19";
            this.comboBox19.Size = new System.Drawing.Size(159, 21);
            this.comboBox19.TabIndex = 32;
            this.comboBox19.Tag = "required";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label19.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.Location = new System.Drawing.Point(5, 203);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(299, 20);
            this.label19.TabIndex = 92;
            this.label19.Text = "Related Experience:";
            this.label19.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // comboBox18
            // 
            this.comboBox18.Dock = System.Windows.Forms.DockStyle.Fill;
            this.comboBox18.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox18.FormattingEnabled = true;
            this.comboBox18.Items.AddRange(new object[] {
            "Poor",
            "Fair",
            "Proficient",
            "Very Good",
            "Excellent"});
            this.comboBox18.Location = new System.Drawing.Point(309, 225);
            this.comboBox18.Margin = new System.Windows.Forms.Padding(0);
            this.comboBox18.Name = "comboBox18";
            this.comboBox18.Size = new System.Drawing.Size(159, 21);
            this.comboBox18.TabIndex = 31;
            this.comboBox18.Tag = "required";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label18.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.Location = new System.Drawing.Point(5, 181);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(299, 20);
            this.label18.TabIndex = 91;
            this.label18.Text = "Education/Training:";
            this.label18.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // comboBox17
            // 
            this.comboBox17.Dock = System.Windows.Forms.DockStyle.Fill;
            this.comboBox17.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox17.FormattingEnabled = true;
            this.comboBox17.Items.AddRange(new object[] {
            "Poor",
            "Fair",
            "Proficient",
            "Very Good",
            "Excellent"});
            this.comboBox17.Location = new System.Drawing.Point(309, 203);
            this.comboBox17.Margin = new System.Windows.Forms.Padding(0);
            this.comboBox17.Name = "comboBox17";
            this.comboBox17.Size = new System.Drawing.Size(159, 21);
            this.comboBox17.TabIndex = 30;
            this.comboBox17.Tag = "required";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label17.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.Location = new System.Drawing.Point(5, 159);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(299, 20);
            this.label17.TabIndex = 90;
            this.label17.Text = "Knowledge of Job/Company:";
            this.label17.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // comboBox16
            // 
            this.comboBox16.Dock = System.Windows.Forms.DockStyle.Fill;
            this.comboBox16.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox16.FormattingEnabled = true;
            this.comboBox16.Items.AddRange(new object[] {
            "Poor",
            "Fair",
            "Proficient",
            "Very Good",
            "Excellent"});
            this.comboBox16.Location = new System.Drawing.Point(309, 181);
            this.comboBox16.Margin = new System.Windows.Forms.Padding(0);
            this.comboBox16.Name = "comboBox16";
            this.comboBox16.Size = new System.Drawing.Size(159, 21);
            this.comboBox16.TabIndex = 29;
            this.comboBox16.Tag = "required";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label16.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(5, 137);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(299, 20);
            this.label16.TabIndex = 89;
            this.label16.Text = "Confidence:";
            this.label16.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // comboBox15
            // 
            this.comboBox15.Dock = System.Windows.Forms.DockStyle.Fill;
            this.comboBox15.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox15.FormattingEnabled = true;
            this.comboBox15.Items.AddRange(new object[] {
            "Poor",
            "Fair",
            "Proficient",
            "Very Good",
            "Excellent"});
            this.comboBox15.Location = new System.Drawing.Point(309, 159);
            this.comboBox15.Margin = new System.Windows.Forms.Padding(0);
            this.comboBox15.Name = "comboBox15";
            this.comboBox15.Size = new System.Drawing.Size(159, 21);
            this.comboBox15.TabIndex = 28;
            this.comboBox15.Tag = "required";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label15.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(5, 115);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(299, 20);
            this.label15.TabIndex = 88;
            this.label15.Text = "Level of Interest:";
            this.label15.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // comboBox14
            // 
            this.comboBox14.Dock = System.Windows.Forms.DockStyle.Fill;
            this.comboBox14.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox14.FormattingEnabled = true;
            this.comboBox14.Items.AddRange(new object[] {
            "Poor",
            "Fair",
            "Proficient",
            "Very Good",
            "Excellent"});
            this.comboBox14.Location = new System.Drawing.Point(309, 137);
            this.comboBox14.Margin = new System.Windows.Forms.Padding(0);
            this.comboBox14.Name = "comboBox14";
            this.comboBox14.Size = new System.Drawing.Size(159, 21);
            this.comboBox14.TabIndex = 27;
            this.comboBox14.Tag = "required";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label14.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(5, 93);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(299, 20);
            this.label14.TabIndex = 87;
            this.label14.Text = "Eye Contact:";
            this.label14.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // comboBox13
            // 
            this.comboBox13.Dock = System.Windows.Forms.DockStyle.Fill;
            this.comboBox13.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox13.FormattingEnabled = true;
            this.comboBox13.Items.AddRange(new object[] {
            "Poor",
            "Fair",
            "Proficient",
            "Very Good",
            "Excellent"});
            this.comboBox13.Location = new System.Drawing.Point(309, 115);
            this.comboBox13.Margin = new System.Windows.Forms.Padding(0);
            this.comboBox13.Name = "comboBox13";
            this.comboBox13.Size = new System.Drawing.Size(159, 21);
            this.comboBox13.TabIndex = 26;
            this.comboBox13.Tag = "required";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label8.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(5, 71);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(299, 20);
            this.label8.TabIndex = 86;
            this.label8.Text = "Dress Appropriately:";
            this.label8.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // comboBox12
            // 
            this.comboBox12.Dock = System.Windows.Forms.DockStyle.Fill;
            this.comboBox12.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox12.FormattingEnabled = true;
            this.comboBox12.Items.AddRange(new object[] {
            "Poor",
            "Fair",
            "Proficient",
            "Very Good",
            "Excellent"});
            this.comboBox12.Location = new System.Drawing.Point(309, 93);
            this.comboBox12.Margin = new System.Windows.Forms.Padding(0);
            this.comboBox12.Name = "comboBox12";
            this.comboBox12.Size = new System.Drawing.Size(159, 21);
            this.comboBox12.TabIndex = 25;
            this.comboBox12.Tag = "required";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label9.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(5, 48);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(299, 21);
            this.label9.TabIndex = 85;
            this.label9.Text = "Attitude:";
            this.label9.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // comboBox11
            // 
            this.comboBox11.Dock = System.Windows.Forms.DockStyle.Fill;
            this.comboBox11.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox11.FormattingEnabled = true;
            this.comboBox11.Items.AddRange(new object[] {
            "Poor",
            "Fair",
            "Proficient",
            "Very Good",
            "Excellent"});
            this.comboBox11.Location = new System.Drawing.Point(309, 71);
            this.comboBox11.Margin = new System.Windows.Forms.Padding(0);
            this.comboBox11.Name = "comboBox11";
            this.comboBox11.Size = new System.Drawing.Size(159, 21);
            this.comboBox11.TabIndex = 24;
            this.comboBox11.Tag = "required";
            // 
            // comboBox10
            // 
            this.comboBox10.Dock = System.Windows.Forms.DockStyle.Fill;
            this.comboBox10.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox10.FormattingEnabled = true;
            this.comboBox10.Items.AddRange(new object[] {
            "Poor",
            "Fair",
            "Proficient",
            "Very Good",
            "Excellent"});
            this.comboBox10.Location = new System.Drawing.Point(309, 48);
            this.comboBox10.Margin = new System.Windows.Forms.Padding(0);
            this.comboBox10.Name = "comboBox10";
            this.comboBox10.Size = new System.Drawing.Size(159, 21);
            this.comboBox10.TabIndex = 23;
            this.comboBox10.Tag = "required";
            // 
            // comboBox9
            // 
            this.comboBox9.Dock = System.Windows.Forms.DockStyle.Fill;
            this.comboBox9.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox9.FormattingEnabled = true;
            this.comboBox9.Items.AddRange(new object[] {
            "Poor",
            "Fair",
            "Proficient",
            "Very Good",
            "Excellent"});
            this.comboBox9.Location = new System.Drawing.Point(309, 25);
            this.comboBox9.Margin = new System.Windows.Forms.Padding(0);
            this.comboBox9.Name = "comboBox9";
            this.comboBox9.Size = new System.Drawing.Size(159, 21);
            this.comboBox9.TabIndex = 22;
            this.comboBox9.Tag = "required";
            // 
            // comboBox8
            // 
            this.comboBox8.Dock = System.Windows.Forms.DockStyle.Fill;
            this.comboBox8.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox8.FormattingEnabled = true;
            this.comboBox8.Items.AddRange(new object[] {
            "Poor",
            "Fair",
            "Proficient",
            "Very Good",
            "Excellent"});
            this.comboBox8.Location = new System.Drawing.Point(309, 2);
            this.comboBox8.Margin = new System.Windows.Forms.Padding(0);
            this.comboBox8.Name = "comboBox8";
            this.comboBox8.Size = new System.Drawing.Size(159, 21);
            this.comboBox8.TabIndex = 21;
            this.comboBox8.Tag = "required";
            // 
            // btnReset
            // 
            this.btnReset.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.btnReset.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnReset.Location = new System.Drawing.Point(177, 574);
            this.btnReset.Name = "btnReset";
            this.btnReset.Size = new System.Drawing.Size(75, 23);
            this.btnReset.TabIndex = 5;
            this.btnReset.Text = "Reset";
            this.btnReset.UseVisualStyleBackColor = false;
            // 
            // btnBack
            // 
            this.btnBack.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.btnBack.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnBack.Location = new System.Drawing.Point(96, 574);
            this.btnBack.Name = "btnBack";
            this.btnBack.Size = new System.Drawing.Size(75, 23);
            this.btnBack.TabIndex = 3;
            this.btnBack.Text = "Back";
            this.btnBack.UseVisualStyleBackColor = false;
            this.btnBack.Click += new System.EventHandler(this.OnBackClick);
            // 
            // EvaluateApplicant
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(526, 610);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.panel2);
            this.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Name = "EvaluateApplicant";
            this.Text = "Interview Evaluation";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.EvaluateApplicant_FormClosing);
            this.Load += new System.EventHandler(this.OnLoad);
            this.gbxAppInfo.ResumeLayout(false);
            this.applicantInfo.ResumeLayout(false);
            this.applicantInfo.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.tableLayoutPanel3.ResumeLayout(false);
            this.tableLayoutPanel3.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox gbxAppInfo;
        private System.Windows.Forms.TableLayoutPanel applicantInfo;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel3;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.ComboBox comboBox5;
        private System.Windows.Forms.ComboBox comboBox4;
        private System.Windows.Forms.ComboBox comboBox3;
        private System.Windows.Forms.ComboBox comboBox2;
        private System.Windows.Forms.ComboBox comboBox7;
        private System.Windows.Forms.ComboBox comboBox6;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button btnCancel1;
        private System.Windows.Forms.Button btnNext;
        private System.Windows.Forms.Button btnReset;
        private System.Windows.Forms.Button btnBack;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.ComboBox comboBox30;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.ComboBox comboBox29;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.ComboBox comboBox28;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.ComboBox comboBox27;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.ComboBox comboBox26;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.ComboBox comboBox25;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.ComboBox comboBox24;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.ComboBox comboBox23;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.ComboBox comboBox22;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.ComboBox comboBox21;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.ComboBox comboBox20;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.ComboBox comboBox19;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.ComboBox comboBox18;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.ComboBox comboBox17;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.ComboBox comboBox16;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.ComboBox comboBox15;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.ComboBox comboBox14;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.ComboBox comboBox13;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.ComboBox comboBox12;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.ComboBox comboBox11;
        private System.Windows.Forms.ComboBox comboBox10;
        private System.Windows.Forms.ComboBox comboBox9;
        private System.Windows.Forms.ComboBox comboBox8;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button2;
    }
}