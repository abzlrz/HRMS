﻿namespace Presentation.DialogBox
{
    partial class FormEmployeeDashboard
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.btn_ok = new System.Windows.Forms.Button();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.tableLayoutPanel3 = new System.Windows.Forms.TableLayoutPanel();
            this.linkLabel21 = new System.Windows.Forms.LinkLabel();
            this.checkBox38 = new System.Windows.Forms.CheckBox();
            this.checkBox37 = new System.Windows.Forms.CheckBox();
            this.checkBox36 = new System.Windows.Forms.CheckBox();
            this.checkBox35 = new System.Windows.Forms.CheckBox();
            this.checkBox34 = new System.Windows.Forms.CheckBox();
            this.checkBox33 = new System.Windows.Forms.CheckBox();
            this.checkBox32 = new System.Windows.Forms.CheckBox();
            this.checkBox31 = new System.Windows.Forms.CheckBox();
            this.checkBox30 = new System.Windows.Forms.CheckBox();
            this.checkBox29 = new System.Windows.Forms.CheckBox();
            this.checkBox28 = new System.Windows.Forms.CheckBox();
            this.checkBox27 = new System.Windows.Forms.CheckBox();
            this.checkBox26 = new System.Windows.Forms.CheckBox();
            this.checkBox25 = new System.Windows.Forms.CheckBox();
            this.checkBox24 = new System.Windows.Forms.CheckBox();
            this.checkBox23 = new System.Windows.Forms.CheckBox();
            this.checkBox22 = new System.Windows.Forms.CheckBox();
            this.checkBox21 = new System.Windows.Forms.CheckBox();
            this.label84 = new System.Windows.Forms.Label();
            this.label59 = new System.Windows.Forms.Label();
            this.link_locker = new System.Windows.Forms.LinkLabel();
            this.link_IdentificationCard = new System.Windows.Forms.LinkLabel();
            this.link_acceptablePolicy = new System.Windows.Forms.LinkLabel();
            this.linkLabel35 = new System.Windows.Forms.LinkLabel();
            this.link_consent = new System.Windows.Forms.LinkLabel();
            this.link_acceptanceCOC = new System.Windows.Forms.LinkLabel();
            this.link_acceptance_COD = new System.Windows.Forms.LinkLabel();
            this.link_NSOmarriage = new System.Windows.Forms.LinkLabel();
            this.link_NSOdependent = new System.Windows.Forms.LinkLabel();
            this.link_cedula = new System.Windows.Forms.LinkLabel();
            this.link_OccupationalPermit = new System.Windows.Forms.LinkLabel();
            this.link_2316 = new System.Windows.Forms.LinkLabel();
            this.link_2305 = new System.Windows.Forms.LinkLabel();
            this.link_1905 = new System.Windows.Forms.LinkLabel();
            this.link_bankForm = new System.Windows.Forms.LinkLabel();
            this.link_HMO = new System.Windows.Forms.LinkLabel();
            this.label60 = new System.Windows.Forms.Label();
            this.label61 = new System.Windows.Forms.Label();
            this.label62 = new System.Windows.Forms.Label();
            this.label63 = new System.Windows.Forms.Label();
            this.labs = new System.Windows.Forms.Label();
            this.label65 = new System.Windows.Forms.Label();
            this.label66 = new System.Windows.Forms.Label();
            this.label67 = new System.Windows.Forms.Label();
            this.label68 = new System.Windows.Forms.Label();
            this.label69 = new System.Windows.Forms.Label();
            this.label70 = new System.Windows.Forms.Label();
            this.label71 = new System.Windows.Forms.Label();
            this.label72 = new System.Windows.Forms.Label();
            this.label73 = new System.Windows.Forms.Label();
            this.label74 = new System.Windows.Forms.Label();
            this.label75 = new System.Windows.Forms.Label();
            this.label76 = new System.Windows.Forms.Label();
            this.label77 = new System.Windows.Forms.Label();
            this.label78 = new System.Windows.Forms.Label();
            this.label79 = new System.Windows.Forms.Label();
            this.label80 = new System.Windows.Forms.Label();
            this.label81 = new System.Windows.Forms.Label();
            this.label82 = new System.Windows.Forms.Label();
            this.label83 = new System.Windows.Forms.Label();
            this.label85 = new System.Windows.Forms.Label();
            this.label86 = new System.Windows.Forms.Label();
            this.label87 = new System.Windows.Forms.Label();
            this.label88 = new System.Windows.Forms.Label();
            this.label89 = new System.Windows.Forms.Label();
            this.label90 = new System.Windows.Forms.Label();
            this.label91 = new System.Windows.Forms.Label();
            this.label92 = new System.Windows.Forms.Label();
            this.label93 = new System.Windows.Forms.Label();
            this.label94 = new System.Windows.Forms.Label();
            this.label95 = new System.Windows.Forms.Label();
            this.label96 = new System.Windows.Forms.Label();
            this.label97 = new System.Windows.Forms.Label();
            this.link_payroll = new System.Windows.Forms.LinkLabel();
            this.tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
            this.checkBox20 = new System.Windows.Forms.CheckBox();
            this.checkBox19 = new System.Windows.Forms.CheckBox();
            this.checkBox18 = new System.Windows.Forms.CheckBox();
            this.checkBox17 = new System.Windows.Forms.CheckBox();
            this.checkBox16 = new System.Windows.Forms.CheckBox();
            this.checkBox15 = new System.Windows.Forms.CheckBox();
            this.checkBox14 = new System.Windows.Forms.CheckBox();
            this.checkBox13 = new System.Windows.Forms.CheckBox();
            this.checkBox12 = new System.Windows.Forms.CheckBox();
            this.checkBox11 = new System.Windows.Forms.CheckBox();
            this.checkBox10 = new System.Windows.Forms.CheckBox();
            this.checkBox9 = new System.Windows.Forms.CheckBox();
            this.checkBox8 = new System.Windows.Forms.CheckBox();
            this.checkBox7 = new System.Windows.Forms.CheckBox();
            this.checkBox6 = new System.Windows.Forms.CheckBox();
            this.checkBox5 = new System.Windows.Forms.CheckBox();
            this.checkBox4 = new System.Windows.Forms.CheckBox();
            this.checkBox3 = new System.Windows.Forms.CheckBox();
            this.checkBox2 = new System.Windows.Forms.CheckBox();
            this.linkLabel20 = new System.Windows.Forms.LinkLabel();
            this.label10 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.label33 = new System.Windows.Forms.Label();
            this.label35 = new System.Windows.Forms.Label();
            this.label37 = new System.Windows.Forms.Label();
            this.label39 = new System.Windows.Forms.Label();
            this.label41 = new System.Windows.Forms.Label();
            this.label43 = new System.Windows.Forms.Label();
            this.label45 = new System.Windows.Forms.Label();
            this.label47 = new System.Windows.Forms.Label();
            this.label49 = new System.Windows.Forms.Label();
            this.label51 = new System.Windows.Forms.Label();
            this.linkLabel19 = new System.Windows.Forms.LinkLabel();
            this.linkLabel18 = new System.Windows.Forms.LinkLabel();
            this.link_informationForm = new System.Windows.Forms.LinkLabel();
            this.link_backgroundResult = new System.Windows.Forms.LinkLabel();
            this.link_backgroundCheck = new System.Windows.Forms.LinkLabel();
            this.link_resume = new System.Windows.Forms.LinkLabel();
            this.link_InterviewDocs = new System.Windows.Forms.LinkLabel();
            this.link_NDA = new System.Windows.Forms.LinkLabel();
            this.link_NewHire = new System.Windows.Forms.LinkLabel();
            this.link_SNO = new System.Windows.Forms.LinkLabel();
            this.link_TOR = new System.Windows.Forms.LinkLabel();
            this.link_COE = new System.Windows.Forms.LinkLabel();
            this.link_NBI = new System.Windows.Forms.LinkLabel();
            this.lin_IDPicture = new System.Windows.Forms.LinkLabel();
            this.link_validID = new System.Windows.Forms.LinkLabel();
            this.link_ProofOfPagibig = new System.Windows.Forms.LinkLabel();
            this.link_proofOfPhilHealth = new System.Windows.Forms.LinkLabel();
            this.link_proofOfSSS = new System.Windows.Forms.LinkLabel();
            this.label48 = new System.Windows.Forms.Label();
            this.label46 = new System.Windows.Forms.Label();
            this.label44 = new System.Windows.Forms.Label();
            this.label42 = new System.Windows.Forms.Label();
            this.label40 = new System.Windows.Forms.Label();
            this.label38 = new System.Windows.Forms.Label();
            this.label36 = new System.Windows.Forms.Label();
            this.label34 = new System.Windows.Forms.Label();
            this.label32 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label50 = new System.Windows.Forms.Label();
            this.label52 = new System.Windows.Forms.Label();
            this.label53 = new System.Windows.Forms.Label();
            this.label54 = new System.Windows.Forms.Label();
            this.label55 = new System.Windows.Forms.Label();
            this.label56 = new System.Windows.Forms.Label();
            this.label57 = new System.Windows.Forms.Label();
            this.label58 = new System.Windows.Forms.Label();
            this.link_proofOftin = new System.Windows.Forms.LinkLabel();
            this.checkBox1 = new System.Windows.Forms.CheckBox();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.tableLayoutPanel4 = new System.Windows.Forms.TableLayoutPanel();
            this.lbl_info_maritalstatus = new System.Windows.Forms.Label();
            this.sdf = new System.Windows.Forms.Label();
            this.label104 = new System.Windows.Forms.Label();
            this.lbl_address_postal_no = new System.Windows.Forms.Label();
            this.lbl_info_email = new System.Windows.Forms.Label();
            this.lbl_info_secondary_contact = new System.Windows.Forms.Label();
            this.lbl_info_primary_contact = new System.Windows.Forms.Label();
            this.lbl_info_lastname = new System.Windows.Forms.Label();
            this.lbl_info_middlename = new System.Windows.Forms.Label();
            this.lbl_info_firstname = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.lbl_info_employee_id = new System.Windows.Forms.Label();
            this.lbl_benefits = new System.Windows.Forms.Label();
            this.lbl_info_sss = new System.Windows.Forms.Label();
            this.lbl_info_tin = new System.Windows.Forms.Label();
            this.lbl_info_hdmf = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.lbl_info_bpi = new System.Windows.Forms.Label();
            this.label64 = new System.Windows.Forms.Label();
            this.label98 = new System.Windows.Forms.Label();
            this.label99 = new System.Windows.Forms.Label();
            this.lbl_address_no = new System.Windows.Forms.Label();
            this.lbl_address_street = new System.Windows.Forms.Label();
            this.lbl_address_postal_area = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.tableLayoutPanel7 = new System.Windows.Forms.TableLayoutPanel();
            this.tableLayoutPanel8 = new System.Windows.Forms.TableLayoutPanel();
            this.lbl_salary_shift_allowance = new System.Windows.Forms.Label();
            this.lbl_salary_annual_allowance = new System.Windows.Forms.Label();
            this.lbl_salary_annual = new System.Windows.Forms.Label();
            this.lbl_salary_approved = new System.Windows.Forms.Label();
            this.lbl_salary_date_started = new System.Windows.Forms.Label();
            this.lbl_salary_date_accepted = new System.Windows.Forms.Label();
            this.label114 = new System.Windows.Forms.Label();
            this.label116 = new System.Windows.Forms.Label();
            this.label117 = new System.Windows.Forms.Label();
            this.label118 = new System.Windows.Forms.Label();
            this.label120 = new System.Windows.Forms.Label();
            this.label122 = new System.Windows.Forms.Label();
            this.label123 = new System.Windows.Forms.Label();
            this.label124 = new System.Windows.Forms.Label();
            this.label125 = new System.Windows.Forms.Label();
            this.lbl_salary_date_approved = new System.Windows.Forms.Label();
            this.label128 = new System.Windows.Forms.Label();
            this.lbl_salary_reloc_allowance = new System.Windows.Forms.Label();
            this.lbl_salary_reloc_detail = new System.Windows.Forms.Label();
            this.lbl_salary_cost_centre = new System.Windows.Forms.Label();
            this.label140 = new System.Windows.Forms.Label();
            this.tableLayoutPanel5 = new System.Windows.Forms.TableLayoutPanel();
            this.tableLayoutPanel6 = new System.Windows.Forms.TableLayoutPanel();
            this.lbl_job_team = new System.Windows.Forms.Label();
            this.lbl_job_title = new System.Windows.Forms.Label();
            this.lbl_job_arvatolevel = new System.Windows.Forms.Label();
            this.lbl_job_bucket = new System.Windows.Forms.Label();
            this.lbl_job_titantitle = new System.Windows.Forms.Label();
            this.lbl_hiringmanager_name = new System.Windows.Forms.Label();
            this.label105 = new System.Windows.Forms.Label();
            this.label106 = new System.Windows.Forms.Label();
            this.label107 = new System.Windows.Forms.Label();
            this.label108 = new System.Windows.Forms.Label();
            this.label109 = new System.Windows.Forms.Label();
            this.label110 = new System.Windows.Forms.Label();
            this.label111 = new System.Windows.Forms.Label();
            this.label112 = new System.Windows.Forms.Label();
            this.label113 = new System.Windows.Forms.Label();
            this.lbl_hiringmanager_id = new System.Windows.Forms.Label();
            this.label115 = new System.Windows.Forms.Label();
            this.lbl_job_contract_type = new System.Windows.Forms.Label();
            this.lbl_job_role = new System.Windows.Forms.Label();
            this.lbl_owner_id = new System.Windows.Forms.Label();
            this.label119 = new System.Windows.Forms.Label();
            this.lbl_owner_firstname = new System.Windows.Forms.Label();
            this.label121 = new System.Windows.Forms.Label();
            this.lbl_owner_lastname = new System.Windows.Forms.Label();
            this.label127 = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.tabPage4.SuspendLayout();
            this.tableLayoutPanel3.SuspendLayout();
            this.tableLayoutPanel2.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tableLayoutPanel1.SuspendLayout();
            this.tableLayoutPanel4.SuspendLayout();
            this.tabControl1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.tableLayoutPanel7.SuspendLayout();
            this.tableLayoutPanel8.SuspendLayout();
            this.tableLayoutPanel5.SuspendLayout();
            this.tableLayoutPanel6.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.btn_ok);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel1.Location = new System.Drawing.Point(12, 503);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(829, 57);
            this.panel1.TabIndex = 0;
            // 
            // btn_ok
            // 
            this.btn_ok.DialogResult = System.Windows.Forms.DialogResult.OK;
            this.btn_ok.Location = new System.Drawing.Point(750, 29);
            this.btn_ok.Name = "btn_ok";
            this.btn_ok.Size = new System.Drawing.Size(75, 25);
            this.btn_ok.TabIndex = 1;
            this.btn_ok.Text = "OK";
            this.btn_ok.UseVisualStyleBackColor = true;
            // 
            // tabPage4
            // 
            this.tabPage4.AutoScroll = true;
            this.tabPage4.Controls.Add(this.tableLayoutPanel3);
            this.tabPage4.Controls.Add(this.tableLayoutPanel2);
            this.tabPage4.Location = new System.Drawing.Point(4, 22);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Size = new System.Drawing.Size(821, 465);
            this.tabPage4.TabIndex = 3;
            this.tabPage4.Text = "PER Checklist";
            this.tabPage4.UseVisualStyleBackColor = true;
            // 
            // tableLayoutPanel3
            // 
            this.tableLayoutPanel3.ColumnCount = 4;
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 27F));
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 265F));
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 50F));
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 35F));
            this.tableLayoutPanel3.Controls.Add(this.linkLabel21, 2, 18);
            this.tableLayoutPanel3.Controls.Add(this.checkBox38, 3, 18);
            this.tableLayoutPanel3.Controls.Add(this.checkBox37, 3, 17);
            this.tableLayoutPanel3.Controls.Add(this.checkBox36, 3, 16);
            this.tableLayoutPanel3.Controls.Add(this.checkBox35, 3, 15);
            this.tableLayoutPanel3.Controls.Add(this.checkBox34, 3, 14);
            this.tableLayoutPanel3.Controls.Add(this.checkBox33, 3, 13);
            this.tableLayoutPanel3.Controls.Add(this.checkBox32, 3, 12);
            this.tableLayoutPanel3.Controls.Add(this.checkBox31, 3, 11);
            this.tableLayoutPanel3.Controls.Add(this.checkBox30, 3, 10);
            this.tableLayoutPanel3.Controls.Add(this.checkBox29, 3, 9);
            this.tableLayoutPanel3.Controls.Add(this.checkBox28, 3, 8);
            this.tableLayoutPanel3.Controls.Add(this.checkBox27, 3, 7);
            this.tableLayoutPanel3.Controls.Add(this.checkBox26, 3, 6);
            this.tableLayoutPanel3.Controls.Add(this.checkBox25, 3, 5);
            this.tableLayoutPanel3.Controls.Add(this.checkBox24, 3, 4);
            this.tableLayoutPanel3.Controls.Add(this.checkBox23, 3, 3);
            this.tableLayoutPanel3.Controls.Add(this.checkBox22, 3, 2);
            this.tableLayoutPanel3.Controls.Add(this.checkBox21, 3, 1);
            this.tableLayoutPanel3.Controls.Add(this.label84, 0, 18);
            this.tableLayoutPanel3.Controls.Add(this.label59, 0, 18);
            this.tableLayoutPanel3.Controls.Add(this.link_locker, 2, 17);
            this.tableLayoutPanel3.Controls.Add(this.link_IdentificationCard, 2, 16);
            this.tableLayoutPanel3.Controls.Add(this.link_acceptablePolicy, 2, 15);
            this.tableLayoutPanel3.Controls.Add(this.linkLabel35, 2, 14);
            this.tableLayoutPanel3.Controls.Add(this.link_consent, 2, 13);
            this.tableLayoutPanel3.Controls.Add(this.link_acceptanceCOC, 2, 12);
            this.tableLayoutPanel3.Controls.Add(this.link_acceptance_COD, 2, 11);
            this.tableLayoutPanel3.Controls.Add(this.link_NSOmarriage, 2, 10);
            this.tableLayoutPanel3.Controls.Add(this.link_NSOdependent, 2, 9);
            this.tableLayoutPanel3.Controls.Add(this.link_cedula, 2, 8);
            this.tableLayoutPanel3.Controls.Add(this.link_OccupationalPermit, 2, 7);
            this.tableLayoutPanel3.Controls.Add(this.link_2316, 2, 6);
            this.tableLayoutPanel3.Controls.Add(this.link_2305, 2, 5);
            this.tableLayoutPanel3.Controls.Add(this.link_1905, 2, 4);
            this.tableLayoutPanel3.Controls.Add(this.link_bankForm, 2, 3);
            this.tableLayoutPanel3.Controls.Add(this.link_HMO, 2, 2);
            this.tableLayoutPanel3.Controls.Add(this.label60, 1, 17);
            this.tableLayoutPanel3.Controls.Add(this.label61, 0, 17);
            this.tableLayoutPanel3.Controls.Add(this.label62, 1, 16);
            this.tableLayoutPanel3.Controls.Add(this.label63, 0, 16);
            this.tableLayoutPanel3.Controls.Add(this.labs, 1, 15);
            this.tableLayoutPanel3.Controls.Add(this.label65, 0, 15);
            this.tableLayoutPanel3.Controls.Add(this.label66, 1, 14);
            this.tableLayoutPanel3.Controls.Add(this.label67, 0, 14);
            this.tableLayoutPanel3.Controls.Add(this.label68, 1, 13);
            this.tableLayoutPanel3.Controls.Add(this.label69, 0, 13);
            this.tableLayoutPanel3.Controls.Add(this.label70, 1, 12);
            this.tableLayoutPanel3.Controls.Add(this.label71, 0, 12);
            this.tableLayoutPanel3.Controls.Add(this.label72, 1, 11);
            this.tableLayoutPanel3.Controls.Add(this.label73, 0, 11);
            this.tableLayoutPanel3.Controls.Add(this.label74, 1, 10);
            this.tableLayoutPanel3.Controls.Add(this.label75, 0, 10);
            this.tableLayoutPanel3.Controls.Add(this.label76, 1, 9);
            this.tableLayoutPanel3.Controls.Add(this.label77, 0, 9);
            this.tableLayoutPanel3.Controls.Add(this.label78, 1, 8);
            this.tableLayoutPanel3.Controls.Add(this.label79, 0, 8);
            this.tableLayoutPanel3.Controls.Add(this.label80, 1, 7);
            this.tableLayoutPanel3.Controls.Add(this.label81, 1, 6);
            this.tableLayoutPanel3.Controls.Add(this.label82, 1, 5);
            this.tableLayoutPanel3.Controls.Add(this.label83, 1, 4);
            this.tableLayoutPanel3.Controls.Add(this.label85, 1, 3);
            this.tableLayoutPanel3.Controls.Add(this.label86, 1, 2);
            this.tableLayoutPanel3.Controls.Add(this.label87, 1, 1);
            this.tableLayoutPanel3.Controls.Add(this.label88, 2, 0);
            this.tableLayoutPanel3.Controls.Add(this.label89, 0, 0);
            this.tableLayoutPanel3.Controls.Add(this.label90, 1, 0);
            this.tableLayoutPanel3.Controls.Add(this.label91, 0, 1);
            this.tableLayoutPanel3.Controls.Add(this.label92, 0, 2);
            this.tableLayoutPanel3.Controls.Add(this.label93, 0, 3);
            this.tableLayoutPanel3.Controls.Add(this.label94, 0, 4);
            this.tableLayoutPanel3.Controls.Add(this.label95, 0, 5);
            this.tableLayoutPanel3.Controls.Add(this.label96, 0, 6);
            this.tableLayoutPanel3.Controls.Add(this.label97, 0, 7);
            this.tableLayoutPanel3.Controls.Add(this.link_payroll, 2, 1);
            this.tableLayoutPanel3.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tableLayoutPanel3.Location = new System.Drawing.Point(432, 3);
            this.tableLayoutPanel3.Name = "tableLayoutPanel3";
            this.tableLayoutPanel3.RowCount = 19;
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel3.Size = new System.Drawing.Size(372, 380);
            this.tableLayoutPanel3.TabIndex = 87;
            // 
            // linkLabel21
            // 
            this.linkLabel21.AutoSize = true;
            this.linkLabel21.Dock = System.Windows.Forms.DockStyle.Fill;
            this.linkLabel21.Location = new System.Drawing.Point(295, 360);
            this.linkLabel21.Name = "linkLabel21";
            this.linkLabel21.Size = new System.Drawing.Size(44, 20);
            this.linkLabel21.TabIndex = 147;
            this.linkLabel21.TabStop = true;
            this.linkLabel21.Text = "File";
            this.linkLabel21.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // checkBox38
            // 
            this.checkBox38.AutoSize = true;
            this.checkBox38.Dock = System.Windows.Forms.DockStyle.Fill;
            this.checkBox38.Location = new System.Drawing.Point(345, 363);
            this.checkBox38.Name = "checkBox38";
            this.checkBox38.Size = new System.Drawing.Size(29, 14);
            this.checkBox38.TabIndex = 146;
            this.checkBox38.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.checkBox38.UseVisualStyleBackColor = true;
            // 
            // checkBox37
            // 
            this.checkBox37.AutoSize = true;
            this.checkBox37.Dock = System.Windows.Forms.DockStyle.Fill;
            this.checkBox37.Location = new System.Drawing.Point(345, 343);
            this.checkBox37.Name = "checkBox37";
            this.checkBox37.Size = new System.Drawing.Size(29, 14);
            this.checkBox37.TabIndex = 145;
            this.checkBox37.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.checkBox37.UseVisualStyleBackColor = true;
            // 
            // checkBox36
            // 
            this.checkBox36.AutoSize = true;
            this.checkBox36.Dock = System.Windows.Forms.DockStyle.Fill;
            this.checkBox36.Location = new System.Drawing.Point(345, 323);
            this.checkBox36.Name = "checkBox36";
            this.checkBox36.Size = new System.Drawing.Size(29, 14);
            this.checkBox36.TabIndex = 144;
            this.checkBox36.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.checkBox36.UseVisualStyleBackColor = true;
            // 
            // checkBox35
            // 
            this.checkBox35.AutoSize = true;
            this.checkBox35.Dock = System.Windows.Forms.DockStyle.Fill;
            this.checkBox35.Location = new System.Drawing.Point(345, 303);
            this.checkBox35.Name = "checkBox35";
            this.checkBox35.Size = new System.Drawing.Size(29, 14);
            this.checkBox35.TabIndex = 143;
            this.checkBox35.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.checkBox35.UseVisualStyleBackColor = true;
            // 
            // checkBox34
            // 
            this.checkBox34.AutoSize = true;
            this.checkBox34.Dock = System.Windows.Forms.DockStyle.Fill;
            this.checkBox34.Location = new System.Drawing.Point(345, 283);
            this.checkBox34.Name = "checkBox34";
            this.checkBox34.Size = new System.Drawing.Size(29, 14);
            this.checkBox34.TabIndex = 142;
            this.checkBox34.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.checkBox34.UseVisualStyleBackColor = true;
            // 
            // checkBox33
            // 
            this.checkBox33.AutoSize = true;
            this.checkBox33.Dock = System.Windows.Forms.DockStyle.Fill;
            this.checkBox33.Location = new System.Drawing.Point(345, 263);
            this.checkBox33.Name = "checkBox33";
            this.checkBox33.Size = new System.Drawing.Size(29, 14);
            this.checkBox33.TabIndex = 141;
            this.checkBox33.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.checkBox33.UseVisualStyleBackColor = true;
            // 
            // checkBox32
            // 
            this.checkBox32.AutoSize = true;
            this.checkBox32.Dock = System.Windows.Forms.DockStyle.Fill;
            this.checkBox32.Location = new System.Drawing.Point(345, 243);
            this.checkBox32.Name = "checkBox32";
            this.checkBox32.Size = new System.Drawing.Size(29, 14);
            this.checkBox32.TabIndex = 140;
            this.checkBox32.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.checkBox32.UseVisualStyleBackColor = true;
            // 
            // checkBox31
            // 
            this.checkBox31.AutoSize = true;
            this.checkBox31.Dock = System.Windows.Forms.DockStyle.Fill;
            this.checkBox31.Location = new System.Drawing.Point(345, 223);
            this.checkBox31.Name = "checkBox31";
            this.checkBox31.Size = new System.Drawing.Size(29, 14);
            this.checkBox31.TabIndex = 139;
            this.checkBox31.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.checkBox31.UseVisualStyleBackColor = true;
            // 
            // checkBox30
            // 
            this.checkBox30.AutoSize = true;
            this.checkBox30.Dock = System.Windows.Forms.DockStyle.Fill;
            this.checkBox30.Location = new System.Drawing.Point(345, 203);
            this.checkBox30.Name = "checkBox30";
            this.checkBox30.Size = new System.Drawing.Size(29, 14);
            this.checkBox30.TabIndex = 138;
            this.checkBox30.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.checkBox30.UseVisualStyleBackColor = true;
            // 
            // checkBox29
            // 
            this.checkBox29.AutoSize = true;
            this.checkBox29.Dock = System.Windows.Forms.DockStyle.Fill;
            this.checkBox29.Location = new System.Drawing.Point(345, 183);
            this.checkBox29.Name = "checkBox29";
            this.checkBox29.Size = new System.Drawing.Size(29, 14);
            this.checkBox29.TabIndex = 137;
            this.checkBox29.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.checkBox29.UseVisualStyleBackColor = true;
            // 
            // checkBox28
            // 
            this.checkBox28.AutoSize = true;
            this.checkBox28.Dock = System.Windows.Forms.DockStyle.Fill;
            this.checkBox28.Location = new System.Drawing.Point(345, 163);
            this.checkBox28.Name = "checkBox28";
            this.checkBox28.Size = new System.Drawing.Size(29, 14);
            this.checkBox28.TabIndex = 136;
            this.checkBox28.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.checkBox28.UseVisualStyleBackColor = true;
            // 
            // checkBox27
            // 
            this.checkBox27.AutoSize = true;
            this.checkBox27.Dock = System.Windows.Forms.DockStyle.Fill;
            this.checkBox27.Location = new System.Drawing.Point(345, 143);
            this.checkBox27.Name = "checkBox27";
            this.checkBox27.Size = new System.Drawing.Size(29, 14);
            this.checkBox27.TabIndex = 135;
            this.checkBox27.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.checkBox27.UseVisualStyleBackColor = true;
            // 
            // checkBox26
            // 
            this.checkBox26.AutoSize = true;
            this.checkBox26.Dock = System.Windows.Forms.DockStyle.Fill;
            this.checkBox26.Location = new System.Drawing.Point(345, 123);
            this.checkBox26.Name = "checkBox26";
            this.checkBox26.Size = new System.Drawing.Size(29, 14);
            this.checkBox26.TabIndex = 134;
            this.checkBox26.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.checkBox26.UseVisualStyleBackColor = true;
            // 
            // checkBox25
            // 
            this.checkBox25.AutoSize = true;
            this.checkBox25.Dock = System.Windows.Forms.DockStyle.Fill;
            this.checkBox25.Location = new System.Drawing.Point(345, 103);
            this.checkBox25.Name = "checkBox25";
            this.checkBox25.Size = new System.Drawing.Size(29, 14);
            this.checkBox25.TabIndex = 133;
            this.checkBox25.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.checkBox25.UseVisualStyleBackColor = true;
            // 
            // checkBox24
            // 
            this.checkBox24.AutoSize = true;
            this.checkBox24.Dock = System.Windows.Forms.DockStyle.Fill;
            this.checkBox24.Location = new System.Drawing.Point(345, 83);
            this.checkBox24.Name = "checkBox24";
            this.checkBox24.Size = new System.Drawing.Size(29, 14);
            this.checkBox24.TabIndex = 132;
            this.checkBox24.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.checkBox24.UseVisualStyleBackColor = true;
            // 
            // checkBox23
            // 
            this.checkBox23.AutoSize = true;
            this.checkBox23.Dock = System.Windows.Forms.DockStyle.Fill;
            this.checkBox23.Location = new System.Drawing.Point(345, 63);
            this.checkBox23.Name = "checkBox23";
            this.checkBox23.Size = new System.Drawing.Size(29, 14);
            this.checkBox23.TabIndex = 131;
            this.checkBox23.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.checkBox23.UseVisualStyleBackColor = true;
            // 
            // checkBox22
            // 
            this.checkBox22.AutoSize = true;
            this.checkBox22.Dock = System.Windows.Forms.DockStyle.Fill;
            this.checkBox22.Location = new System.Drawing.Point(345, 43);
            this.checkBox22.Name = "checkBox22";
            this.checkBox22.Size = new System.Drawing.Size(29, 14);
            this.checkBox22.TabIndex = 130;
            this.checkBox22.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.checkBox22.UseVisualStyleBackColor = true;
            // 
            // checkBox21
            // 
            this.checkBox21.AutoSize = true;
            this.checkBox21.Dock = System.Windows.Forms.DockStyle.Fill;
            this.checkBox21.Location = new System.Drawing.Point(345, 23);
            this.checkBox21.Name = "checkBox21";
            this.checkBox21.Size = new System.Drawing.Size(29, 14);
            this.checkBox21.TabIndex = 129;
            this.checkBox21.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.checkBox21.UseVisualStyleBackColor = true;
            // 
            // label84
            // 
            this.label84.AutoSize = true;
            this.label84.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label84.Location = new System.Drawing.Point(3, 360);
            this.label84.Name = "label84";
            this.label84.Size = new System.Drawing.Size(21, 20);
            this.label84.TabIndex = 98;
            this.label84.Text = "18";
            this.label84.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label59
            // 
            this.label59.AutoSize = true;
            this.label59.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label59.Location = new System.Drawing.Point(30, 360);
            this.label59.Name = "label59";
            this.label59.Size = new System.Drawing.Size(259, 20);
            this.label59.TabIndex = 97;
            this.label59.Text = "Data Privacy Consent";
            this.label59.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // link_locker
            // 
            this.link_locker.AutoSize = true;
            this.link_locker.Dock = System.Windows.Forms.DockStyle.Fill;
            this.link_locker.Location = new System.Drawing.Point(295, 340);
            this.link_locker.Name = "link_locker";
            this.link_locker.Size = new System.Drawing.Size(44, 20);
            this.link_locker.TabIndex = 94;
            this.link_locker.TabStop = true;
            this.link_locker.Text = "File";
            this.link_locker.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // link_IdentificationCard
            // 
            this.link_IdentificationCard.AutoSize = true;
            this.link_IdentificationCard.Dock = System.Windows.Forms.DockStyle.Fill;
            this.link_IdentificationCard.Location = new System.Drawing.Point(295, 320);
            this.link_IdentificationCard.Name = "link_IdentificationCard";
            this.link_IdentificationCard.Size = new System.Drawing.Size(44, 20);
            this.link_IdentificationCard.TabIndex = 93;
            this.link_IdentificationCard.TabStop = true;
            this.link_IdentificationCard.Text = "File";
            this.link_IdentificationCard.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // link_acceptablePolicy
            // 
            this.link_acceptablePolicy.AutoSize = true;
            this.link_acceptablePolicy.Dock = System.Windows.Forms.DockStyle.Fill;
            this.link_acceptablePolicy.Location = new System.Drawing.Point(295, 300);
            this.link_acceptablePolicy.Name = "link_acceptablePolicy";
            this.link_acceptablePolicy.Size = new System.Drawing.Size(44, 20);
            this.link_acceptablePolicy.TabIndex = 92;
            this.link_acceptablePolicy.TabStop = true;
            this.link_acceptablePolicy.Text = "File";
            this.link_acceptablePolicy.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // linkLabel35
            // 
            this.linkLabel35.AutoSize = true;
            this.linkLabel35.Dock = System.Windows.Forms.DockStyle.Fill;
            this.linkLabel35.Location = new System.Drawing.Point(295, 280);
            this.linkLabel35.Name = "linkLabel35";
            this.linkLabel35.Size = new System.Drawing.Size(44, 20);
            this.linkLabel35.TabIndex = 91;
            this.linkLabel35.TabStop = true;
            this.linkLabel35.Text = "File";
            this.linkLabel35.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // link_consent
            // 
            this.link_consent.AutoSize = true;
            this.link_consent.Dock = System.Windows.Forms.DockStyle.Fill;
            this.link_consent.Location = new System.Drawing.Point(295, 260);
            this.link_consent.Name = "link_consent";
            this.link_consent.Size = new System.Drawing.Size(44, 20);
            this.link_consent.TabIndex = 90;
            this.link_consent.TabStop = true;
            this.link_consent.Text = "File";
            this.link_consent.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // link_acceptanceCOC
            // 
            this.link_acceptanceCOC.AutoSize = true;
            this.link_acceptanceCOC.Dock = System.Windows.Forms.DockStyle.Fill;
            this.link_acceptanceCOC.Location = new System.Drawing.Point(295, 240);
            this.link_acceptanceCOC.Name = "link_acceptanceCOC";
            this.link_acceptanceCOC.Size = new System.Drawing.Size(44, 20);
            this.link_acceptanceCOC.TabIndex = 89;
            this.link_acceptanceCOC.TabStop = true;
            this.link_acceptanceCOC.Text = "File";
            this.link_acceptanceCOC.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // link_acceptance_COD
            // 
            this.link_acceptance_COD.AutoSize = true;
            this.link_acceptance_COD.Dock = System.Windows.Forms.DockStyle.Fill;
            this.link_acceptance_COD.Location = new System.Drawing.Point(295, 220);
            this.link_acceptance_COD.Name = "link_acceptance_COD";
            this.link_acceptance_COD.Size = new System.Drawing.Size(44, 20);
            this.link_acceptance_COD.TabIndex = 88;
            this.link_acceptance_COD.TabStop = true;
            this.link_acceptance_COD.Text = "File";
            this.link_acceptance_COD.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // link_NSOmarriage
            // 
            this.link_NSOmarriage.AutoSize = true;
            this.link_NSOmarriage.Dock = System.Windows.Forms.DockStyle.Fill;
            this.link_NSOmarriage.Location = new System.Drawing.Point(295, 200);
            this.link_NSOmarriage.Name = "link_NSOmarriage";
            this.link_NSOmarriage.Size = new System.Drawing.Size(44, 20);
            this.link_NSOmarriage.TabIndex = 87;
            this.link_NSOmarriage.TabStop = true;
            this.link_NSOmarriage.Text = "File";
            this.link_NSOmarriage.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // link_NSOdependent
            // 
            this.link_NSOdependent.AutoSize = true;
            this.link_NSOdependent.Dock = System.Windows.Forms.DockStyle.Fill;
            this.link_NSOdependent.Location = new System.Drawing.Point(295, 180);
            this.link_NSOdependent.Name = "link_NSOdependent";
            this.link_NSOdependent.Size = new System.Drawing.Size(44, 20);
            this.link_NSOdependent.TabIndex = 86;
            this.link_NSOdependent.TabStop = true;
            this.link_NSOdependent.Text = "File";
            this.link_NSOdependent.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // link_cedula
            // 
            this.link_cedula.AutoSize = true;
            this.link_cedula.Dock = System.Windows.Forms.DockStyle.Fill;
            this.link_cedula.Location = new System.Drawing.Point(295, 160);
            this.link_cedula.Name = "link_cedula";
            this.link_cedula.Size = new System.Drawing.Size(44, 20);
            this.link_cedula.TabIndex = 85;
            this.link_cedula.TabStop = true;
            this.link_cedula.Text = "File";
            this.link_cedula.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // link_OccupationalPermit
            // 
            this.link_OccupationalPermit.AutoSize = true;
            this.link_OccupationalPermit.Dock = System.Windows.Forms.DockStyle.Fill;
            this.link_OccupationalPermit.Location = new System.Drawing.Point(295, 140);
            this.link_OccupationalPermit.Name = "link_OccupationalPermit";
            this.link_OccupationalPermit.Size = new System.Drawing.Size(44, 20);
            this.link_OccupationalPermit.TabIndex = 84;
            this.link_OccupationalPermit.TabStop = true;
            this.link_OccupationalPermit.Text = "File";
            this.link_OccupationalPermit.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // link_2316
            // 
            this.link_2316.AutoSize = true;
            this.link_2316.Dock = System.Windows.Forms.DockStyle.Fill;
            this.link_2316.Location = new System.Drawing.Point(295, 120);
            this.link_2316.Name = "link_2316";
            this.link_2316.Size = new System.Drawing.Size(44, 20);
            this.link_2316.TabIndex = 83;
            this.link_2316.TabStop = true;
            this.link_2316.Text = "File";
            this.link_2316.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // link_2305
            // 
            this.link_2305.AutoSize = true;
            this.link_2305.Dock = System.Windows.Forms.DockStyle.Fill;
            this.link_2305.Location = new System.Drawing.Point(295, 100);
            this.link_2305.Name = "link_2305";
            this.link_2305.Size = new System.Drawing.Size(44, 20);
            this.link_2305.TabIndex = 82;
            this.link_2305.TabStop = true;
            this.link_2305.Text = "File";
            this.link_2305.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // link_1905
            // 
            this.link_1905.AutoSize = true;
            this.link_1905.Dock = System.Windows.Forms.DockStyle.Fill;
            this.link_1905.Location = new System.Drawing.Point(295, 80);
            this.link_1905.Name = "link_1905";
            this.link_1905.Size = new System.Drawing.Size(44, 20);
            this.link_1905.TabIndex = 81;
            this.link_1905.TabStop = true;
            this.link_1905.Text = "File";
            this.link_1905.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // link_bankForm
            // 
            this.link_bankForm.AutoSize = true;
            this.link_bankForm.Dock = System.Windows.Forms.DockStyle.Fill;
            this.link_bankForm.Location = new System.Drawing.Point(295, 60);
            this.link_bankForm.Name = "link_bankForm";
            this.link_bankForm.Size = new System.Drawing.Size(44, 20);
            this.link_bankForm.TabIndex = 80;
            this.link_bankForm.TabStop = true;
            this.link_bankForm.Text = "File";
            this.link_bankForm.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // link_HMO
            // 
            this.link_HMO.AutoSize = true;
            this.link_HMO.Dock = System.Windows.Forms.DockStyle.Fill;
            this.link_HMO.Location = new System.Drawing.Point(295, 40);
            this.link_HMO.Name = "link_HMO";
            this.link_HMO.Size = new System.Drawing.Size(44, 20);
            this.link_HMO.TabIndex = 79;
            this.link_HMO.TabStop = true;
            this.link_HMO.Text = "File";
            this.link_HMO.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label60
            // 
            this.label60.AutoSize = true;
            this.label60.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label60.Location = new System.Drawing.Point(30, 340);
            this.label60.Name = "label60";
            this.label60.Size = new System.Drawing.Size(259, 20);
            this.label60.TabIndex = 77;
            this.label60.Text = "Locker Accountability && Usage Policy";
            this.label60.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label61
            // 
            this.label61.AutoSize = true;
            this.label61.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label61.Location = new System.Drawing.Point(3, 340);
            this.label61.Name = "label61";
            this.label61.Size = new System.Drawing.Size(21, 20);
            this.label61.TabIndex = 76;
            this.label61.Text = "17";
            this.label61.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label62
            // 
            this.label62.AutoSize = true;
            this.label62.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label62.Location = new System.Drawing.Point(30, 320);
            this.label62.Name = "label62";
            this.label62.Size = new System.Drawing.Size(259, 20);
            this.label62.TabIndex = 75;
            this.label62.Text = "Identification Card && ID Badge";
            this.label62.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label63
            // 
            this.label63.AutoSize = true;
            this.label63.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label63.Location = new System.Drawing.Point(3, 320);
            this.label63.Name = "label63";
            this.label63.Size = new System.Drawing.Size(21, 20);
            this.label63.TabIndex = 74;
            this.label63.Text = "16";
            this.label63.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // labs
            // 
            this.labs.AutoSize = true;
            this.labs.Dock = System.Windows.Forms.DockStyle.Fill;
            this.labs.Location = new System.Drawing.Point(30, 300);
            this.labs.Name = "labs";
            this.labs.Size = new System.Drawing.Size(259, 20);
            this.labs.TabIndex = 73;
            this.labs.Text = "Acceptable Use Policy";
            this.labs.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label65
            // 
            this.label65.AutoSize = true;
            this.label65.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label65.Location = new System.Drawing.Point(3, 300);
            this.label65.Name = "label65";
            this.label65.Size = new System.Drawing.Size(21, 20);
            this.label65.TabIndex = 72;
            this.label65.Text = "15";
            this.label65.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label66
            // 
            this.label66.AutoSize = true;
            this.label66.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label66.Location = new System.Drawing.Point(30, 280);
            this.label66.Name = "label66";
            this.label66.Size = new System.Drawing.Size(259, 20);
            this.label66.TabIndex = 71;
            this.label66.Text = "Consent && Waiver for Call Recording";
            this.label66.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label67
            // 
            this.label67.AutoSize = true;
            this.label67.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label67.Location = new System.Drawing.Point(3, 280);
            this.label67.Name = "label67";
            this.label67.Size = new System.Drawing.Size(21, 20);
            this.label67.TabIndex = 70;
            this.label67.Text = "14";
            this.label67.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label68
            // 
            this.label68.AutoSize = true;
            this.label68.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label68.Location = new System.Drawing.Point(30, 260);
            this.label68.Name = "label68";
            this.label68.Size = new System.Drawing.Size(259, 20);
            this.label68.TabIndex = 69;
            this.label68.Text = "Confidentiality Agreement";
            this.label68.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label69
            // 
            this.label69.AutoSize = true;
            this.label69.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label69.Location = new System.Drawing.Point(3, 260);
            this.label69.Name = "label69";
            this.label69.Size = new System.Drawing.Size(21, 20);
            this.label69.TabIndex = 68;
            this.label69.Text = "13";
            this.label69.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label70
            // 
            this.label70.AutoSize = true;
            this.label70.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label70.Location = new System.Drawing.Point(30, 240);
            this.label70.Name = "label70";
            this.label70.Size = new System.Drawing.Size(259, 20);
            this.label70.TabIndex = 67;
            this.label70.Text = "Acceptance of Code of Conduct";
            this.label70.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label71
            // 
            this.label71.AutoSize = true;
            this.label71.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label71.Location = new System.Drawing.Point(3, 240);
            this.label71.Name = "label71";
            this.label71.Size = new System.Drawing.Size(21, 20);
            this.label71.TabIndex = 66;
            this.label71.Text = "12";
            this.label71.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label72
            // 
            this.label72.AutoSize = true;
            this.label72.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label72.Location = new System.Drawing.Point(30, 220);
            this.label72.Name = "label72";
            this.label72.Size = new System.Drawing.Size(259, 20);
            this.label72.TabIndex = 65;
            this.label72.Text = "Acceptance of Code of Discipline";
            this.label72.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label73
            // 
            this.label73.AutoSize = true;
            this.label73.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label73.Location = new System.Drawing.Point(3, 220);
            this.label73.Name = "label73";
            this.label73.Size = new System.Drawing.Size(21, 20);
            this.label73.TabIndex = 64;
            this.label73.Text = "11";
            this.label73.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label74
            // 
            this.label74.AutoSize = true;
            this.label74.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label74.Location = new System.Drawing.Point(30, 200);
            this.label74.Name = "label74";
            this.label74.Size = new System.Drawing.Size(259, 20);
            this.label74.TabIndex = 63;
            this.label74.Text = "NSO Marriage Certificate (4 copies)";
            this.label74.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label75
            // 
            this.label75.AutoSize = true;
            this.label75.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label75.Location = new System.Drawing.Point(3, 200);
            this.label75.Name = "label75";
            this.label75.Size = new System.Drawing.Size(21, 20);
            this.label75.TabIndex = 62;
            this.label75.Text = "10";
            this.label75.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label76
            // 
            this.label76.AutoSize = true;
            this.label76.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label76.Location = new System.Drawing.Point(30, 180);
            this.label76.Name = "label76";
            this.label76.Size = new System.Drawing.Size(259, 20);
            this.label76.TabIndex = 61;
            this.label76.Text = "NSO Dependent/s\' Birth Certificate (4 copies)";
            this.label76.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label77
            // 
            this.label77.AutoSize = true;
            this.label77.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label77.Location = new System.Drawing.Point(3, 180);
            this.label77.Name = "label77";
            this.label77.Size = new System.Drawing.Size(21, 20);
            this.label77.TabIndex = 60;
            this.label77.Text = "9";
            this.label77.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label78
            // 
            this.label78.AutoSize = true;
            this.label78.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label78.Location = new System.Drawing.Point(30, 160);
            this.label78.Name = "label78";
            this.label78.Size = new System.Drawing.Size(259, 20);
            this.label78.TabIndex = 59;
            this.label78.Text = "Cedula";
            this.label78.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label79
            // 
            this.label79.AutoSize = true;
            this.label79.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label79.Location = new System.Drawing.Point(3, 160);
            this.label79.Name = "label79";
            this.label79.Size = new System.Drawing.Size(21, 20);
            this.label79.TabIndex = 58;
            this.label79.Text = "8";
            this.label79.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label80
            // 
            this.label80.AutoSize = true;
            this.label80.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label80.Location = new System.Drawing.Point(30, 140);
            this.label80.Name = "label80";
            this.label80.Size = new System.Drawing.Size(259, 20);
            this.label80.TabIndex = 57;
            this.label80.Text = "Occupational Permit";
            this.label80.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label81
            // 
            this.label81.AutoSize = true;
            this.label81.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label81.Location = new System.Drawing.Point(30, 120);
            this.label81.Name = "label81";
            this.label81.Size = new System.Drawing.Size(259, 20);
            this.label81.TabIndex = 56;
            this.label81.Text = "BIR 2316 or BIR 2316 with waiver";
            this.label81.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label82
            // 
            this.label82.AutoSize = true;
            this.label82.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label82.Location = new System.Drawing.Point(30, 100);
            this.label82.Name = "label82";
            this.label82.Size = new System.Drawing.Size(259, 20);
            this.label82.TabIndex = 55;
            this.label82.Text = "BIR 2305";
            this.label82.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label83
            // 
            this.label83.AutoSize = true;
            this.label83.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label83.Location = new System.Drawing.Point(30, 80);
            this.label83.Name = "label83";
            this.label83.Size = new System.Drawing.Size(259, 20);
            this.label83.TabIndex = 54;
            this.label83.Text = "BIR 1905";
            this.label83.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label85
            // 
            this.label85.AutoSize = true;
            this.label85.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label85.Location = new System.Drawing.Point(30, 60);
            this.label85.Name = "label85";
            this.label85.Size = new System.Drawing.Size(259, 20);
            this.label85.TabIndex = 53;
            this.label85.Text = "Bank Forms";
            this.label85.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label86
            // 
            this.label86.AutoSize = true;
            this.label86.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label86.Location = new System.Drawing.Point(30, 40);
            this.label86.Name = "label86";
            this.label86.Size = new System.Drawing.Size(259, 20);
            this.label86.TabIndex = 52;
            this.label86.Text = "HMO/AXA Form";
            this.label86.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label87
            // 
            this.label87.AutoSize = true;
            this.label87.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label87.Location = new System.Drawing.Point(30, 20);
            this.label87.Name = "label87";
            this.label87.Size = new System.Drawing.Size(259, 20);
            this.label87.TabIndex = 51;
            this.label87.Text = "Payroll Data Form";
            this.label87.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label88
            // 
            this.label88.AutoSize = true;
            this.label88.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.label88.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label88.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label88.Location = new System.Drawing.Point(292, 0);
            this.label88.Margin = new System.Windows.Forms.Padding(0);
            this.label88.Name = "label88";
            this.label88.Size = new System.Drawing.Size(50, 20);
            this.label88.TabIndex = 2;
            this.label88.Text = "@@";
            this.label88.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label89
            // 
            this.label89.AutoSize = true;
            this.label89.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.label89.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label89.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label89.Location = new System.Drawing.Point(0, 0);
            this.label89.Margin = new System.Windows.Forms.Padding(0);
            this.label89.Name = "label89";
            this.label89.Size = new System.Drawing.Size(27, 20);
            this.label89.TabIndex = 1;
            this.label89.Text = "#";
            this.label89.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label90
            // 
            this.label90.AutoSize = true;
            this.label90.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.label90.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label90.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label90.Location = new System.Drawing.Point(27, 0);
            this.label90.Margin = new System.Windows.Forms.Padding(0);
            this.label90.Name = "label90";
            this.label90.Size = new System.Drawing.Size(265, 20);
            this.label90.TabIndex = 0;
            this.label90.Text = "Secondary Requirements";
            this.label90.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label91
            // 
            this.label91.AutoSize = true;
            this.label91.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label91.Location = new System.Drawing.Point(3, 20);
            this.label91.Name = "label91";
            this.label91.Size = new System.Drawing.Size(21, 20);
            this.label91.TabIndex = 44;
            this.label91.Text = "1";
            this.label91.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label92
            // 
            this.label92.AutoSize = true;
            this.label92.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label92.Location = new System.Drawing.Point(3, 40);
            this.label92.Name = "label92";
            this.label92.Size = new System.Drawing.Size(21, 20);
            this.label92.TabIndex = 45;
            this.label92.Text = "2";
            this.label92.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label93
            // 
            this.label93.AutoSize = true;
            this.label93.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label93.Location = new System.Drawing.Point(3, 60);
            this.label93.Name = "label93";
            this.label93.Size = new System.Drawing.Size(21, 20);
            this.label93.TabIndex = 46;
            this.label93.Text = "3";
            this.label93.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label94
            // 
            this.label94.AutoSize = true;
            this.label94.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label94.Location = new System.Drawing.Point(3, 80);
            this.label94.Name = "label94";
            this.label94.Size = new System.Drawing.Size(21, 20);
            this.label94.TabIndex = 47;
            this.label94.Text = "4";
            this.label94.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label95
            // 
            this.label95.AutoSize = true;
            this.label95.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label95.Location = new System.Drawing.Point(3, 100);
            this.label95.Name = "label95";
            this.label95.Size = new System.Drawing.Size(21, 20);
            this.label95.TabIndex = 48;
            this.label95.Text = "5";
            this.label95.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label96
            // 
            this.label96.AutoSize = true;
            this.label96.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label96.Location = new System.Drawing.Point(3, 120);
            this.label96.Name = "label96";
            this.label96.Size = new System.Drawing.Size(21, 20);
            this.label96.TabIndex = 49;
            this.label96.Text = "6";
            this.label96.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label97
            // 
            this.label97.AutoSize = true;
            this.label97.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label97.Location = new System.Drawing.Point(3, 140);
            this.label97.Name = "label97";
            this.label97.Size = new System.Drawing.Size(21, 20);
            this.label97.TabIndex = 50;
            this.label97.Text = "7";
            this.label97.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // link_payroll
            // 
            this.link_payroll.AutoSize = true;
            this.link_payroll.Dock = System.Windows.Forms.DockStyle.Fill;
            this.link_payroll.Location = new System.Drawing.Point(295, 20);
            this.link_payroll.Name = "link_payroll";
            this.link_payroll.Size = new System.Drawing.Size(44, 20);
            this.link_payroll.TabIndex = 78;
            this.link_payroll.TabStop = true;
            this.link_payroll.Text = "File";
            this.link_payroll.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tableLayoutPanel2
            // 
            this.tableLayoutPanel2.ColumnCount = 4;
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 27F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 264F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 51F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 36F));
            this.tableLayoutPanel2.Controls.Add(this.checkBox20, 3, 20);
            this.tableLayoutPanel2.Controls.Add(this.checkBox19, 3, 19);
            this.tableLayoutPanel2.Controls.Add(this.checkBox18, 3, 18);
            this.tableLayoutPanel2.Controls.Add(this.checkBox17, 3, 17);
            this.tableLayoutPanel2.Controls.Add(this.checkBox16, 3, 16);
            this.tableLayoutPanel2.Controls.Add(this.checkBox15, 3, 15);
            this.tableLayoutPanel2.Controls.Add(this.checkBox14, 3, 14);
            this.tableLayoutPanel2.Controls.Add(this.checkBox13, 3, 13);
            this.tableLayoutPanel2.Controls.Add(this.checkBox12, 3, 12);
            this.tableLayoutPanel2.Controls.Add(this.checkBox11, 3, 11);
            this.tableLayoutPanel2.Controls.Add(this.checkBox10, 3, 10);
            this.tableLayoutPanel2.Controls.Add(this.checkBox9, 3, 9);
            this.tableLayoutPanel2.Controls.Add(this.checkBox8, 3, 8);
            this.tableLayoutPanel2.Controls.Add(this.checkBox7, 3, 7);
            this.tableLayoutPanel2.Controls.Add(this.checkBox6, 3, 6);
            this.tableLayoutPanel2.Controls.Add(this.checkBox5, 3, 5);
            this.tableLayoutPanel2.Controls.Add(this.checkBox4, 3, 4);
            this.tableLayoutPanel2.Controls.Add(this.checkBox3, 3, 3);
            this.tableLayoutPanel2.Controls.Add(this.checkBox2, 3, 2);
            this.tableLayoutPanel2.Controls.Add(this.linkLabel20, 2, 20);
            this.tableLayoutPanel2.Controls.Add(this.label10, 0, 20);
            this.tableLayoutPanel2.Controls.Add(this.label21, 1, 3);
            this.tableLayoutPanel2.Controls.Add(this.label22, 1, 4);
            this.tableLayoutPanel2.Controls.Add(this.label23, 1, 5);
            this.tableLayoutPanel2.Controls.Add(this.label24, 1, 6);
            this.tableLayoutPanel2.Controls.Add(this.label25, 1, 7);
            this.tableLayoutPanel2.Controls.Add(this.label27, 1, 8);
            this.tableLayoutPanel2.Controls.Add(this.label29, 1, 9);
            this.tableLayoutPanel2.Controls.Add(this.label31, 1, 10);
            this.tableLayoutPanel2.Controls.Add(this.label33, 1, 11);
            this.tableLayoutPanel2.Controls.Add(this.label35, 1, 12);
            this.tableLayoutPanel2.Controls.Add(this.label37, 1, 13);
            this.tableLayoutPanel2.Controls.Add(this.label39, 1, 14);
            this.tableLayoutPanel2.Controls.Add(this.label41, 1, 15);
            this.tableLayoutPanel2.Controls.Add(this.label43, 1, 16);
            this.tableLayoutPanel2.Controls.Add(this.label45, 1, 17);
            this.tableLayoutPanel2.Controls.Add(this.label47, 1, 18);
            this.tableLayoutPanel2.Controls.Add(this.label49, 1, 19);
            this.tableLayoutPanel2.Controls.Add(this.label51, 1, 20);
            this.tableLayoutPanel2.Controls.Add(this.linkLabel19, 2, 19);
            this.tableLayoutPanel2.Controls.Add(this.linkLabel18, 2, 18);
            this.tableLayoutPanel2.Controls.Add(this.link_informationForm, 2, 17);
            this.tableLayoutPanel2.Controls.Add(this.link_backgroundResult, 2, 16);
            this.tableLayoutPanel2.Controls.Add(this.link_backgroundCheck, 2, 15);
            this.tableLayoutPanel2.Controls.Add(this.link_resume, 2, 14);
            this.tableLayoutPanel2.Controls.Add(this.link_InterviewDocs, 2, 13);
            this.tableLayoutPanel2.Controls.Add(this.link_NDA, 2, 12);
            this.tableLayoutPanel2.Controls.Add(this.link_NewHire, 2, 11);
            this.tableLayoutPanel2.Controls.Add(this.link_SNO, 2, 10);
            this.tableLayoutPanel2.Controls.Add(this.link_TOR, 2, 9);
            this.tableLayoutPanel2.Controls.Add(this.link_COE, 2, 8);
            this.tableLayoutPanel2.Controls.Add(this.link_NBI, 2, 7);
            this.tableLayoutPanel2.Controls.Add(this.lin_IDPicture, 2, 6);
            this.tableLayoutPanel2.Controls.Add(this.link_validID, 2, 5);
            this.tableLayoutPanel2.Controls.Add(this.link_ProofOfPagibig, 2, 4);
            this.tableLayoutPanel2.Controls.Add(this.link_proofOfPhilHealth, 2, 3);
            this.tableLayoutPanel2.Controls.Add(this.link_proofOfSSS, 2, 2);
            this.tableLayoutPanel2.Controls.Add(this.label48, 0, 19);
            this.tableLayoutPanel2.Controls.Add(this.label46, 0, 18);
            this.tableLayoutPanel2.Controls.Add(this.label44, 0, 17);
            this.tableLayoutPanel2.Controls.Add(this.label42, 0, 16);
            this.tableLayoutPanel2.Controls.Add(this.label40, 0, 15);
            this.tableLayoutPanel2.Controls.Add(this.label38, 0, 14);
            this.tableLayoutPanel2.Controls.Add(this.label36, 0, 13);
            this.tableLayoutPanel2.Controls.Add(this.label34, 0, 12);
            this.tableLayoutPanel2.Controls.Add(this.label32, 0, 11);
            this.tableLayoutPanel2.Controls.Add(this.label30, 0, 10);
            this.tableLayoutPanel2.Controls.Add(this.label28, 0, 9);
            this.tableLayoutPanel2.Controls.Add(this.label26, 0, 8);
            this.tableLayoutPanel2.Controls.Add(this.label20, 1, 2);
            this.tableLayoutPanel2.Controls.Add(this.label18, 1, 1);
            this.tableLayoutPanel2.Controls.Add(this.label14, 2, 0);
            this.tableLayoutPanel2.Controls.Add(this.label19, 0, 0);
            this.tableLayoutPanel2.Controls.Add(this.label50, 1, 0);
            this.tableLayoutPanel2.Controls.Add(this.label52, 0, 1);
            this.tableLayoutPanel2.Controls.Add(this.label53, 0, 2);
            this.tableLayoutPanel2.Controls.Add(this.label54, 0, 3);
            this.tableLayoutPanel2.Controls.Add(this.label55, 0, 4);
            this.tableLayoutPanel2.Controls.Add(this.label56, 0, 5);
            this.tableLayoutPanel2.Controls.Add(this.label57, 0, 6);
            this.tableLayoutPanel2.Controls.Add(this.label58, 0, 7);
            this.tableLayoutPanel2.Controls.Add(this.link_proofOftin, 2, 1);
            this.tableLayoutPanel2.Controls.Add(this.checkBox1, 3, 1);
            this.tableLayoutPanel2.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tableLayoutPanel2.Location = new System.Drawing.Point(3, 3);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            this.tableLayoutPanel2.RowCount = 21;
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel2.Size = new System.Drawing.Size(375, 423);
            this.tableLayoutPanel2.TabIndex = 86;
            // 
            // checkBox20
            // 
            this.checkBox20.AutoSize = true;
            this.checkBox20.Dock = System.Windows.Forms.DockStyle.Fill;
            this.checkBox20.Location = new System.Drawing.Point(345, 403);
            this.checkBox20.Name = "checkBox20";
            this.checkBox20.Size = new System.Drawing.Size(30, 17);
            this.checkBox20.TabIndex = 147;
            this.checkBox20.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.checkBox20.UseVisualStyleBackColor = true;
            // 
            // checkBox19
            // 
            this.checkBox19.AutoSize = true;
            this.checkBox19.Dock = System.Windows.Forms.DockStyle.Fill;
            this.checkBox19.Location = new System.Drawing.Point(345, 383);
            this.checkBox19.Name = "checkBox19";
            this.checkBox19.Size = new System.Drawing.Size(30, 14);
            this.checkBox19.TabIndex = 146;
            this.checkBox19.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.checkBox19.UseVisualStyleBackColor = true;
            // 
            // checkBox18
            // 
            this.checkBox18.AutoSize = true;
            this.checkBox18.Dock = System.Windows.Forms.DockStyle.Fill;
            this.checkBox18.Location = new System.Drawing.Point(345, 363);
            this.checkBox18.Name = "checkBox18";
            this.checkBox18.Size = new System.Drawing.Size(30, 14);
            this.checkBox18.TabIndex = 145;
            this.checkBox18.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.checkBox18.UseVisualStyleBackColor = true;
            // 
            // checkBox17
            // 
            this.checkBox17.AutoSize = true;
            this.checkBox17.Dock = System.Windows.Forms.DockStyle.Fill;
            this.checkBox17.Location = new System.Drawing.Point(345, 343);
            this.checkBox17.Name = "checkBox17";
            this.checkBox17.Size = new System.Drawing.Size(30, 14);
            this.checkBox17.TabIndex = 144;
            this.checkBox17.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.checkBox17.UseVisualStyleBackColor = true;
            // 
            // checkBox16
            // 
            this.checkBox16.AutoSize = true;
            this.checkBox16.Dock = System.Windows.Forms.DockStyle.Fill;
            this.checkBox16.Location = new System.Drawing.Point(345, 323);
            this.checkBox16.Name = "checkBox16";
            this.checkBox16.Size = new System.Drawing.Size(30, 14);
            this.checkBox16.TabIndex = 143;
            this.checkBox16.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.checkBox16.UseVisualStyleBackColor = true;
            // 
            // checkBox15
            // 
            this.checkBox15.AutoSize = true;
            this.checkBox15.Dock = System.Windows.Forms.DockStyle.Fill;
            this.checkBox15.Location = new System.Drawing.Point(345, 303);
            this.checkBox15.Name = "checkBox15";
            this.checkBox15.Size = new System.Drawing.Size(30, 14);
            this.checkBox15.TabIndex = 142;
            this.checkBox15.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.checkBox15.UseVisualStyleBackColor = true;
            // 
            // checkBox14
            // 
            this.checkBox14.AutoSize = true;
            this.checkBox14.Dock = System.Windows.Forms.DockStyle.Fill;
            this.checkBox14.Location = new System.Drawing.Point(345, 283);
            this.checkBox14.Name = "checkBox14";
            this.checkBox14.Size = new System.Drawing.Size(30, 14);
            this.checkBox14.TabIndex = 141;
            this.checkBox14.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.checkBox14.UseVisualStyleBackColor = true;
            // 
            // checkBox13
            // 
            this.checkBox13.AutoSize = true;
            this.checkBox13.Dock = System.Windows.Forms.DockStyle.Fill;
            this.checkBox13.Location = new System.Drawing.Point(345, 263);
            this.checkBox13.Name = "checkBox13";
            this.checkBox13.Size = new System.Drawing.Size(30, 14);
            this.checkBox13.TabIndex = 140;
            this.checkBox13.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.checkBox13.UseVisualStyleBackColor = true;
            // 
            // checkBox12
            // 
            this.checkBox12.AutoSize = true;
            this.checkBox12.Dock = System.Windows.Forms.DockStyle.Fill;
            this.checkBox12.Location = new System.Drawing.Point(345, 243);
            this.checkBox12.Name = "checkBox12";
            this.checkBox12.Size = new System.Drawing.Size(30, 14);
            this.checkBox12.TabIndex = 139;
            this.checkBox12.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.checkBox12.UseVisualStyleBackColor = true;
            // 
            // checkBox11
            // 
            this.checkBox11.AutoSize = true;
            this.checkBox11.Dock = System.Windows.Forms.DockStyle.Fill;
            this.checkBox11.Location = new System.Drawing.Point(345, 223);
            this.checkBox11.Name = "checkBox11";
            this.checkBox11.Size = new System.Drawing.Size(30, 14);
            this.checkBox11.TabIndex = 138;
            this.checkBox11.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.checkBox11.UseVisualStyleBackColor = true;
            // 
            // checkBox10
            // 
            this.checkBox10.AutoSize = true;
            this.checkBox10.Dock = System.Windows.Forms.DockStyle.Fill;
            this.checkBox10.Location = new System.Drawing.Point(345, 203);
            this.checkBox10.Name = "checkBox10";
            this.checkBox10.Size = new System.Drawing.Size(30, 14);
            this.checkBox10.TabIndex = 137;
            this.checkBox10.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.checkBox10.UseVisualStyleBackColor = true;
            // 
            // checkBox9
            // 
            this.checkBox9.AutoSize = true;
            this.checkBox9.Dock = System.Windows.Forms.DockStyle.Fill;
            this.checkBox9.Location = new System.Drawing.Point(345, 183);
            this.checkBox9.Name = "checkBox9";
            this.checkBox9.Size = new System.Drawing.Size(30, 14);
            this.checkBox9.TabIndex = 136;
            this.checkBox9.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.checkBox9.UseVisualStyleBackColor = true;
            // 
            // checkBox8
            // 
            this.checkBox8.AutoSize = true;
            this.checkBox8.Dock = System.Windows.Forms.DockStyle.Fill;
            this.checkBox8.Location = new System.Drawing.Point(345, 163);
            this.checkBox8.Name = "checkBox8";
            this.checkBox8.Size = new System.Drawing.Size(30, 14);
            this.checkBox8.TabIndex = 135;
            this.checkBox8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.checkBox8.UseVisualStyleBackColor = true;
            // 
            // checkBox7
            // 
            this.checkBox7.AutoSize = true;
            this.checkBox7.Dock = System.Windows.Forms.DockStyle.Fill;
            this.checkBox7.Location = new System.Drawing.Point(345, 143);
            this.checkBox7.Name = "checkBox7";
            this.checkBox7.Size = new System.Drawing.Size(30, 14);
            this.checkBox7.TabIndex = 134;
            this.checkBox7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.checkBox7.UseVisualStyleBackColor = true;
            // 
            // checkBox6
            // 
            this.checkBox6.AutoSize = true;
            this.checkBox6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.checkBox6.Location = new System.Drawing.Point(345, 123);
            this.checkBox6.Name = "checkBox6";
            this.checkBox6.Size = new System.Drawing.Size(30, 14);
            this.checkBox6.TabIndex = 133;
            this.checkBox6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.checkBox6.UseVisualStyleBackColor = true;
            // 
            // checkBox5
            // 
            this.checkBox5.AutoSize = true;
            this.checkBox5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.checkBox5.Location = new System.Drawing.Point(345, 103);
            this.checkBox5.Name = "checkBox5";
            this.checkBox5.Size = new System.Drawing.Size(30, 14);
            this.checkBox5.TabIndex = 132;
            this.checkBox5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.checkBox5.UseVisualStyleBackColor = true;
            // 
            // checkBox4
            // 
            this.checkBox4.AutoSize = true;
            this.checkBox4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.checkBox4.Location = new System.Drawing.Point(345, 83);
            this.checkBox4.Name = "checkBox4";
            this.checkBox4.Size = new System.Drawing.Size(30, 14);
            this.checkBox4.TabIndex = 131;
            this.checkBox4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.checkBox4.UseVisualStyleBackColor = true;
            // 
            // checkBox3
            // 
            this.checkBox3.AutoSize = true;
            this.checkBox3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.checkBox3.Location = new System.Drawing.Point(345, 63);
            this.checkBox3.Name = "checkBox3";
            this.checkBox3.Size = new System.Drawing.Size(30, 14);
            this.checkBox3.TabIndex = 130;
            this.checkBox3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.checkBox3.UseVisualStyleBackColor = true;
            // 
            // checkBox2
            // 
            this.checkBox2.AutoSize = true;
            this.checkBox2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.checkBox2.Location = new System.Drawing.Point(345, 43);
            this.checkBox2.Name = "checkBox2";
            this.checkBox2.Size = new System.Drawing.Size(30, 14);
            this.checkBox2.TabIndex = 129;
            this.checkBox2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.checkBox2.UseVisualStyleBackColor = true;
            // 
            // linkLabel20
            // 
            this.linkLabel20.AutoSize = true;
            this.linkLabel20.Dock = System.Windows.Forms.DockStyle.Fill;
            this.linkLabel20.Location = new System.Drawing.Point(294, 400);
            this.linkLabel20.Name = "linkLabel20";
            this.linkLabel20.Size = new System.Drawing.Size(45, 23);
            this.linkLabel20.TabIndex = 126;
            this.linkLabel20.TabStop = true;
            this.linkLabel20.Text = "File";
            this.linkLabel20.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label10.Location = new System.Drawing.Point(3, 400);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(21, 23);
            this.label10.TabIndex = 125;
            this.label10.Text = "20";
            this.label10.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label21.Location = new System.Drawing.Point(30, 60);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(258, 20);
            this.label21.TabIndex = 124;
            this.label21.Text = "Proof of PhilHealth/PMRF";
            this.label21.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label22.Location = new System.Drawing.Point(30, 80);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(258, 20);
            this.label22.TabIndex = 123;
            this.label22.Text = "Proof of Pag-Ibig";
            this.label22.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label23.Location = new System.Drawing.Point(30, 100);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(258, 20);
            this.label23.TabIndex = 122;
            this.label23.Text = "2 Valid ID\'s";
            this.label23.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label24.Location = new System.Drawing.Point(30, 120);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(258, 20);
            this.label24.TabIndex = 121;
            this.label24.Text = "ID Pictures (6 pieces 1 x 1 with nameplate)";
            this.label24.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label25.Location = new System.Drawing.Point(30, 140);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(258, 20);
            this.label25.TabIndex = 120;
            this.label25.Text = "NBI Clearance (Receipt is not acceptable)";
            this.label25.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label27.Location = new System.Drawing.Point(30, 160);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(258, 20);
            this.label27.TabIndex = 119;
            this.label27.Text = "COE (Proof of Employment)";
            this.label27.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label29.Location = new System.Drawing.Point(30, 180);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(258, 20);
            this.label29.TabIndex = 118;
            this.label29.Text = "TOR/Diploma (School Records)";
            this.label29.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label31.Location = new System.Drawing.Point(30, 200);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(258, 20);
            this.label31.TabIndex = 117;
            this.label31.Text = "NSO Birth Certificate (4 copies)";
            this.label31.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label33.Location = new System.Drawing.Point(30, 220);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(258, 20);
            this.label33.TabIndex = 116;
            this.label33.Text = "New Hire Acknowledgement";
            this.label33.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label35.Location = new System.Drawing.Point(30, 240);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(258, 20);
            this.label35.TabIndex = 115;
            this.label35.Text = "NDA";
            this.label35.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label37.Location = new System.Drawing.Point(30, 260);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(258, 20);
            this.label37.TabIndex = 114;
            this.label37.Text = "Interview/Assesment Docs";
            this.label37.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label39.Location = new System.Drawing.Point(30, 280);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(258, 20);
            this.label39.TabIndex = 113;
            this.label39.Text = "Resume/CV";
            this.label39.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label41.Location = new System.Drawing.Point(30, 300);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(258, 20);
            this.label41.TabIndex = 112;
            this.label41.Text = "Background Investigation Check Form";
            this.label41.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label43
            // 
            this.label43.AutoSize = true;
            this.label43.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label43.Location = new System.Drawing.Point(30, 320);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(258, 20);
            this.label43.TabIndex = 111;
            this.label43.Text = "Background Investigation Result";
            this.label43.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label45
            // 
            this.label45.AutoSize = true;
            this.label45.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label45.Location = new System.Drawing.Point(30, 340);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(258, 20);
            this.label45.TabIndex = 110;
            this.label45.Text = "Employee Information Form";
            this.label45.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label47
            // 
            this.label47.AutoSize = true;
            this.label47.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label47.Location = new System.Drawing.Point(30, 360);
            this.label47.Name = "label47";
            this.label47.Size = new System.Drawing.Size(258, 20);
            this.label47.TabIndex = 108;
            this.label47.Text = "Job Description";
            this.label47.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label49
            // 
            this.label49.AutoSize = true;
            this.label49.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label49.Location = new System.Drawing.Point(30, 380);
            this.label49.Name = "label49";
            this.label49.Size = new System.Drawing.Size(258, 20);
            this.label49.TabIndex = 107;
            this.label49.Text = "Employee Contract";
            this.label49.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label51
            // 
            this.label51.AutoSize = true;
            this.label51.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label51.Location = new System.Drawing.Point(30, 400);
            this.label51.Name = "label51";
            this.label51.Size = new System.Drawing.Size(258, 23);
            this.label51.TabIndex = 106;
            this.label51.Text = "PEME Slip";
            this.label51.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // linkLabel19
            // 
            this.linkLabel19.AutoSize = true;
            this.linkLabel19.Dock = System.Windows.Forms.DockStyle.Fill;
            this.linkLabel19.Location = new System.Drawing.Point(294, 380);
            this.linkLabel19.Name = "linkLabel19";
            this.linkLabel19.Size = new System.Drawing.Size(45, 20);
            this.linkLabel19.TabIndex = 100;
            this.linkLabel19.TabStop = true;
            this.linkLabel19.Text = "File";
            this.linkLabel19.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // linkLabel18
            // 
            this.linkLabel18.AutoSize = true;
            this.linkLabel18.Dock = System.Windows.Forms.DockStyle.Fill;
            this.linkLabel18.Location = new System.Drawing.Point(294, 360);
            this.linkLabel18.Name = "linkLabel18";
            this.linkLabel18.Size = new System.Drawing.Size(45, 20);
            this.linkLabel18.TabIndex = 99;
            this.linkLabel18.TabStop = true;
            this.linkLabel18.Text = "File";
            this.linkLabel18.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // link_informationForm
            // 
            this.link_informationForm.AutoSize = true;
            this.link_informationForm.Dock = System.Windows.Forms.DockStyle.Fill;
            this.link_informationForm.Location = new System.Drawing.Point(294, 340);
            this.link_informationForm.Name = "link_informationForm";
            this.link_informationForm.Size = new System.Drawing.Size(45, 20);
            this.link_informationForm.TabIndex = 98;
            this.link_informationForm.TabStop = true;
            this.link_informationForm.Text = "File";
            this.link_informationForm.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // link_backgroundResult
            // 
            this.link_backgroundResult.AutoSize = true;
            this.link_backgroundResult.Dock = System.Windows.Forms.DockStyle.Fill;
            this.link_backgroundResult.Location = new System.Drawing.Point(294, 320);
            this.link_backgroundResult.Name = "link_backgroundResult";
            this.link_backgroundResult.Size = new System.Drawing.Size(45, 20);
            this.link_backgroundResult.TabIndex = 97;
            this.link_backgroundResult.TabStop = true;
            this.link_backgroundResult.Text = "File";
            this.link_backgroundResult.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // link_backgroundCheck
            // 
            this.link_backgroundCheck.AutoSize = true;
            this.link_backgroundCheck.Dock = System.Windows.Forms.DockStyle.Fill;
            this.link_backgroundCheck.Location = new System.Drawing.Point(294, 300);
            this.link_backgroundCheck.Name = "link_backgroundCheck";
            this.link_backgroundCheck.Size = new System.Drawing.Size(45, 20);
            this.link_backgroundCheck.TabIndex = 96;
            this.link_backgroundCheck.TabStop = true;
            this.link_backgroundCheck.Text = "File";
            this.link_backgroundCheck.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // link_resume
            // 
            this.link_resume.AutoSize = true;
            this.link_resume.Dock = System.Windows.Forms.DockStyle.Fill;
            this.link_resume.Location = new System.Drawing.Point(294, 280);
            this.link_resume.Name = "link_resume";
            this.link_resume.Size = new System.Drawing.Size(45, 20);
            this.link_resume.TabIndex = 95;
            this.link_resume.TabStop = true;
            this.link_resume.Text = "File";
            this.link_resume.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // link_InterviewDocs
            // 
            this.link_InterviewDocs.AutoSize = true;
            this.link_InterviewDocs.Dock = System.Windows.Forms.DockStyle.Fill;
            this.link_InterviewDocs.Location = new System.Drawing.Point(294, 260);
            this.link_InterviewDocs.Name = "link_InterviewDocs";
            this.link_InterviewDocs.Size = new System.Drawing.Size(45, 20);
            this.link_InterviewDocs.TabIndex = 94;
            this.link_InterviewDocs.TabStop = true;
            this.link_InterviewDocs.Text = "File";
            this.link_InterviewDocs.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // link_NDA
            // 
            this.link_NDA.AutoSize = true;
            this.link_NDA.Dock = System.Windows.Forms.DockStyle.Fill;
            this.link_NDA.Location = new System.Drawing.Point(294, 240);
            this.link_NDA.Name = "link_NDA";
            this.link_NDA.Size = new System.Drawing.Size(45, 20);
            this.link_NDA.TabIndex = 93;
            this.link_NDA.TabStop = true;
            this.link_NDA.Text = "File";
            this.link_NDA.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // link_NewHire
            // 
            this.link_NewHire.AutoSize = true;
            this.link_NewHire.Dock = System.Windows.Forms.DockStyle.Fill;
            this.link_NewHire.Location = new System.Drawing.Point(294, 220);
            this.link_NewHire.Name = "link_NewHire";
            this.link_NewHire.Size = new System.Drawing.Size(45, 20);
            this.link_NewHire.TabIndex = 92;
            this.link_NewHire.TabStop = true;
            this.link_NewHire.Text = "File";
            this.link_NewHire.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // link_SNO
            // 
            this.link_SNO.AutoSize = true;
            this.link_SNO.Dock = System.Windows.Forms.DockStyle.Fill;
            this.link_SNO.Location = new System.Drawing.Point(294, 200);
            this.link_SNO.Name = "link_SNO";
            this.link_SNO.Size = new System.Drawing.Size(45, 20);
            this.link_SNO.TabIndex = 91;
            this.link_SNO.TabStop = true;
            this.link_SNO.Text = "File";
            this.link_SNO.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // link_TOR
            // 
            this.link_TOR.AutoSize = true;
            this.link_TOR.Dock = System.Windows.Forms.DockStyle.Fill;
            this.link_TOR.Location = new System.Drawing.Point(294, 180);
            this.link_TOR.Name = "link_TOR";
            this.link_TOR.Size = new System.Drawing.Size(45, 20);
            this.link_TOR.TabIndex = 90;
            this.link_TOR.TabStop = true;
            this.link_TOR.Text = "File";
            this.link_TOR.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // link_COE
            // 
            this.link_COE.AutoSize = true;
            this.link_COE.Dock = System.Windows.Forms.DockStyle.Fill;
            this.link_COE.Location = new System.Drawing.Point(294, 160);
            this.link_COE.Name = "link_COE";
            this.link_COE.Size = new System.Drawing.Size(45, 20);
            this.link_COE.TabIndex = 89;
            this.link_COE.TabStop = true;
            this.link_COE.Text = "File";
            this.link_COE.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // link_NBI
            // 
            this.link_NBI.AutoSize = true;
            this.link_NBI.Dock = System.Windows.Forms.DockStyle.Fill;
            this.link_NBI.Location = new System.Drawing.Point(294, 140);
            this.link_NBI.Name = "link_NBI";
            this.link_NBI.Size = new System.Drawing.Size(45, 20);
            this.link_NBI.TabIndex = 88;
            this.link_NBI.TabStop = true;
            this.link_NBI.Text = "File";
            this.link_NBI.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lin_IDPicture
            // 
            this.lin_IDPicture.AutoSize = true;
            this.lin_IDPicture.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lin_IDPicture.Location = new System.Drawing.Point(294, 120);
            this.lin_IDPicture.Name = "lin_IDPicture";
            this.lin_IDPicture.Size = new System.Drawing.Size(45, 20);
            this.lin_IDPicture.TabIndex = 87;
            this.lin_IDPicture.TabStop = true;
            this.lin_IDPicture.Text = "File";
            this.lin_IDPicture.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // link_validID
            // 
            this.link_validID.AutoSize = true;
            this.link_validID.Dock = System.Windows.Forms.DockStyle.Fill;
            this.link_validID.Location = new System.Drawing.Point(294, 100);
            this.link_validID.Name = "link_validID";
            this.link_validID.Size = new System.Drawing.Size(45, 20);
            this.link_validID.TabIndex = 86;
            this.link_validID.TabStop = true;
            this.link_validID.Text = "File";
            this.link_validID.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // link_ProofOfPagibig
            // 
            this.link_ProofOfPagibig.AutoSize = true;
            this.link_ProofOfPagibig.Dock = System.Windows.Forms.DockStyle.Fill;
            this.link_ProofOfPagibig.Location = new System.Drawing.Point(294, 80);
            this.link_ProofOfPagibig.Name = "link_ProofOfPagibig";
            this.link_ProofOfPagibig.Size = new System.Drawing.Size(45, 20);
            this.link_ProofOfPagibig.TabIndex = 85;
            this.link_ProofOfPagibig.TabStop = true;
            this.link_ProofOfPagibig.Text = "File";
            this.link_ProofOfPagibig.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // link_proofOfPhilHealth
            // 
            this.link_proofOfPhilHealth.AutoSize = true;
            this.link_proofOfPhilHealth.Dock = System.Windows.Forms.DockStyle.Fill;
            this.link_proofOfPhilHealth.Location = new System.Drawing.Point(294, 60);
            this.link_proofOfPhilHealth.Name = "link_proofOfPhilHealth";
            this.link_proofOfPhilHealth.Size = new System.Drawing.Size(45, 20);
            this.link_proofOfPhilHealth.TabIndex = 84;
            this.link_proofOfPhilHealth.TabStop = true;
            this.link_proofOfPhilHealth.Text = "File";
            this.link_proofOfPhilHealth.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // link_proofOfSSS
            // 
            this.link_proofOfSSS.AutoSize = true;
            this.link_proofOfSSS.Dock = System.Windows.Forms.DockStyle.Fill;
            this.link_proofOfSSS.Location = new System.Drawing.Point(294, 40);
            this.link_proofOfSSS.Name = "link_proofOfSSS";
            this.link_proofOfSSS.Size = new System.Drawing.Size(45, 20);
            this.link_proofOfSSS.TabIndex = 83;
            this.link_proofOfSSS.TabStop = true;
            this.link_proofOfSSS.Text = "File";
            this.link_proofOfSSS.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label48
            // 
            this.label48.AutoSize = true;
            this.label48.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label48.Location = new System.Drawing.Point(3, 380);
            this.label48.Name = "label48";
            this.label48.Size = new System.Drawing.Size(21, 20);
            this.label48.TabIndex = 80;
            this.label48.Text = "19";
            this.label48.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label46
            // 
            this.label46.AutoSize = true;
            this.label46.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label46.Location = new System.Drawing.Point(3, 360);
            this.label46.Name = "label46";
            this.label46.Size = new System.Drawing.Size(21, 20);
            this.label46.TabIndex = 78;
            this.label46.Text = "18";
            this.label46.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.label44.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label44.Location = new System.Drawing.Point(3, 340);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(21, 20);
            this.label44.TabIndex = 76;
            this.label44.Text = "17";
            this.label44.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label42
            // 
            this.label42.AutoSize = true;
            this.label42.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label42.Location = new System.Drawing.Point(3, 320);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(21, 20);
            this.label42.TabIndex = 74;
            this.label42.Text = "16";
            this.label42.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label40.Location = new System.Drawing.Point(3, 300);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(21, 20);
            this.label40.TabIndex = 72;
            this.label40.Text = "15";
            this.label40.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label38.Location = new System.Drawing.Point(3, 280);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(21, 20);
            this.label38.TabIndex = 70;
            this.label38.Text = "14";
            this.label38.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label36.Location = new System.Drawing.Point(3, 260);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(21, 20);
            this.label36.TabIndex = 68;
            this.label36.Text = "13";
            this.label36.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label34.Location = new System.Drawing.Point(3, 240);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(21, 20);
            this.label34.TabIndex = 66;
            this.label34.Text = "12";
            this.label34.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label32.Location = new System.Drawing.Point(3, 220);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(21, 20);
            this.label32.TabIndex = 64;
            this.label32.Text = "11";
            this.label32.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label30.Location = new System.Drawing.Point(3, 200);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(21, 20);
            this.label30.TabIndex = 62;
            this.label30.Text = "10";
            this.label30.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label28.Location = new System.Drawing.Point(3, 180);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(21, 20);
            this.label28.TabIndex = 60;
            this.label28.Text = "9";
            this.label28.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label26.Location = new System.Drawing.Point(3, 160);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(21, 20);
            this.label26.TabIndex = 58;
            this.label26.Text = "8";
            this.label26.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label20.Location = new System.Drawing.Point(30, 40);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(258, 20);
            this.label20.TabIndex = 52;
            this.label20.Text = "Proof of SSS";
            this.label20.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label18.Location = new System.Drawing.Point(30, 20);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(258, 20);
            this.label18.TabIndex = 51;
            this.label18.Text = "Proof of TIN/BIR 1902";
            this.label18.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.label14.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label14.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(291, 0);
            this.label14.Margin = new System.Windows.Forms.Padding(0);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(51, 20);
            this.label14.TabIndex = 2;
            this.label14.Text = "@@";
            this.label14.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.label19.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label19.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.Location = new System.Drawing.Point(0, 0);
            this.label19.Margin = new System.Windows.Forms.Padding(0);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(27, 20);
            this.label19.TabIndex = 1;
            this.label19.Text = "#";
            this.label19.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label50
            // 
            this.label50.AutoSize = true;
            this.label50.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.label50.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label50.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label50.Location = new System.Drawing.Point(27, 0);
            this.label50.Margin = new System.Windows.Forms.Padding(0);
            this.label50.Name = "label50";
            this.label50.Size = new System.Drawing.Size(264, 20);
            this.label50.TabIndex = 0;
            this.label50.Text = "Primary Requirements";
            this.label50.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label52
            // 
            this.label52.AutoSize = true;
            this.label52.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label52.Location = new System.Drawing.Point(3, 20);
            this.label52.Name = "label52";
            this.label52.Size = new System.Drawing.Size(21, 20);
            this.label52.TabIndex = 44;
            this.label52.Text = "1";
            this.label52.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label53
            // 
            this.label53.AutoSize = true;
            this.label53.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label53.Location = new System.Drawing.Point(3, 40);
            this.label53.Name = "label53";
            this.label53.Size = new System.Drawing.Size(21, 20);
            this.label53.TabIndex = 45;
            this.label53.Text = "2";
            this.label53.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label54
            // 
            this.label54.AutoSize = true;
            this.label54.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label54.Location = new System.Drawing.Point(3, 60);
            this.label54.Name = "label54";
            this.label54.Size = new System.Drawing.Size(21, 20);
            this.label54.TabIndex = 46;
            this.label54.Text = "3";
            this.label54.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label55
            // 
            this.label55.AutoSize = true;
            this.label55.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label55.Location = new System.Drawing.Point(3, 80);
            this.label55.Name = "label55";
            this.label55.Size = new System.Drawing.Size(21, 20);
            this.label55.TabIndex = 47;
            this.label55.Text = "4";
            this.label55.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label56
            // 
            this.label56.AutoSize = true;
            this.label56.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label56.Location = new System.Drawing.Point(3, 100);
            this.label56.Name = "label56";
            this.label56.Size = new System.Drawing.Size(21, 20);
            this.label56.TabIndex = 48;
            this.label56.Text = "5";
            this.label56.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label57
            // 
            this.label57.AutoSize = true;
            this.label57.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label57.Location = new System.Drawing.Point(3, 120);
            this.label57.Name = "label57";
            this.label57.Size = new System.Drawing.Size(21, 20);
            this.label57.TabIndex = 49;
            this.label57.Text = "6";
            this.label57.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label58
            // 
            this.label58.AutoSize = true;
            this.label58.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label58.Location = new System.Drawing.Point(3, 140);
            this.label58.Name = "label58";
            this.label58.Size = new System.Drawing.Size(21, 20);
            this.label58.TabIndex = 50;
            this.label58.Text = "7";
            this.label58.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // link_proofOftin
            // 
            this.link_proofOftin.AutoSize = true;
            this.link_proofOftin.Dock = System.Windows.Forms.DockStyle.Fill;
            this.link_proofOftin.Location = new System.Drawing.Point(294, 20);
            this.link_proofOftin.Name = "link_proofOftin";
            this.link_proofOftin.Size = new System.Drawing.Size(45, 20);
            this.link_proofOftin.TabIndex = 82;
            this.link_proofOftin.TabStop = true;
            this.link_proofOftin.Text = "File";
            this.link_proofOftin.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // checkBox1
            // 
            this.checkBox1.AutoSize = true;
            this.checkBox1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.checkBox1.Location = new System.Drawing.Point(345, 23);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Size = new System.Drawing.Size(30, 14);
            this.checkBox1.TabIndex = 128;
            this.checkBox1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.checkBox1.UseVisualStyleBackColor = true;
            // 
            // tabPage1
            // 
            this.tabPage1.AutoScroll = true;
            this.tabPage1.Controls.Add(this.tableLayoutPanel1);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(821, 465);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Employee Info";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.BackColor = System.Drawing.SystemColors.Control;
            this.tableLayoutPanel1.ColumnCount = 1;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.Controls.Add(this.tableLayoutPanel4, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.label11, 0, 0);
            this.tableLayoutPanel1.Location = new System.Drawing.Point(6, 6);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 3;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 28F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 415F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 8F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(418, 445);
            this.tableLayoutPanel1.TabIndex = 2;
            // 
            // tableLayoutPanel4
            // 
            this.tableLayoutPanel4.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Single;
            this.tableLayoutPanel4.ColumnCount = 2;
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel4.Controls.Add(this.lbl_info_maritalstatus, 1, 6);
            this.tableLayoutPanel4.Controls.Add(this.sdf, 0, 6);
            this.tableLayoutPanel4.Controls.Add(this.label104, 0, 15);
            this.tableLayoutPanel4.Controls.Add(this.lbl_address_postal_no, 0, 15);
            this.tableLayoutPanel4.Controls.Add(this.lbl_info_email, 1, 7);
            this.tableLayoutPanel4.Controls.Add(this.lbl_info_secondary_contact, 1, 5);
            this.tableLayoutPanel4.Controls.Add(this.lbl_info_primary_contact, 1, 4);
            this.tableLayoutPanel4.Controls.Add(this.lbl_info_lastname, 1, 3);
            this.tableLayoutPanel4.Controls.Add(this.lbl_info_middlename, 1, 2);
            this.tableLayoutPanel4.Controls.Add(this.lbl_info_firstname, 1, 1);
            this.tableLayoutPanel4.Controls.Add(this.label2, 0, 0);
            this.tableLayoutPanel4.Controls.Add(this.label3, 0, 1);
            this.tableLayoutPanel4.Controls.Add(this.label4, 0, 2);
            this.tableLayoutPanel4.Controls.Add(this.label5, 0, 3);
            this.tableLayoutPanel4.Controls.Add(this.label6, 0, 4);
            this.tableLayoutPanel4.Controls.Add(this.label7, 0, 5);
            this.tableLayoutPanel4.Controls.Add(this.label8, 0, 7);
            this.tableLayoutPanel4.Controls.Add(this.label9, 0, 9);
            this.tableLayoutPanel4.Controls.Add(this.label1, 0, 10);
            this.tableLayoutPanel4.Controls.Add(this.lbl_info_employee_id, 1, 0);
            this.tableLayoutPanel4.Controls.Add(this.lbl_benefits, 0, 8);
            this.tableLayoutPanel4.Controls.Add(this.lbl_info_sss, 1, 8);
            this.tableLayoutPanel4.Controls.Add(this.lbl_info_tin, 1, 9);
            this.tableLayoutPanel4.Controls.Add(this.lbl_info_hdmf, 1, 10);
            this.tableLayoutPanel4.Controls.Add(this.label16, 0, 11);
            this.tableLayoutPanel4.Controls.Add(this.lbl_info_bpi, 1, 11);
            this.tableLayoutPanel4.Controls.Add(this.label64, 0, 12);
            this.tableLayoutPanel4.Controls.Add(this.label98, 0, 13);
            this.tableLayoutPanel4.Controls.Add(this.label99, 0, 14);
            this.tableLayoutPanel4.Controls.Add(this.lbl_address_no, 1, 12);
            this.tableLayoutPanel4.Controls.Add(this.lbl_address_street, 1, 13);
            this.tableLayoutPanel4.Controls.Add(this.lbl_address_postal_area, 1, 14);
            this.tableLayoutPanel4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel4.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tableLayoutPanel4.Location = new System.Drawing.Point(0, 28);
            this.tableLayoutPanel4.Margin = new System.Windows.Forms.Padding(0);
            this.tableLayoutPanel4.Name = "tableLayoutPanel4";
            this.tableLayoutPanel4.RowCount = 16;
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 25F));
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 25F));
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 25F));
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 25F));
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 25F));
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 25F));
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 25F));
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 25F));
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 25F));
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 25F));
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 25F));
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 25F));
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 25F));
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 25F));
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 25F));
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 25F));
            this.tableLayoutPanel4.Size = new System.Drawing.Size(418, 415);
            this.tableLayoutPanel4.TabIndex = 0;
            // 
            // lbl_info_maritalstatus
            // 
            this.lbl_info_maritalstatus.AutoSize = true;
            this.lbl_info_maritalstatus.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl_info_maritalstatus.Location = new System.Drawing.Point(212, 157);
            this.lbl_info_maritalstatus.Name = "lbl_info_maritalstatus";
            this.lbl_info_maritalstatus.Size = new System.Drawing.Size(202, 25);
            this.lbl_info_maritalstatus.TabIndex = 8;
            this.lbl_info_maritalstatus.Text = "<-->";
            this.lbl_info_maritalstatus.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // sdf
            // 
            this.sdf.AutoSize = true;
            this.sdf.Dock = System.Windows.Forms.DockStyle.Fill;
            this.sdf.Location = new System.Drawing.Point(4, 157);
            this.sdf.Name = "sdf";
            this.sdf.Size = new System.Drawing.Size(201, 25);
            this.sdf.TabIndex = 7;
            this.sdf.Text = "Marital Status";
            this.sdf.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label104
            // 
            this.label104.AutoSize = true;
            this.label104.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label104.Location = new System.Drawing.Point(4, 391);
            this.label104.Name = "label104";
            this.label104.Size = new System.Drawing.Size(201, 25);
            this.label104.TabIndex = 32;
            this.label104.Text = "(Contact Person) Relationship";
            this.label104.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lbl_address_postal_no
            // 
            this.lbl_address_postal_no.AutoSize = true;
            this.lbl_address_postal_no.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl_address_postal_no.Location = new System.Drawing.Point(212, 391);
            this.lbl_address_postal_no.Name = "lbl_address_postal_no";
            this.lbl_address_postal_no.Size = new System.Drawing.Size(202, 25);
            this.lbl_address_postal_no.TabIndex = 31;
            this.lbl_address_postal_no.Text = "<-->";
            this.lbl_address_postal_no.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lbl_info_email
            // 
            this.lbl_info_email.AutoSize = true;
            this.lbl_info_email.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl_info_email.Location = new System.Drawing.Point(212, 183);
            this.lbl_info_email.Name = "lbl_info_email";
            this.lbl_info_email.Size = new System.Drawing.Size(202, 25);
            this.lbl_info_email.TabIndex = 15;
            this.lbl_info_email.Text = "<-->";
            this.lbl_info_email.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lbl_info_secondary_contact
            // 
            this.lbl_info_secondary_contact.AutoSize = true;
            this.lbl_info_secondary_contact.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl_info_secondary_contact.Location = new System.Drawing.Point(212, 131);
            this.lbl_info_secondary_contact.Name = "lbl_info_secondary_contact";
            this.lbl_info_secondary_contact.Size = new System.Drawing.Size(202, 25);
            this.lbl_info_secondary_contact.TabIndex = 14;
            this.lbl_info_secondary_contact.Text = "<-->";
            this.lbl_info_secondary_contact.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lbl_info_primary_contact
            // 
            this.lbl_info_primary_contact.AutoSize = true;
            this.lbl_info_primary_contact.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl_info_primary_contact.Location = new System.Drawing.Point(212, 105);
            this.lbl_info_primary_contact.Name = "lbl_info_primary_contact";
            this.lbl_info_primary_contact.Size = new System.Drawing.Size(202, 25);
            this.lbl_info_primary_contact.TabIndex = 13;
            this.lbl_info_primary_contact.Text = "<-->";
            this.lbl_info_primary_contact.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lbl_info_lastname
            // 
            this.lbl_info_lastname.AutoSize = true;
            this.lbl_info_lastname.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl_info_lastname.Location = new System.Drawing.Point(212, 79);
            this.lbl_info_lastname.Name = "lbl_info_lastname";
            this.lbl_info_lastname.Size = new System.Drawing.Size(202, 25);
            this.lbl_info_lastname.TabIndex = 12;
            this.lbl_info_lastname.Text = "<-->";
            this.lbl_info_lastname.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lbl_info_middlename
            // 
            this.lbl_info_middlename.AutoSize = true;
            this.lbl_info_middlename.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl_info_middlename.Location = new System.Drawing.Point(212, 53);
            this.lbl_info_middlename.Name = "lbl_info_middlename";
            this.lbl_info_middlename.Size = new System.Drawing.Size(202, 25);
            this.lbl_info_middlename.TabIndex = 11;
            this.lbl_info_middlename.Text = "<-->";
            this.lbl_info_middlename.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lbl_info_firstname
            // 
            this.lbl_info_firstname.AutoSize = true;
            this.lbl_info_firstname.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl_info_firstname.Location = new System.Drawing.Point(212, 27);
            this.lbl_info_firstname.Name = "lbl_info_firstname";
            this.lbl_info_firstname.Size = new System.Drawing.Size(202, 25);
            this.lbl_info_firstname.TabIndex = 10;
            this.lbl_info_firstname.Text = "<-->";
            this.lbl_info_firstname.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label2.Location = new System.Drawing.Point(4, 1);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(201, 25);
            this.label2.TabIndex = 0;
            this.label2.Text = "Employee ID";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label3.Location = new System.Drawing.Point(4, 27);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(201, 25);
            this.label3.TabIndex = 1;
            this.label3.Text = "Firstname";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label4.Location = new System.Drawing.Point(4, 53);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(201, 25);
            this.label4.TabIndex = 2;
            this.label4.Text = "Middlename";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label5.Location = new System.Drawing.Point(4, 79);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(201, 25);
            this.label5.TabIndex = 3;
            this.label5.Text = "Lastname";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label6.Location = new System.Drawing.Point(4, 105);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(201, 25);
            this.label6.TabIndex = 4;
            this.label6.Text = "Primary Contact";
            this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label7.Location = new System.Drawing.Point(4, 131);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(201, 25);
            this.label7.TabIndex = 5;
            this.label7.Text = "Secondary Contact";
            this.label7.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label8.Location = new System.Drawing.Point(4, 183);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(201, 25);
            this.label8.TabIndex = 6;
            this.label8.Text = "Email";
            this.label8.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label9.Location = new System.Drawing.Point(4, 235);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(201, 25);
            this.label9.TabIndex = 7;
            this.label9.Text = "TIN";
            this.label9.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label1.Location = new System.Drawing.Point(4, 261);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(201, 25);
            this.label1.TabIndex = 8;
            this.label1.Text = "HDMF";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lbl_info_employee_id
            // 
            this.lbl_info_employee_id.AutoSize = true;
            this.lbl_info_employee_id.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl_info_employee_id.Location = new System.Drawing.Point(212, 1);
            this.lbl_info_employee_id.Name = "lbl_info_employee_id";
            this.lbl_info_employee_id.Size = new System.Drawing.Size(202, 25);
            this.lbl_info_employee_id.TabIndex = 9;
            this.lbl_info_employee_id.Text = "<-->";
            this.lbl_info_employee_id.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lbl_benefits
            // 
            this.lbl_benefits.AutoSize = true;
            this.lbl_benefits.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl_benefits.Location = new System.Drawing.Point(4, 209);
            this.lbl_benefits.Name = "lbl_benefits";
            this.lbl_benefits.Size = new System.Drawing.Size(201, 25);
            this.lbl_benefits.TabIndex = 19;
            this.lbl_benefits.Text = "SSS";
            this.lbl_benefits.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lbl_info_sss
            // 
            this.lbl_info_sss.AutoSize = true;
            this.lbl_info_sss.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl_info_sss.Location = new System.Drawing.Point(212, 209);
            this.lbl_info_sss.Name = "lbl_info_sss";
            this.lbl_info_sss.Size = new System.Drawing.Size(202, 25);
            this.lbl_info_sss.TabIndex = 20;
            this.lbl_info_sss.Text = "<-->";
            this.lbl_info_sss.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lbl_info_tin
            // 
            this.lbl_info_tin.AutoSize = true;
            this.lbl_info_tin.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl_info_tin.Location = new System.Drawing.Point(212, 235);
            this.lbl_info_tin.Name = "lbl_info_tin";
            this.lbl_info_tin.Size = new System.Drawing.Size(202, 25);
            this.lbl_info_tin.TabIndex = 21;
            this.lbl_info_tin.Text = "<-->";
            this.lbl_info_tin.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lbl_info_hdmf
            // 
            this.lbl_info_hdmf.AutoSize = true;
            this.lbl_info_hdmf.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl_info_hdmf.Location = new System.Drawing.Point(212, 261);
            this.lbl_info_hdmf.Name = "lbl_info_hdmf";
            this.lbl_info_hdmf.Size = new System.Drawing.Size(202, 25);
            this.lbl_info_hdmf.TabIndex = 22;
            this.lbl_info_hdmf.Text = "<-->";
            this.lbl_info_hdmf.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label16.Location = new System.Drawing.Point(4, 287);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(201, 25);
            this.label16.TabIndex = 23;
            this.label16.Text = "BPI Account";
            this.label16.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lbl_info_bpi
            // 
            this.lbl_info_bpi.AutoSize = true;
            this.lbl_info_bpi.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl_info_bpi.Location = new System.Drawing.Point(212, 287);
            this.lbl_info_bpi.Name = "lbl_info_bpi";
            this.lbl_info_bpi.Size = new System.Drawing.Size(202, 25);
            this.lbl_info_bpi.TabIndex = 24;
            this.lbl_info_bpi.Text = "<-->";
            this.lbl_info_bpi.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label64
            // 
            this.label64.AutoSize = true;
            this.label64.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label64.Location = new System.Drawing.Point(4, 313);
            this.label64.Name = "label64";
            this.label64.Size = new System.Drawing.Size(201, 25);
            this.label64.TabIndex = 25;
            this.label64.Text = "(Contact Person) Firstname";
            this.label64.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label98
            // 
            this.label98.AutoSize = true;
            this.label98.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label98.Location = new System.Drawing.Point(4, 339);
            this.label98.Name = "label98";
            this.label98.Size = new System.Drawing.Size(201, 25);
            this.label98.TabIndex = 26;
            this.label98.Text = "(Contact Person) Lastname";
            this.label98.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label99
            // 
            this.label99.AutoSize = true;
            this.label99.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label99.Location = new System.Drawing.Point(4, 365);
            this.label99.Name = "label99";
            this.label99.Size = new System.Drawing.Size(201, 25);
            this.label99.TabIndex = 27;
            this.label99.Text = "(Contact Person) Contact Number";
            this.label99.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lbl_address_no
            // 
            this.lbl_address_no.AutoSize = true;
            this.lbl_address_no.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl_address_no.Location = new System.Drawing.Point(212, 313);
            this.lbl_address_no.Name = "lbl_address_no";
            this.lbl_address_no.Size = new System.Drawing.Size(202, 25);
            this.lbl_address_no.TabIndex = 28;
            this.lbl_address_no.Text = "<-->";
            this.lbl_address_no.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lbl_address_street
            // 
            this.lbl_address_street.AutoSize = true;
            this.lbl_address_street.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl_address_street.Location = new System.Drawing.Point(212, 339);
            this.lbl_address_street.Name = "lbl_address_street";
            this.lbl_address_street.Size = new System.Drawing.Size(202, 25);
            this.lbl_address_street.TabIndex = 29;
            this.lbl_address_street.Text = "<-->";
            this.lbl_address_street.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lbl_address_postal_area
            // 
            this.lbl_address_postal_area.AutoSize = true;
            this.lbl_address_postal_area.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl_address_postal_area.Location = new System.Drawing.Point(212, 365);
            this.lbl_address_postal_area.Name = "lbl_address_postal_area";
            this.lbl_address_postal_area.Size = new System.Drawing.Size(202, 25);
            this.lbl_address_postal_area.TabIndex = 30;
            this.lbl_address_postal_area.Text = "<-->";
            this.lbl_address_postal_area.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label11
            // 
            this.label11.BackColor = System.Drawing.SystemColors.Highlight;
            this.label11.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label11.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label11.Location = new System.Drawing.Point(0, 0);
            this.label11.Margin = new System.Windows.Forms.Padding(0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(418, 28);
            this.label11.TabIndex = 1;
            this.label11.Text = "Personal Info";
            this.label11.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage4);
            this.tabControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControl1.Location = new System.Drawing.Point(12, 12);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(829, 491);
            this.tabControl1.TabIndex = 0;
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.tableLayoutPanel7);
            this.tabPage2.Controls.Add(this.tableLayoutPanel5);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Size = new System.Drawing.Size(821, 465);
            this.tabPage2.TabIndex = 4;
            this.tabPage2.Text = "Job & Salary Info";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // tableLayoutPanel7
            // 
            this.tableLayoutPanel7.BackColor = System.Drawing.SystemColors.Control;
            this.tableLayoutPanel7.ColumnCount = 1;
            this.tableLayoutPanel7.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel7.Controls.Add(this.tableLayoutPanel8, 0, 1);
            this.tableLayoutPanel7.Controls.Add(this.label140, 0, 0);
            this.tableLayoutPanel7.Location = new System.Drawing.Point(424, 5);
            this.tableLayoutPanel7.Name = "tableLayoutPanel7";
            this.tableLayoutPanel7.RowCount = 3;
            this.tableLayoutPanel7.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 28F));
            this.tableLayoutPanel7.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 261F));
            this.tableLayoutPanel7.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 146F));
            this.tableLayoutPanel7.Size = new System.Drawing.Size(390, 289);
            this.tableLayoutPanel7.TabIndex = 6;
            // 
            // tableLayoutPanel8
            // 
            this.tableLayoutPanel8.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Single;
            this.tableLayoutPanel8.ColumnCount = 2;
            this.tableLayoutPanel8.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel8.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel8.Controls.Add(this.lbl_salary_shift_allowance, 1, 6);
            this.tableLayoutPanel8.Controls.Add(this.lbl_salary_annual_allowance, 1, 5);
            this.tableLayoutPanel8.Controls.Add(this.lbl_salary_annual, 1, 4);
            this.tableLayoutPanel8.Controls.Add(this.lbl_salary_approved, 1, 3);
            this.tableLayoutPanel8.Controls.Add(this.lbl_salary_date_started, 1, 2);
            this.tableLayoutPanel8.Controls.Add(this.lbl_salary_date_accepted, 1, 1);
            this.tableLayoutPanel8.Controls.Add(this.label114, 0, 0);
            this.tableLayoutPanel8.Controls.Add(this.label116, 0, 1);
            this.tableLayoutPanel8.Controls.Add(this.label117, 0, 2);
            this.tableLayoutPanel8.Controls.Add(this.label118, 0, 3);
            this.tableLayoutPanel8.Controls.Add(this.label120, 0, 4);
            this.tableLayoutPanel8.Controls.Add(this.label122, 0, 5);
            this.tableLayoutPanel8.Controls.Add(this.label123, 0, 6);
            this.tableLayoutPanel8.Controls.Add(this.label124, 0, 8);
            this.tableLayoutPanel8.Controls.Add(this.label125, 0, 9);
            this.tableLayoutPanel8.Controls.Add(this.lbl_salary_date_approved, 1, 0);
            this.tableLayoutPanel8.Controls.Add(this.label128, 0, 7);
            this.tableLayoutPanel8.Controls.Add(this.lbl_salary_reloc_allowance, 1, 7);
            this.tableLayoutPanel8.Controls.Add(this.lbl_salary_reloc_detail, 1, 8);
            this.tableLayoutPanel8.Controls.Add(this.lbl_salary_cost_centre, 1, 9);
            this.tableLayoutPanel8.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel8.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tableLayoutPanel8.Location = new System.Drawing.Point(0, 28);
            this.tableLayoutPanel8.Margin = new System.Windows.Forms.Padding(0);
            this.tableLayoutPanel8.Name = "tableLayoutPanel8";
            this.tableLayoutPanel8.RowCount = 10;
            this.tableLayoutPanel8.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 25F));
            this.tableLayoutPanel8.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 25F));
            this.tableLayoutPanel8.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 25F));
            this.tableLayoutPanel8.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 25F));
            this.tableLayoutPanel8.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 25F));
            this.tableLayoutPanel8.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 25F));
            this.tableLayoutPanel8.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 25F));
            this.tableLayoutPanel8.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 25F));
            this.tableLayoutPanel8.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 25F));
            this.tableLayoutPanel8.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 25F));
            this.tableLayoutPanel8.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel8.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel8.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel8.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel8.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel8.Size = new System.Drawing.Size(390, 261);
            this.tableLayoutPanel8.TabIndex = 0;
            // 
            // lbl_salary_shift_allowance
            // 
            this.lbl_salary_shift_allowance.AutoSize = true;
            this.lbl_salary_shift_allowance.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl_salary_shift_allowance.Location = new System.Drawing.Point(198, 157);
            this.lbl_salary_shift_allowance.Name = "lbl_salary_shift_allowance";
            this.lbl_salary_shift_allowance.Size = new System.Drawing.Size(188, 25);
            this.lbl_salary_shift_allowance.TabIndex = 15;
            this.lbl_salary_shift_allowance.Text = "<-->";
            this.lbl_salary_shift_allowance.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lbl_salary_annual_allowance
            // 
            this.lbl_salary_annual_allowance.AutoSize = true;
            this.lbl_salary_annual_allowance.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl_salary_annual_allowance.Location = new System.Drawing.Point(198, 131);
            this.lbl_salary_annual_allowance.Name = "lbl_salary_annual_allowance";
            this.lbl_salary_annual_allowance.Size = new System.Drawing.Size(188, 25);
            this.lbl_salary_annual_allowance.TabIndex = 14;
            this.lbl_salary_annual_allowance.Text = "<-->";
            this.lbl_salary_annual_allowance.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lbl_salary_annual
            // 
            this.lbl_salary_annual.AutoSize = true;
            this.lbl_salary_annual.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl_salary_annual.Location = new System.Drawing.Point(198, 105);
            this.lbl_salary_annual.Name = "lbl_salary_annual";
            this.lbl_salary_annual.Size = new System.Drawing.Size(188, 25);
            this.lbl_salary_annual.TabIndex = 13;
            this.lbl_salary_annual.Text = "<-->";
            this.lbl_salary_annual.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lbl_salary_approved
            // 
            this.lbl_salary_approved.AutoSize = true;
            this.lbl_salary_approved.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl_salary_approved.Location = new System.Drawing.Point(198, 79);
            this.lbl_salary_approved.Name = "lbl_salary_approved";
            this.lbl_salary_approved.Size = new System.Drawing.Size(188, 25);
            this.lbl_salary_approved.TabIndex = 12;
            this.lbl_salary_approved.Text = "<-->";
            this.lbl_salary_approved.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lbl_salary_date_started
            // 
            this.lbl_salary_date_started.AutoSize = true;
            this.lbl_salary_date_started.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl_salary_date_started.Location = new System.Drawing.Point(198, 53);
            this.lbl_salary_date_started.Name = "lbl_salary_date_started";
            this.lbl_salary_date_started.Size = new System.Drawing.Size(188, 25);
            this.lbl_salary_date_started.TabIndex = 11;
            this.lbl_salary_date_started.Text = "<-->";
            this.lbl_salary_date_started.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lbl_salary_date_accepted
            // 
            this.lbl_salary_date_accepted.AutoSize = true;
            this.lbl_salary_date_accepted.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl_salary_date_accepted.Location = new System.Drawing.Point(198, 27);
            this.lbl_salary_date_accepted.Name = "lbl_salary_date_accepted";
            this.lbl_salary_date_accepted.Size = new System.Drawing.Size(188, 25);
            this.lbl_salary_date_accepted.TabIndex = 10;
            this.lbl_salary_date_accepted.Text = "<-->";
            this.lbl_salary_date_accepted.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label114
            // 
            this.label114.AutoSize = true;
            this.label114.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label114.Location = new System.Drawing.Point(4, 1);
            this.label114.Name = "label114";
            this.label114.Size = new System.Drawing.Size(187, 25);
            this.label114.TabIndex = 0;
            this.label114.Text = "Date Approved";
            this.label114.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label116
            // 
            this.label116.AutoSize = true;
            this.label116.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label116.Location = new System.Drawing.Point(4, 27);
            this.label116.Name = "label116";
            this.label116.Size = new System.Drawing.Size(187, 25);
            this.label116.TabIndex = 1;
            this.label116.Text = "Date Accepted";
            this.label116.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label117
            // 
            this.label117.AutoSize = true;
            this.label117.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label117.Location = new System.Drawing.Point(4, 53);
            this.label117.Name = "label117";
            this.label117.Size = new System.Drawing.Size(187, 25);
            this.label117.TabIndex = 2;
            this.label117.Text = "Date Started";
            this.label117.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label118
            // 
            this.label118.AutoSize = true;
            this.label118.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label118.Location = new System.Drawing.Point(4, 79);
            this.label118.Name = "label118";
            this.label118.Size = new System.Drawing.Size(187, 25);
            this.label118.TabIndex = 3;
            this.label118.Text = "Approved Salary (PHP)";
            this.label118.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label120
            // 
            this.label120.AutoSize = true;
            this.label120.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label120.Location = new System.Drawing.Point(4, 105);
            this.label120.Name = "label120";
            this.label120.Size = new System.Drawing.Size(187, 25);
            this.label120.TabIndex = 4;
            this.label120.Text = "Annual-based Salary (PHP):";
            this.label120.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label122
            // 
            this.label122.AutoSize = true;
            this.label122.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label122.Location = new System.Drawing.Point(4, 131);
            this.label122.Name = "label122";
            this.label122.Size = new System.Drawing.Size(187, 25);
            this.label122.TabIndex = 5;
            this.label122.Text = "Annual Language Allowance (PHP):";
            this.label122.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label123
            // 
            this.label123.AutoSize = true;
            this.label123.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label123.Location = new System.Drawing.Point(4, 157);
            this.label123.Name = "label123";
            this.label123.Size = new System.Drawing.Size(187, 25);
            this.label123.TabIndex = 6;
            this.label123.Text = "Shift Allowance (PHP):";
            this.label123.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label124
            // 
            this.label124.AutoSize = true;
            this.label124.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label124.Location = new System.Drawing.Point(4, 209);
            this.label124.Name = "label124";
            this.label124.Size = new System.Drawing.Size(187, 25);
            this.label124.TabIndex = 7;
            this.label124.Text = "Relocation Allowance Detail:";
            this.label124.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label125
            // 
            this.label125.AutoSize = true;
            this.label125.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label125.Location = new System.Drawing.Point(4, 235);
            this.label125.Name = "label125";
            this.label125.Size = new System.Drawing.Size(187, 25);
            this.label125.TabIndex = 8;
            this.label125.Text = "Cost Center:";
            this.label125.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lbl_salary_date_approved
            // 
            this.lbl_salary_date_approved.AutoSize = true;
            this.lbl_salary_date_approved.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl_salary_date_approved.Location = new System.Drawing.Point(198, 1);
            this.lbl_salary_date_approved.Name = "lbl_salary_date_approved";
            this.lbl_salary_date_approved.Size = new System.Drawing.Size(188, 25);
            this.lbl_salary_date_approved.TabIndex = 9;
            this.lbl_salary_date_approved.Text = "<-->";
            this.lbl_salary_date_approved.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label128
            // 
            this.label128.AutoSize = true;
            this.label128.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label128.Location = new System.Drawing.Point(4, 183);
            this.label128.Name = "label128";
            this.label128.Size = new System.Drawing.Size(187, 25);
            this.label128.TabIndex = 19;
            this.label128.Text = "Relocation Allowance (PHP):";
            this.label128.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lbl_salary_reloc_allowance
            // 
            this.lbl_salary_reloc_allowance.AutoSize = true;
            this.lbl_salary_reloc_allowance.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl_salary_reloc_allowance.Location = new System.Drawing.Point(198, 183);
            this.lbl_salary_reloc_allowance.Name = "lbl_salary_reloc_allowance";
            this.lbl_salary_reloc_allowance.Size = new System.Drawing.Size(188, 25);
            this.lbl_salary_reloc_allowance.TabIndex = 20;
            this.lbl_salary_reloc_allowance.Text = "<-->";
            this.lbl_salary_reloc_allowance.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lbl_salary_reloc_detail
            // 
            this.lbl_salary_reloc_detail.AutoSize = true;
            this.lbl_salary_reloc_detail.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl_salary_reloc_detail.Location = new System.Drawing.Point(198, 209);
            this.lbl_salary_reloc_detail.Name = "lbl_salary_reloc_detail";
            this.lbl_salary_reloc_detail.Size = new System.Drawing.Size(188, 25);
            this.lbl_salary_reloc_detail.TabIndex = 21;
            this.lbl_salary_reloc_detail.Text = "<-->";
            this.lbl_salary_reloc_detail.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lbl_salary_cost_centre
            // 
            this.lbl_salary_cost_centre.AutoSize = true;
            this.lbl_salary_cost_centre.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl_salary_cost_centre.Location = new System.Drawing.Point(198, 235);
            this.lbl_salary_cost_centre.Name = "lbl_salary_cost_centre";
            this.lbl_salary_cost_centre.Size = new System.Drawing.Size(188, 25);
            this.lbl_salary_cost_centre.TabIndex = 22;
            this.lbl_salary_cost_centre.Text = "<-->";
            this.lbl_salary_cost_centre.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label140
            // 
            this.label140.BackColor = System.Drawing.SystemColors.Highlight;
            this.label140.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label140.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label140.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label140.Location = new System.Drawing.Point(0, 0);
            this.label140.Margin = new System.Windows.Forms.Padding(0);
            this.label140.Name = "label140";
            this.label140.Size = new System.Drawing.Size(390, 28);
            this.label140.TabIndex = 1;
            this.label140.Text = "Salary Info";
            this.label140.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tableLayoutPanel5
            // 
            this.tableLayoutPanel5.BackColor = System.Drawing.SystemColors.Control;
            this.tableLayoutPanel5.ColumnCount = 1;
            this.tableLayoutPanel5.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel5.Controls.Add(this.tableLayoutPanel6, 0, 1);
            this.tableLayoutPanel5.Controls.Add(this.label127, 0, 0);
            this.tableLayoutPanel5.Location = new System.Drawing.Point(6, 5);
            this.tableLayoutPanel5.Name = "tableLayoutPanel5";
            this.tableLayoutPanel5.RowCount = 3;
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 28F));
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 313F));
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 94F));
            this.tableLayoutPanel5.Size = new System.Drawing.Size(412, 341);
            this.tableLayoutPanel5.TabIndex = 5;
            // 
            // tableLayoutPanel6
            // 
            this.tableLayoutPanel6.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Single;
            this.tableLayoutPanel6.ColumnCount = 2;
            this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel6.Controls.Add(this.lbl_job_team, 1, 6);
            this.tableLayoutPanel6.Controls.Add(this.lbl_job_title, 1, 5);
            this.tableLayoutPanel6.Controls.Add(this.lbl_job_arvatolevel, 1, 4);
            this.tableLayoutPanel6.Controls.Add(this.lbl_job_bucket, 1, 3);
            this.tableLayoutPanel6.Controls.Add(this.lbl_job_titantitle, 1, 2);
            this.tableLayoutPanel6.Controls.Add(this.lbl_hiringmanager_name, 1, 1);
            this.tableLayoutPanel6.Controls.Add(this.label105, 0, 0);
            this.tableLayoutPanel6.Controls.Add(this.label106, 0, 1);
            this.tableLayoutPanel6.Controls.Add(this.label107, 0, 2);
            this.tableLayoutPanel6.Controls.Add(this.label108, 0, 3);
            this.tableLayoutPanel6.Controls.Add(this.label109, 0, 4);
            this.tableLayoutPanel6.Controls.Add(this.label110, 0, 5);
            this.tableLayoutPanel6.Controls.Add(this.label111, 0, 6);
            this.tableLayoutPanel6.Controls.Add(this.label112, 0, 8);
            this.tableLayoutPanel6.Controls.Add(this.label113, 0, 9);
            this.tableLayoutPanel6.Controls.Add(this.lbl_hiringmanager_id, 1, 0);
            this.tableLayoutPanel6.Controls.Add(this.label115, 0, 7);
            this.tableLayoutPanel6.Controls.Add(this.lbl_job_contract_type, 1, 7);
            this.tableLayoutPanel6.Controls.Add(this.lbl_job_role, 1, 8);
            this.tableLayoutPanel6.Controls.Add(this.lbl_owner_id, 1, 9);
            this.tableLayoutPanel6.Controls.Add(this.label119, 0, 10);
            this.tableLayoutPanel6.Controls.Add(this.lbl_owner_firstname, 1, 10);
            this.tableLayoutPanel6.Controls.Add(this.label121, 0, 11);
            this.tableLayoutPanel6.Controls.Add(this.lbl_owner_lastname, 1, 11);
            this.tableLayoutPanel6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel6.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tableLayoutPanel6.Location = new System.Drawing.Point(0, 28);
            this.tableLayoutPanel6.Margin = new System.Windows.Forms.Padding(0);
            this.tableLayoutPanel6.Name = "tableLayoutPanel6";
            this.tableLayoutPanel6.RowCount = 12;
            this.tableLayoutPanel6.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 25F));
            this.tableLayoutPanel6.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 25F));
            this.tableLayoutPanel6.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 25F));
            this.tableLayoutPanel6.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 25F));
            this.tableLayoutPanel6.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 25F));
            this.tableLayoutPanel6.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 25F));
            this.tableLayoutPanel6.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 25F));
            this.tableLayoutPanel6.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 25F));
            this.tableLayoutPanel6.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 25F));
            this.tableLayoutPanel6.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 25F));
            this.tableLayoutPanel6.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 25F));
            this.tableLayoutPanel6.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 25F));
            this.tableLayoutPanel6.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel6.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel6.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel6.Size = new System.Drawing.Size(412, 313);
            this.tableLayoutPanel6.TabIndex = 0;
            // 
            // lbl_job_team
            // 
            this.lbl_job_team.AutoSize = true;
            this.lbl_job_team.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl_job_team.Location = new System.Drawing.Point(209, 157);
            this.lbl_job_team.Name = "lbl_job_team";
            this.lbl_job_team.Size = new System.Drawing.Size(199, 25);
            this.lbl_job_team.TabIndex = 15;
            this.lbl_job_team.Text = "<-->";
            this.lbl_job_team.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lbl_job_title
            // 
            this.lbl_job_title.AutoSize = true;
            this.lbl_job_title.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl_job_title.Location = new System.Drawing.Point(209, 131);
            this.lbl_job_title.Name = "lbl_job_title";
            this.lbl_job_title.Size = new System.Drawing.Size(199, 25);
            this.lbl_job_title.TabIndex = 14;
            this.lbl_job_title.Text = "<-->";
            this.lbl_job_title.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lbl_job_arvatolevel
            // 
            this.lbl_job_arvatolevel.AutoSize = true;
            this.lbl_job_arvatolevel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl_job_arvatolevel.Location = new System.Drawing.Point(209, 105);
            this.lbl_job_arvatolevel.Name = "lbl_job_arvatolevel";
            this.lbl_job_arvatolevel.Size = new System.Drawing.Size(199, 25);
            this.lbl_job_arvatolevel.TabIndex = 13;
            this.lbl_job_arvatolevel.Text = "<-->";
            this.lbl_job_arvatolevel.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lbl_job_bucket
            // 
            this.lbl_job_bucket.AutoSize = true;
            this.lbl_job_bucket.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl_job_bucket.Location = new System.Drawing.Point(209, 79);
            this.lbl_job_bucket.Name = "lbl_job_bucket";
            this.lbl_job_bucket.Size = new System.Drawing.Size(199, 25);
            this.lbl_job_bucket.TabIndex = 12;
            this.lbl_job_bucket.Text = "<-->";
            this.lbl_job_bucket.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lbl_job_titantitle
            // 
            this.lbl_job_titantitle.AutoSize = true;
            this.lbl_job_titantitle.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl_job_titantitle.Location = new System.Drawing.Point(209, 53);
            this.lbl_job_titantitle.Name = "lbl_job_titantitle";
            this.lbl_job_titantitle.Size = new System.Drawing.Size(199, 25);
            this.lbl_job_titantitle.TabIndex = 11;
            this.lbl_job_titantitle.Text = "<-->";
            this.lbl_job_titantitle.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lbl_hiringmanager_name
            // 
            this.lbl_hiringmanager_name.AutoSize = true;
            this.lbl_hiringmanager_name.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl_hiringmanager_name.Location = new System.Drawing.Point(209, 27);
            this.lbl_hiringmanager_name.Name = "lbl_hiringmanager_name";
            this.lbl_hiringmanager_name.Size = new System.Drawing.Size(199, 25);
            this.lbl_hiringmanager_name.TabIndex = 10;
            this.lbl_hiringmanager_name.Text = "<-->";
            this.lbl_hiringmanager_name.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label105
            // 
            this.label105.AutoSize = true;
            this.label105.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label105.Location = new System.Drawing.Point(4, 1);
            this.label105.Name = "label105";
            this.label105.Size = new System.Drawing.Size(198, 25);
            this.label105.TabIndex = 0;
            this.label105.Text = "(Hiring Manager) Employee ID";
            this.label105.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label106
            // 
            this.label106.AutoSize = true;
            this.label106.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label106.Location = new System.Drawing.Point(4, 27);
            this.label106.Name = "label106";
            this.label106.Size = new System.Drawing.Size(198, 25);
            this.label106.TabIndex = 1;
            this.label106.Text = "(Hiring Manager) Name";
            this.label106.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label107
            // 
            this.label107.AutoSize = true;
            this.label107.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label107.Location = new System.Drawing.Point(4, 53);
            this.label107.Name = "label107";
            this.label107.Size = new System.Drawing.Size(198, 25);
            this.label107.TabIndex = 2;
            this.label107.Text = "Titan Title";
            this.label107.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label108
            // 
            this.label108.AutoSize = true;
            this.label108.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label108.Location = new System.Drawing.Point(4, 79);
            this.label108.Name = "label108";
            this.label108.Size = new System.Drawing.Size(198, 25);
            this.label108.TabIndex = 3;
            this.label108.Text = "Bucket";
            this.label108.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label109
            // 
            this.label109.AutoSize = true;
            this.label109.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label109.Location = new System.Drawing.Point(4, 105);
            this.label109.Name = "label109";
            this.label109.Size = new System.Drawing.Size(198, 25);
            this.label109.TabIndex = 4;
            this.label109.Text = "Arvato Level";
            this.label109.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label110
            // 
            this.label110.AutoSize = true;
            this.label110.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label110.Location = new System.Drawing.Point(4, 131);
            this.label110.Name = "label110";
            this.label110.Size = new System.Drawing.Size(198, 25);
            this.label110.TabIndex = 5;
            this.label110.Text = "Job Title";
            this.label110.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label111
            // 
            this.label111.AutoSize = true;
            this.label111.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label111.Location = new System.Drawing.Point(4, 157);
            this.label111.Name = "label111";
            this.label111.Size = new System.Drawing.Size(198, 25);
            this.label111.TabIndex = 6;
            this.label111.Text = "Team";
            this.label111.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label112
            // 
            this.label112.AutoSize = true;
            this.label112.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label112.Location = new System.Drawing.Point(4, 209);
            this.label112.Name = "label112";
            this.label112.Size = new System.Drawing.Size(198, 25);
            this.label112.TabIndex = 7;
            this.label112.Text = "Role";
            this.label112.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label113
            // 
            this.label113.AutoSize = true;
            this.label113.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label113.Location = new System.Drawing.Point(4, 235);
            this.label113.Name = "label113";
            this.label113.Size = new System.Drawing.Size(198, 25);
            this.label113.TabIndex = 8;
            this.label113.Text = "(Owner) Employee ID";
            this.label113.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lbl_hiringmanager_id
            // 
            this.lbl_hiringmanager_id.AutoSize = true;
            this.lbl_hiringmanager_id.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl_hiringmanager_id.Location = new System.Drawing.Point(209, 1);
            this.lbl_hiringmanager_id.Name = "lbl_hiringmanager_id";
            this.lbl_hiringmanager_id.Size = new System.Drawing.Size(199, 25);
            this.lbl_hiringmanager_id.TabIndex = 9;
            this.lbl_hiringmanager_id.Text = "<-->";
            this.lbl_hiringmanager_id.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label115
            // 
            this.label115.AutoSize = true;
            this.label115.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label115.Location = new System.Drawing.Point(4, 183);
            this.label115.Name = "label115";
            this.label115.Size = new System.Drawing.Size(198, 25);
            this.label115.TabIndex = 19;
            this.label115.Text = "Contract Type";
            this.label115.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lbl_job_contract_type
            // 
            this.lbl_job_contract_type.AutoSize = true;
            this.lbl_job_contract_type.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl_job_contract_type.Location = new System.Drawing.Point(209, 183);
            this.lbl_job_contract_type.Name = "lbl_job_contract_type";
            this.lbl_job_contract_type.Size = new System.Drawing.Size(199, 25);
            this.lbl_job_contract_type.TabIndex = 20;
            this.lbl_job_contract_type.Text = "<-->";
            this.lbl_job_contract_type.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lbl_job_role
            // 
            this.lbl_job_role.AutoSize = true;
            this.lbl_job_role.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl_job_role.Location = new System.Drawing.Point(209, 209);
            this.lbl_job_role.Name = "lbl_job_role";
            this.lbl_job_role.Size = new System.Drawing.Size(199, 25);
            this.lbl_job_role.TabIndex = 21;
            this.lbl_job_role.Text = "<-->";
            this.lbl_job_role.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lbl_owner_id
            // 
            this.lbl_owner_id.AutoSize = true;
            this.lbl_owner_id.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl_owner_id.Location = new System.Drawing.Point(209, 235);
            this.lbl_owner_id.Name = "lbl_owner_id";
            this.lbl_owner_id.Size = new System.Drawing.Size(199, 25);
            this.lbl_owner_id.TabIndex = 22;
            this.lbl_owner_id.Text = "<-->";
            this.lbl_owner_id.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label119
            // 
            this.label119.AutoSize = true;
            this.label119.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label119.Location = new System.Drawing.Point(4, 261);
            this.label119.Name = "label119";
            this.label119.Size = new System.Drawing.Size(198, 25);
            this.label119.TabIndex = 23;
            this.label119.Text = "(Owner) Firstname";
            this.label119.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lbl_owner_firstname
            // 
            this.lbl_owner_firstname.AutoSize = true;
            this.lbl_owner_firstname.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl_owner_firstname.Location = new System.Drawing.Point(209, 261);
            this.lbl_owner_firstname.Name = "lbl_owner_firstname";
            this.lbl_owner_firstname.Size = new System.Drawing.Size(199, 25);
            this.lbl_owner_firstname.TabIndex = 24;
            this.lbl_owner_firstname.Text = "<-->";
            this.lbl_owner_firstname.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label121
            // 
            this.label121.AutoSize = true;
            this.label121.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label121.Location = new System.Drawing.Point(4, 287);
            this.label121.Name = "label121";
            this.label121.Size = new System.Drawing.Size(198, 25);
            this.label121.TabIndex = 25;
            this.label121.Text = "(Owner) Lastname";
            this.label121.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lbl_owner_lastname
            // 
            this.lbl_owner_lastname.AutoSize = true;
            this.lbl_owner_lastname.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl_owner_lastname.Location = new System.Drawing.Point(209, 287);
            this.lbl_owner_lastname.Name = "lbl_owner_lastname";
            this.lbl_owner_lastname.Size = new System.Drawing.Size(199, 25);
            this.lbl_owner_lastname.TabIndex = 28;
            this.lbl_owner_lastname.Text = "<-->";
            this.lbl_owner_lastname.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label127
            // 
            this.label127.BackColor = System.Drawing.SystemColors.Highlight;
            this.label127.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label127.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label127.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label127.Location = new System.Drawing.Point(0, 0);
            this.label127.Margin = new System.Windows.Forms.Padding(0);
            this.label127.Name = "label127";
            this.label127.Size = new System.Drawing.Size(412, 28);
            this.label127.TabIndex = 1;
            this.label127.Text = "Job Info";
            this.label127.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // FormEmployeeDashboard
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(853, 572);
            this.Controls.Add(this.tabControl1);
            this.Controls.Add(this.panel1);
            this.Name = "FormEmployeeDashboard";
            this.Padding = new System.Windows.Forms.Padding(12);
            this.Text = "Employee";
            this.Load += new System.EventHandler(this.FormEmployeeDashboard_Load);
            this.panel1.ResumeLayout(false);
            this.tabPage4.ResumeLayout(false);
            this.tableLayoutPanel3.ResumeLayout(false);
            this.tableLayoutPanel3.PerformLayout();
            this.tableLayoutPanel2.ResumeLayout(false);
            this.tableLayoutPanel2.PerformLayout();
            this.tabPage1.ResumeLayout(false);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel4.ResumeLayout(false);
            this.tableLayoutPanel4.PerformLayout();
            this.tabControl1.ResumeLayout(false);
            this.tabPage2.ResumeLayout(false);
            this.tableLayoutPanel7.ResumeLayout(false);
            this.tableLayoutPanel8.ResumeLayout(false);
            this.tableLayoutPanel8.PerformLayout();
            this.tableLayoutPanel5.ResumeLayout(false);
            this.tableLayoutPanel6.ResumeLayout(false);
            this.tableLayoutPanel6.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button btn_ok;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel3;
        private System.Windows.Forms.LinkLabel linkLabel21;
        private System.Windows.Forms.CheckBox checkBox38;
        private System.Windows.Forms.CheckBox checkBox37;
        private System.Windows.Forms.CheckBox checkBox36;
        private System.Windows.Forms.CheckBox checkBox35;
        private System.Windows.Forms.CheckBox checkBox34;
        private System.Windows.Forms.CheckBox checkBox33;
        private System.Windows.Forms.CheckBox checkBox32;
        private System.Windows.Forms.CheckBox checkBox31;
        private System.Windows.Forms.CheckBox checkBox30;
        private System.Windows.Forms.CheckBox checkBox29;
        private System.Windows.Forms.CheckBox checkBox28;
        private System.Windows.Forms.CheckBox checkBox27;
        private System.Windows.Forms.CheckBox checkBox26;
        private System.Windows.Forms.CheckBox checkBox25;
        private System.Windows.Forms.CheckBox checkBox24;
        private System.Windows.Forms.CheckBox checkBox23;
        private System.Windows.Forms.CheckBox checkBox22;
        private System.Windows.Forms.CheckBox checkBox21;
        private System.Windows.Forms.Label label84;
        private System.Windows.Forms.Label label59;
        private System.Windows.Forms.LinkLabel link_locker;
        private System.Windows.Forms.LinkLabel link_IdentificationCard;
        private System.Windows.Forms.LinkLabel link_acceptablePolicy;
        private System.Windows.Forms.LinkLabel linkLabel35;
        private System.Windows.Forms.LinkLabel link_consent;
        private System.Windows.Forms.LinkLabel link_acceptanceCOC;
        private System.Windows.Forms.LinkLabel link_acceptance_COD;
        private System.Windows.Forms.LinkLabel link_NSOmarriage;
        private System.Windows.Forms.LinkLabel link_NSOdependent;
        private System.Windows.Forms.LinkLabel link_cedula;
        private System.Windows.Forms.LinkLabel link_OccupationalPermit;
        private System.Windows.Forms.LinkLabel link_2316;
        private System.Windows.Forms.LinkLabel link_2305;
        private System.Windows.Forms.LinkLabel link_1905;
        private System.Windows.Forms.LinkLabel link_bankForm;
        private System.Windows.Forms.LinkLabel link_HMO;
        private System.Windows.Forms.Label label60;
        private System.Windows.Forms.Label label61;
        private System.Windows.Forms.Label label62;
        private System.Windows.Forms.Label label63;
        private System.Windows.Forms.Label labs;
        private System.Windows.Forms.Label label65;
        private System.Windows.Forms.Label label66;
        private System.Windows.Forms.Label label67;
        private System.Windows.Forms.Label label68;
        private System.Windows.Forms.Label label69;
        private System.Windows.Forms.Label label70;
        private System.Windows.Forms.Label label71;
        private System.Windows.Forms.Label label72;
        private System.Windows.Forms.Label label73;
        private System.Windows.Forms.Label label74;
        private System.Windows.Forms.Label label75;
        private System.Windows.Forms.Label label76;
        private System.Windows.Forms.Label label77;
        private System.Windows.Forms.Label label78;
        private System.Windows.Forms.Label label79;
        private System.Windows.Forms.Label label80;
        private System.Windows.Forms.Label label81;
        private System.Windows.Forms.Label label82;
        private System.Windows.Forms.Label label83;
        private System.Windows.Forms.Label label85;
        private System.Windows.Forms.Label label86;
        private System.Windows.Forms.Label label87;
        private System.Windows.Forms.Label label88;
        private System.Windows.Forms.Label label89;
        private System.Windows.Forms.Label label90;
        private System.Windows.Forms.Label label91;
        private System.Windows.Forms.Label label92;
        private System.Windows.Forms.Label label93;
        private System.Windows.Forms.Label label94;
        private System.Windows.Forms.Label label95;
        private System.Windows.Forms.Label label96;
        private System.Windows.Forms.Label label97;
        private System.Windows.Forms.LinkLabel link_payroll;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel2;
        private System.Windows.Forms.CheckBox checkBox20;
        private System.Windows.Forms.CheckBox checkBox19;
        private System.Windows.Forms.CheckBox checkBox18;
        private System.Windows.Forms.CheckBox checkBox17;
        private System.Windows.Forms.CheckBox checkBox16;
        private System.Windows.Forms.CheckBox checkBox15;
        private System.Windows.Forms.CheckBox checkBox14;
        private System.Windows.Forms.CheckBox checkBox13;
        private System.Windows.Forms.CheckBox checkBox12;
        private System.Windows.Forms.CheckBox checkBox11;
        private System.Windows.Forms.CheckBox checkBox10;
        private System.Windows.Forms.CheckBox checkBox9;
        private System.Windows.Forms.CheckBox checkBox8;
        private System.Windows.Forms.CheckBox checkBox7;
        private System.Windows.Forms.CheckBox checkBox6;
        private System.Windows.Forms.CheckBox checkBox5;
        private System.Windows.Forms.CheckBox checkBox4;
        private System.Windows.Forms.CheckBox checkBox3;
        private System.Windows.Forms.CheckBox checkBox2;
        private System.Windows.Forms.LinkLabel linkLabel20;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.Label label45;
        private System.Windows.Forms.Label label47;
        private System.Windows.Forms.Label label49;
        private System.Windows.Forms.Label label51;
        private System.Windows.Forms.LinkLabel linkLabel19;
        private System.Windows.Forms.LinkLabel linkLabel18;
        private System.Windows.Forms.LinkLabel link_informationForm;
        private System.Windows.Forms.LinkLabel link_backgroundResult;
        private System.Windows.Forms.LinkLabel link_backgroundCheck;
        private System.Windows.Forms.LinkLabel link_resume;
        private System.Windows.Forms.LinkLabel link_InterviewDocs;
        private System.Windows.Forms.LinkLabel link_NDA;
        private System.Windows.Forms.LinkLabel link_NewHire;
        private System.Windows.Forms.LinkLabel link_SNO;
        private System.Windows.Forms.LinkLabel link_TOR;
        private System.Windows.Forms.LinkLabel link_COE;
        private System.Windows.Forms.LinkLabel link_NBI;
        private System.Windows.Forms.LinkLabel lin_IDPicture;
        private System.Windows.Forms.LinkLabel link_validID;
        private System.Windows.Forms.LinkLabel link_ProofOfPagibig;
        private System.Windows.Forms.LinkLabel link_proofOfPhilHealth;
        private System.Windows.Forms.LinkLabel link_proofOfSSS;
        private System.Windows.Forms.Label label48;
        private System.Windows.Forms.Label label46;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label50;
        private System.Windows.Forms.Label label52;
        private System.Windows.Forms.Label label53;
        private System.Windows.Forms.Label label54;
        private System.Windows.Forms.Label label55;
        private System.Windows.Forms.Label label56;
        private System.Windows.Forms.Label label57;
        private System.Windows.Forms.Label label58;
        private System.Windows.Forms.LinkLabel link_proofOftin;
        private System.Windows.Forms.CheckBox checkBox1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel4;
        private System.Windows.Forms.Label lbl_info_email;
        private System.Windows.Forms.Label lbl_info_secondary_contact;
        private System.Windows.Forms.Label lbl_info_primary_contact;
        private System.Windows.Forms.Label lbl_info_lastname;
        private System.Windows.Forms.Label lbl_info_middlename;
        private System.Windows.Forms.Label lbl_info_firstname;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lbl_info_employee_id;
        private System.Windows.Forms.Label lbl_benefits;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label lbl_info_sss;
        private System.Windows.Forms.Label lbl_info_tin;
        private System.Windows.Forms.Label lbl_info_hdmf;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label lbl_info_bpi;
        private System.Windows.Forms.Label lbl_address_no;
        private System.Windows.Forms.Label label64;
        private System.Windows.Forms.Label label98;
        private System.Windows.Forms.Label label99;
        private System.Windows.Forms.Label label104;
        private System.Windows.Forms.Label lbl_address_postal_no;
        private System.Windows.Forms.Label lbl_address_street;
        private System.Windows.Forms.Label lbl_address_postal_area;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel5;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel6;
        private System.Windows.Forms.Label lbl_job_team;
        private System.Windows.Forms.Label lbl_job_title;
        private System.Windows.Forms.Label lbl_job_arvatolevel;
        private System.Windows.Forms.Label lbl_job_bucket;
        private System.Windows.Forms.Label lbl_job_titantitle;
        private System.Windows.Forms.Label lbl_hiringmanager_name;
        private System.Windows.Forms.Label label105;
        private System.Windows.Forms.Label label106;
        private System.Windows.Forms.Label label107;
        private System.Windows.Forms.Label label108;
        private System.Windows.Forms.Label label109;
        private System.Windows.Forms.Label label110;
        private System.Windows.Forms.Label label111;
        private System.Windows.Forms.Label label112;
        private System.Windows.Forms.Label label113;
        private System.Windows.Forms.Label lbl_hiringmanager_id;
        private System.Windows.Forms.Label label115;
        private System.Windows.Forms.Label lbl_job_contract_type;
        private System.Windows.Forms.Label lbl_job_role;
        private System.Windows.Forms.Label lbl_owner_id;
        private System.Windows.Forms.Label label119;
        private System.Windows.Forms.Label lbl_owner_firstname;
        private System.Windows.Forms.Label label121;
        private System.Windows.Forms.Label lbl_owner_lastname;
        private System.Windows.Forms.Label label127;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel7;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel8;
        private System.Windows.Forms.Label lbl_salary_shift_allowance;
        private System.Windows.Forms.Label lbl_salary_annual_allowance;
        private System.Windows.Forms.Label lbl_salary_annual;
        private System.Windows.Forms.Label lbl_salary_approved;
        private System.Windows.Forms.Label lbl_salary_date_started;
        private System.Windows.Forms.Label lbl_salary_date_accepted;
        private System.Windows.Forms.Label label114;
        private System.Windows.Forms.Label label116;
        private System.Windows.Forms.Label label117;
        private System.Windows.Forms.Label label118;
        private System.Windows.Forms.Label label120;
        private System.Windows.Forms.Label label122;
        private System.Windows.Forms.Label label123;
        private System.Windows.Forms.Label label124;
        private System.Windows.Forms.Label label125;
        private System.Windows.Forms.Label lbl_salary_date_approved;
        private System.Windows.Forms.Label label128;
        private System.Windows.Forms.Label lbl_salary_reloc_allowance;
        private System.Windows.Forms.Label lbl_salary_reloc_detail;
        private System.Windows.Forms.Label lbl_salary_cost_centre;
        private System.Windows.Forms.Label label140;
        private System.Windows.Forms.Label lbl_info_maritalstatus;
        private System.Windows.Forms.Label sdf;
    }
}