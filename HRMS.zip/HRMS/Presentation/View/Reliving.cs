﻿using System.Windows.Forms;
using Presentation.Modules;

namespace Presentation.View
{
    public partial class VReliving : UserControl
    {
        public VReliving()
        {
            InitializeComponent();
        }
    }
}
