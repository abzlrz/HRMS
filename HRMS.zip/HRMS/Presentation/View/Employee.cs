﻿using Presentation.Modules;
using System.Windows.Forms;

namespace Presentation.View
{
    public partial class VEmployee : UserControl
    {
        public VEmployee()
        {
            InitializeComponent();
        }
        
    }
}
