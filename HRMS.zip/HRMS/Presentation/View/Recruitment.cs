﻿using System.Windows.Forms;
using Presentation.Modules;

namespace Presentation.View
{
    public partial class VRecruitment : UserControl
    {
        public VRecruitment()
        {
            InitializeComponent();
        }
        
    }
}
