﻿using Presentation.Modules;
using System.Windows.Forms;

namespace Presentation.View
{
    public partial class VTraining : UserControl
    {
        public VTraining()
        {
            InitializeComponent();
        }
    }
}
