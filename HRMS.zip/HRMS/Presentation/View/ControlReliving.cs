﻿using System.Windows.Forms;
using Presentation.Modules;

namespace Presentation.View
{
    public partial class ControlReliving : UserControl
    {
        public ControlReliving()
        {
            InitializeComponent();
        }
    }
}
