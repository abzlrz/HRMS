﻿using Presentation.Modules;
using System.Windows.Forms;

namespace Presentation.View
{
    public partial class ControlEmployee : UserControl
    {
        public ControlEmployee()
        {
            InitializeComponent();
        }
        
    }
}
