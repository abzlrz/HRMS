﻿using System.Windows.Forms;
using Presentation.Modules;

namespace Presentation.View
{
    public partial class ControlRecruitment : UserControl
    {
        public ControlRecruitment()
        {
            InitializeComponent();
        }
        
    }
}
