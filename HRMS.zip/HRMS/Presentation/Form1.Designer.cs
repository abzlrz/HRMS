﻿namespace Presentation
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tableLayoutPanel6 = new System.Windows.Forms.TableLayoutPanel();
            this.date_to = new System.Windows.Forms.DateTimePicker();
            this.lbl_fromdate = new System.Windows.Forms.Label();
            this.tbx_course = new System.Windows.Forms.TextBox();
            this.lbl_course = new System.Windows.Forms.Label();
            this.lbl_school = new System.Windows.Forms.Label();
            this.lbl_location = new System.Windows.Forms.Label();
            this.lbl_degree = new System.Windows.Forms.Label();
            this.tbx_school = new System.Windows.Forms.TextBox();
            this.tbx_location = new System.Windows.Forms.TextBox();
            this.cbx_degree = new System.Windows.Forms.ComboBox();
            this.lbl_todate = new System.Windows.Forms.Label();
            this.date_from = new System.Windows.Forms.DateTimePicker();
            this.panel2 = new System.Windows.Forms.Panel();
            this.main = new System.Windows.Forms.Panel();
            this.btn_cancel = new System.Windows.Forms.Button();
            this.btn_save = new System.Windows.Forms.Button();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.label1 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.label6 = new System.Windows.Forms.Label();
            this.dateTimePicker2 = new System.Windows.Forms.DateTimePicker();
            this.view_education = new System.Windows.Forms.DataGridView();
            this.tableLayoutPanel3 = new System.Windows.Forms.TableLayoutPanel();
            this.checkAll2 = new System.Windows.Forms.CheckBox();
            this.linkLabel21 = new System.Windows.Forms.LinkLabel();
            this.checkBox38 = new System.Windows.Forms.CheckBox();
            this.checkBox37 = new System.Windows.Forms.CheckBox();
            this.checkBox36 = new System.Windows.Forms.CheckBox();
            this.checkBox35 = new System.Windows.Forms.CheckBox();
            this.checkBox34 = new System.Windows.Forms.CheckBox();
            this.checkBox33 = new System.Windows.Forms.CheckBox();
            this.checkBox32 = new System.Windows.Forms.CheckBox();
            this.checkBox31 = new System.Windows.Forms.CheckBox();
            this.checkBox30 = new System.Windows.Forms.CheckBox();
            this.checkBox29 = new System.Windows.Forms.CheckBox();
            this.checkBox28 = new System.Windows.Forms.CheckBox();
            this.checkBox27 = new System.Windows.Forms.CheckBox();
            this.checkBox26 = new System.Windows.Forms.CheckBox();
            this.checkBox25 = new System.Windows.Forms.CheckBox();
            this.checkBox24 = new System.Windows.Forms.CheckBox();
            this.checkBox23 = new System.Windows.Forms.CheckBox();
            this.checkBox22 = new System.Windows.Forms.CheckBox();
            this.checkBox21 = new System.Windows.Forms.CheckBox();
            this.label84 = new System.Windows.Forms.Label();
            this.label59 = new System.Windows.Forms.Label();
            this.link_locker = new System.Windows.Forms.LinkLabel();
            this.link_IdentificationCard = new System.Windows.Forms.LinkLabel();
            this.link_acceptablePolicy = new System.Windows.Forms.LinkLabel();
            this.linkLabel35 = new System.Windows.Forms.LinkLabel();
            this.link_consent = new System.Windows.Forms.LinkLabel();
            this.link_acceptanceCOC = new System.Windows.Forms.LinkLabel();
            this.link_acceptance_COD = new System.Windows.Forms.LinkLabel();
            this.link_NSOmarriage = new System.Windows.Forms.LinkLabel();
            this.link_NSOdependent = new System.Windows.Forms.LinkLabel();
            this.link_cedula = new System.Windows.Forms.LinkLabel();
            this.link_OccupationalPermit = new System.Windows.Forms.LinkLabel();
            this.link_2316 = new System.Windows.Forms.LinkLabel();
            this.link_2305 = new System.Windows.Forms.LinkLabel();
            this.link_1905 = new System.Windows.Forms.LinkLabel();
            this.link_bankForm = new System.Windows.Forms.LinkLabel();
            this.link_HMO = new System.Windows.Forms.LinkLabel();
            this.label60 = new System.Windows.Forms.Label();
            this.label61 = new System.Windows.Forms.Label();
            this.label62 = new System.Windows.Forms.Label();
            this.label63 = new System.Windows.Forms.Label();
            this.labs = new System.Windows.Forms.Label();
            this.label65 = new System.Windows.Forms.Label();
            this.label66 = new System.Windows.Forms.Label();
            this.label67 = new System.Windows.Forms.Label();
            this.label68 = new System.Windows.Forms.Label();
            this.label69 = new System.Windows.Forms.Label();
            this.label70 = new System.Windows.Forms.Label();
            this.label71 = new System.Windows.Forms.Label();
            this.label72 = new System.Windows.Forms.Label();
            this.label73 = new System.Windows.Forms.Label();
            this.label74 = new System.Windows.Forms.Label();
            this.label75 = new System.Windows.Forms.Label();
            this.label76 = new System.Windows.Forms.Label();
            this.label77 = new System.Windows.Forms.Label();
            this.label78 = new System.Windows.Forms.Label();
            this.label79 = new System.Windows.Forms.Label();
            this.label80 = new System.Windows.Forms.Label();
            this.label81 = new System.Windows.Forms.Label();
            this.label82 = new System.Windows.Forms.Label();
            this.label83 = new System.Windows.Forms.Label();
            this.label85 = new System.Windows.Forms.Label();
            this.label86 = new System.Windows.Forms.Label();
            this.label87 = new System.Windows.Forms.Label();
            this.label88 = new System.Windows.Forms.Label();
            this.label89 = new System.Windows.Forms.Label();
            this.label90 = new System.Windows.Forms.Label();
            this.label91 = new System.Windows.Forms.Label();
            this.label92 = new System.Windows.Forms.Label();
            this.label93 = new System.Windows.Forms.Label();
            this.label94 = new System.Windows.Forms.Label();
            this.label95 = new System.Windows.Forms.Label();
            this.label96 = new System.Windows.Forms.Label();
            this.label97 = new System.Windows.Forms.Label();
            this.link_payroll = new System.Windows.Forms.LinkLabel();
            this.tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
            this.checkAll1 = new System.Windows.Forms.CheckBox();
            this.checkBox20 = new System.Windows.Forms.CheckBox();
            this.checkBox19 = new System.Windows.Forms.CheckBox();
            this.checkBox18 = new System.Windows.Forms.CheckBox();
            this.checkBox17 = new System.Windows.Forms.CheckBox();
            this.checkBox16 = new System.Windows.Forms.CheckBox();
            this.checkBox15 = new System.Windows.Forms.CheckBox();
            this.checkBox14 = new System.Windows.Forms.CheckBox();
            this.checkBox13 = new System.Windows.Forms.CheckBox();
            this.checkBox12 = new System.Windows.Forms.CheckBox();
            this.checkBox11 = new System.Windows.Forms.CheckBox();
            this.checkBox10 = new System.Windows.Forms.CheckBox();
            this.checkBox9 = new System.Windows.Forms.CheckBox();
            this.checkBox8 = new System.Windows.Forms.CheckBox();
            this.checkBox7 = new System.Windows.Forms.CheckBox();
            this.checkBox6 = new System.Windows.Forms.CheckBox();
            this.checkBox5 = new System.Windows.Forms.CheckBox();
            this.checkBox4 = new System.Windows.Forms.CheckBox();
            this.checkBox3 = new System.Windows.Forms.CheckBox();
            this.checkBox2 = new System.Windows.Forms.CheckBox();
            this.linkLabel20 = new System.Windows.Forms.LinkLabel();
            this.label10 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.label33 = new System.Windows.Forms.Label();
            this.label35 = new System.Windows.Forms.Label();
            this.label37 = new System.Windows.Forms.Label();
            this.label39 = new System.Windows.Forms.Label();
            this.label41 = new System.Windows.Forms.Label();
            this.label43 = new System.Windows.Forms.Label();
            this.label45 = new System.Windows.Forms.Label();
            this.label47 = new System.Windows.Forms.Label();
            this.label49 = new System.Windows.Forms.Label();
            this.label51 = new System.Windows.Forms.Label();
            this.linkLabel19 = new System.Windows.Forms.LinkLabel();
            this.linkLabel18 = new System.Windows.Forms.LinkLabel();
            this.link_informationForm = new System.Windows.Forms.LinkLabel();
            this.link_backgroundResult = new System.Windows.Forms.LinkLabel();
            this.link_backgroundCheck = new System.Windows.Forms.LinkLabel();
            this.link_resume = new System.Windows.Forms.LinkLabel();
            this.link_InterviewDocs = new System.Windows.Forms.LinkLabel();
            this.link_NDA = new System.Windows.Forms.LinkLabel();
            this.link_NewHire = new System.Windows.Forms.LinkLabel();
            this.link_SNO = new System.Windows.Forms.LinkLabel();
            this.link_TOR = new System.Windows.Forms.LinkLabel();
            this.link_COE = new System.Windows.Forms.LinkLabel();
            this.link_NBI = new System.Windows.Forms.LinkLabel();
            this.lin_IDPicture = new System.Windows.Forms.LinkLabel();
            this.link_validID = new System.Windows.Forms.LinkLabel();
            this.link_ProofOfPagibig = new System.Windows.Forms.LinkLabel();
            this.link_proofOfPhilHealth = new System.Windows.Forms.LinkLabel();
            this.link_proofOfSSS = new System.Windows.Forms.LinkLabel();
            this.label48 = new System.Windows.Forms.Label();
            this.label46 = new System.Windows.Forms.Label();
            this.label44 = new System.Windows.Forms.Label();
            this.label42 = new System.Windows.Forms.Label();
            this.label40 = new System.Windows.Forms.Label();
            this.label38 = new System.Windows.Forms.Label();
            this.label36 = new System.Windows.Forms.Label();
            this.label34 = new System.Windows.Forms.Label();
            this.label32 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label50 = new System.Windows.Forms.Label();
            this.label52 = new System.Windows.Forms.Label();
            this.label53 = new System.Windows.Forms.Label();
            this.label54 = new System.Windows.Forms.Label();
            this.label55 = new System.Windows.Forms.Label();
            this.label56 = new System.Windows.Forms.Label();
            this.label57 = new System.Windows.Forms.Label();
            this.label58 = new System.Windows.Forms.Label();
            this.link_proofOftin = new System.Windows.Forms.LinkLabel();
            this.checkBox1 = new System.Windows.Forms.CheckBox();
            this.tableLayoutPanel6.SuspendLayout();
            this.panel2.SuspendLayout();
            this.main.SuspendLayout();
            this.tableLayoutPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.view_education)).BeginInit();
            this.tableLayoutPanel3.SuspendLayout();
            this.tableLayoutPanel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // tableLayoutPanel6
            // 
            this.tableLayoutPanel6.ColumnCount = 2;
            this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 41.07649F));
            this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 58.92351F));
            this.tableLayoutPanel6.Controls.Add(this.date_to, 1, 5);
            this.tableLayoutPanel6.Controls.Add(this.lbl_fromdate, 0, 4);
            this.tableLayoutPanel6.Controls.Add(this.tbx_course, 1, 3);
            this.tableLayoutPanel6.Controls.Add(this.lbl_course, 0, 3);
            this.tableLayoutPanel6.Controls.Add(this.lbl_school, 0, 0);
            this.tableLayoutPanel6.Controls.Add(this.lbl_location, 0, 1);
            this.tableLayoutPanel6.Controls.Add(this.lbl_degree, 0, 2);
            this.tableLayoutPanel6.Controls.Add(this.tbx_school, 1, 0);
            this.tableLayoutPanel6.Controls.Add(this.tbx_location, 1, 1);
            this.tableLayoutPanel6.Controls.Add(this.cbx_degree, 1, 2);
            this.tableLayoutPanel6.Controls.Add(this.lbl_todate, 0, 5);
            this.tableLayoutPanel6.Controls.Add(this.date_from, 1, 4);
            this.tableLayoutPanel6.Location = new System.Drawing.Point(97, 62);
            this.tableLayoutPanel6.Margin = new System.Windows.Forms.Padding(1);
            this.tableLayoutPanel6.Name = "tableLayoutPanel6";
            this.tableLayoutPanel6.RowCount = 6;
            this.tableLayoutPanel6.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 22F));
            this.tableLayoutPanel6.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 22F));
            this.tableLayoutPanel6.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 23F));
            this.tableLayoutPanel6.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 23F));
            this.tableLayoutPanel6.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 22F));
            this.tableLayoutPanel6.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 68F));
            this.tableLayoutPanel6.Size = new System.Drawing.Size(353, 136);
            this.tableLayoutPanel6.TabIndex = 3;
            // 
            // date_to
            // 
            this.date_to.Dock = System.Windows.Forms.DockStyle.Fill;
            this.date_to.Location = new System.Drawing.Point(145, 112);
            this.date_to.Margin = new System.Windows.Forms.Padding(0);
            this.date_to.Name = "date_to";
            this.date_to.Size = new System.Drawing.Size(208, 20);
            this.date_to.TabIndex = 115;
            // 
            // lbl_fromdate
            // 
            this.lbl_fromdate.AutoSize = true;
            this.lbl_fromdate.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl_fromdate.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_fromdate.ImageAlign = System.Drawing.ContentAlignment.TopRight;
            this.lbl_fromdate.ImageIndex = 1;
            this.lbl_fromdate.Location = new System.Drawing.Point(3, 90);
            this.lbl_fromdate.Name = "lbl_fromdate";
            this.lbl_fromdate.Size = new System.Drawing.Size(139, 22);
            this.lbl_fromdate.TabIndex = 112;
            this.lbl_fromdate.Text = "From Date:";
            // 
            // tbx_course
            // 
            this.tbx_course.Dock = System.Windows.Forms.DockStyle.Top;
            this.tbx_course.Location = new System.Drawing.Point(145, 67);
            this.tbx_course.Margin = new System.Windows.Forms.Padding(0);
            this.tbx_course.Name = "tbx_course";
            this.tbx_course.Size = new System.Drawing.Size(208, 20);
            this.tbx_course.TabIndex = 111;
            this.tbx_course.Tag = "required";
            // 
            // lbl_course
            // 
            this.lbl_course.AutoSize = true;
            this.lbl_course.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl_course.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_course.ImageAlign = System.Drawing.ContentAlignment.TopRight;
            this.lbl_course.ImageIndex = 1;
            this.lbl_course.Location = new System.Drawing.Point(3, 67);
            this.lbl_course.Name = "lbl_course";
            this.lbl_course.Size = new System.Drawing.Size(139, 23);
            this.lbl_course.TabIndex = 90;
            this.lbl_course.Text = "Course/Program:";
            // 
            // lbl_school
            // 
            this.lbl_school.AutoSize = true;
            this.lbl_school.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl_school.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_school.ImageAlign = System.Drawing.ContentAlignment.TopRight;
            this.lbl_school.ImageIndex = 1;
            this.lbl_school.Location = new System.Drawing.Point(3, 0);
            this.lbl_school.Name = "lbl_school";
            this.lbl_school.Size = new System.Drawing.Size(139, 22);
            this.lbl_school.TabIndex = 51;
            this.lbl_school.Text = "School/University:";
            // 
            // lbl_location
            // 
            this.lbl_location.AutoSize = true;
            this.lbl_location.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl_location.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_location.ImageAlign = System.Drawing.ContentAlignment.TopRight;
            this.lbl_location.ImageIndex = 1;
            this.lbl_location.Location = new System.Drawing.Point(3, 22);
            this.lbl_location.Name = "lbl_location";
            this.lbl_location.Size = new System.Drawing.Size(139, 22);
            this.lbl_location.TabIndex = 52;
            this.lbl_location.Text = "Location:";
            // 
            // lbl_degree
            // 
            this.lbl_degree.AutoSize = true;
            this.lbl_degree.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl_degree.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_degree.ImageAlign = System.Drawing.ContentAlignment.TopRight;
            this.lbl_degree.ImageIndex = 1;
            this.lbl_degree.Location = new System.Drawing.Point(3, 44);
            this.lbl_degree.Name = "lbl_degree";
            this.lbl_degree.Size = new System.Drawing.Size(139, 23);
            this.lbl_degree.TabIndex = 83;
            this.lbl_degree.Text = "Academic Degree:";
            // 
            // tbx_school
            // 
            this.tbx_school.Dock = System.Windows.Forms.DockStyle.Top;
            this.tbx_school.Location = new System.Drawing.Point(145, 0);
            this.tbx_school.Margin = new System.Windows.Forms.Padding(0);
            this.tbx_school.Name = "tbx_school";
            this.tbx_school.Size = new System.Drawing.Size(208, 20);
            this.tbx_school.TabIndex = 108;
            this.tbx_school.Tag = "required";
            // 
            // tbx_location
            // 
            this.tbx_location.Dock = System.Windows.Forms.DockStyle.Top;
            this.tbx_location.Location = new System.Drawing.Point(145, 22);
            this.tbx_location.Margin = new System.Windows.Forms.Padding(0);
            this.tbx_location.Name = "tbx_location";
            this.tbx_location.Size = new System.Drawing.Size(208, 20);
            this.tbx_location.TabIndex = 109;
            this.tbx_location.Tag = "required";
            // 
            // cbx_degree
            // 
            this.cbx_degree.Dock = System.Windows.Forms.DockStyle.Fill;
            this.cbx_degree.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbx_degree.FormattingEnabled = true;
            this.cbx_degree.Items.AddRange(new object[] {
            "Diploma",
            "Bachelor",
            "Masteral",
            "Doctorate",
            "Others"});
            this.cbx_degree.Location = new System.Drawing.Point(145, 44);
            this.cbx_degree.Margin = new System.Windows.Forms.Padding(0);
            this.cbx_degree.Name = "cbx_degree";
            this.cbx_degree.Size = new System.Drawing.Size(208, 21);
            this.cbx_degree.TabIndex = 110;
            // 
            // lbl_todate
            // 
            this.lbl_todate.AutoSize = true;
            this.lbl_todate.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl_todate.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_todate.ImageAlign = System.Drawing.ContentAlignment.TopRight;
            this.lbl_todate.ImageIndex = 1;
            this.lbl_todate.Location = new System.Drawing.Point(3, 112);
            this.lbl_todate.Name = "lbl_todate";
            this.lbl_todate.Size = new System.Drawing.Size(139, 68);
            this.lbl_todate.TabIndex = 113;
            this.lbl_todate.Text = "To Date:";
            // 
            // date_from
            // 
            this.date_from.Dock = System.Windows.Forms.DockStyle.Fill;
            this.date_from.Location = new System.Drawing.Point(145, 90);
            this.date_from.Margin = new System.Windows.Forms.Padding(0);
            this.date_from.Name = "date_from";
            this.date_from.Size = new System.Drawing.Size(208, 20);
            this.date_from.TabIndex = 114;
            this.date_from.Value = new System.DateTime(2017, 9, 18, 20, 0, 8, 0);
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.main);
            this.panel2.Controls.Add(this.view_education);
            this.panel2.Location = new System.Drawing.Point(12, 217);
            this.panel2.Name = "panel2";
            this.panel2.Padding = new System.Windows.Forms.Padding(5);
            this.panel2.Size = new System.Drawing.Size(604, 294);
            this.panel2.TabIndex = 5;
            // 
            // main
            // 
            this.main.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.main.Controls.Add(this.btn_cancel);
            this.main.Controls.Add(this.btn_save);
            this.main.Controls.Add(this.tableLayoutPanel1);
            this.main.Location = new System.Drawing.Point(113, 12);
            this.main.Name = "main";
            this.main.Size = new System.Drawing.Size(408, 270);
            this.main.TabIndex = 7;
            this.main.Visible = false;
            // 
            // btn_cancel
            // 
            this.btn_cancel.BackColor = System.Drawing.Color.Firebrick;
            this.btn_cancel.FlatAppearance.BorderColor = System.Drawing.Color.Blue;
            this.btn_cancel.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_cancel.ForeColor = System.Drawing.Color.White;
            this.btn_cancel.Location = new System.Drawing.Point(231, 235);
            this.btn_cancel.Name = "btn_cancel";
            this.btn_cancel.Size = new System.Drawing.Size(75, 23);
            this.btn_cancel.TabIndex = 9;
            this.btn_cancel.Text = "Cancel";
            this.btn_cancel.UseVisualStyleBackColor = false;
            // 
            // btn_save
            // 
            this.btn_save.BackColor = System.Drawing.Color.Green;
            this.btn_save.FlatAppearance.BorderColor = System.Drawing.Color.Blue;
            this.btn_save.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_save.ForeColor = System.Drawing.Color.White;
            this.btn_save.Location = new System.Drawing.Point(150, 235);
            this.btn_save.Name = "btn_save";
            this.btn_save.Size = new System.Drawing.Size(75, 23);
            this.btn_save.TabIndex = 10;
            this.btn_save.Text = "Save";
            this.btn_save.UseVisualStyleBackColor = false;
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 2;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 41.64306F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 58.35694F));
            this.tableLayoutPanel1.Controls.Add(this.dateTimePicker1, 1, 5);
            this.tableLayoutPanel1.Controls.Add(this.label1, 0, 4);
            this.tableLayoutPanel1.Controls.Add(this.textBox1, 1, 3);
            this.tableLayoutPanel1.Controls.Add(this.label2, 0, 3);
            this.tableLayoutPanel1.Controls.Add(this.label3, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.label4, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.label5, 0, 2);
            this.tableLayoutPanel1.Controls.Add(this.textBox2, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.textBox3, 1, 1);
            this.tableLayoutPanel1.Controls.Add(this.comboBox1, 1, 2);
            this.tableLayoutPanel1.Controls.Add(this.label6, 0, 5);
            this.tableLayoutPanel1.Controls.Add(this.dateTimePicker2, 1, 4);
            this.tableLayoutPanel1.Location = new System.Drawing.Point(30, 17);
            this.tableLayoutPanel1.Margin = new System.Windows.Forms.Padding(1);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 6;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(353, 201);
            this.tableLayoutPanel1.TabIndex = 2;
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dateTimePicker1.Location = new System.Drawing.Point(146, 150);
            this.dateTimePicker1.Margin = new System.Windows.Forms.Padding(0);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(207, 20);
            this.dateTimePicker1.TabIndex = 115;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ImageAlign = System.Drawing.ContentAlignment.TopRight;
            this.label1.ImageIndex = 1;
            this.label1.Location = new System.Drawing.Point(3, 120);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(140, 30);
            this.label1.TabIndex = 112;
            this.label1.Text = "From Date:";
            // 
            // textBox1
            // 
            this.textBox1.Dock = System.Windows.Forms.DockStyle.Top;
            this.textBox1.Location = new System.Drawing.Point(146, 90);
            this.textBox1.Margin = new System.Windows.Forms.Padding(0);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(207, 20);
            this.textBox1.TabIndex = 111;
            this.textBox1.Tag = "required";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label2.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ImageAlign = System.Drawing.ContentAlignment.TopRight;
            this.label2.ImageIndex = 1;
            this.label2.Location = new System.Drawing.Point(3, 90);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(140, 30);
            this.label2.TabIndex = 90;
            this.label2.Text = "Course/Program:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label3.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ImageAlign = System.Drawing.ContentAlignment.TopRight;
            this.label3.ImageIndex = 1;
            this.label3.Location = new System.Drawing.Point(3, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(140, 30);
            this.label3.TabIndex = 51;
            this.label3.Text = "School/University:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label4.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ImageAlign = System.Drawing.ContentAlignment.TopRight;
            this.label4.ImageIndex = 1;
            this.label4.Location = new System.Drawing.Point(3, 30);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(140, 30);
            this.label4.TabIndex = 52;
            this.label4.Text = "Location:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label5.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ImageAlign = System.Drawing.ContentAlignment.TopRight;
            this.label5.ImageIndex = 1;
            this.label5.Location = new System.Drawing.Point(3, 60);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(140, 30);
            this.label5.TabIndex = 83;
            this.label5.Text = "Academic Degree:";
            // 
            // textBox2
            // 
            this.textBox2.Dock = System.Windows.Forms.DockStyle.Top;
            this.textBox2.Location = new System.Drawing.Point(146, 0);
            this.textBox2.Margin = new System.Windows.Forms.Padding(0);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(207, 20);
            this.textBox2.TabIndex = 108;
            this.textBox2.Tag = "required";
            // 
            // textBox3
            // 
            this.textBox3.Dock = System.Windows.Forms.DockStyle.Top;
            this.textBox3.Location = new System.Drawing.Point(146, 30);
            this.textBox3.Margin = new System.Windows.Forms.Padding(0);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(207, 20);
            this.textBox3.TabIndex = 109;
            this.textBox3.Tag = "required";
            // 
            // comboBox1
            // 
            this.comboBox1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.comboBox1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Items.AddRange(new object[] {
            "Diploma",
            "Bachelor",
            "Masteral",
            "Doctorate",
            "Others"});
            this.comboBox1.Location = new System.Drawing.Point(146, 60);
            this.comboBox1.Margin = new System.Windows.Forms.Padding(0);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(207, 21);
            this.comboBox1.TabIndex = 110;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label6.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ImageAlign = System.Drawing.ContentAlignment.TopRight;
            this.label6.ImageIndex = 1;
            this.label6.Location = new System.Drawing.Point(3, 150);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(140, 51);
            this.label6.TabIndex = 113;
            this.label6.Text = "To Date:";
            // 
            // dateTimePicker2
            // 
            this.dateTimePicker2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dateTimePicker2.Location = new System.Drawing.Point(146, 120);
            this.dateTimePicker2.Margin = new System.Windows.Forms.Padding(0);
            this.dateTimePicker2.Name = "dateTimePicker2";
            this.dateTimePicker2.Size = new System.Drawing.Size(207, 20);
            this.dateTimePicker2.TabIndex = 114;
            this.dateTimePicker2.Value = new System.DateTime(2017, 9, 18, 20, 0, 8, 0);
            // 
            // view_education
            // 
            this.view_education.AllowUserToAddRows = false;
            this.view_education.AllowUserToDeleteRows = false;
            this.view_education.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.view_education.BackgroundColor = System.Drawing.Color.White;
            this.view_education.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.view_education.Dock = System.Windows.Forms.DockStyle.Fill;
            this.view_education.Location = new System.Drawing.Point(5, 5);
            this.view_education.Name = "view_education";
            this.view_education.RowHeadersVisible = false;
            this.view_education.Size = new System.Drawing.Size(594, 284);
            this.view_education.TabIndex = 6;
            // 
            // tableLayoutPanel3
            // 
            this.tableLayoutPanel3.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Inset;
            this.tableLayoutPanel3.ColumnCount = 4;
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 27F));
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 265F));
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 50F));
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 35F));
            this.tableLayoutPanel3.Controls.Add(this.checkAll2, 3, 0);
            this.tableLayoutPanel3.Controls.Add(this.linkLabel21, 2, 18);
            this.tableLayoutPanel3.Controls.Add(this.checkBox38, 3, 18);
            this.tableLayoutPanel3.Controls.Add(this.checkBox37, 3, 17);
            this.tableLayoutPanel3.Controls.Add(this.checkBox36, 3, 16);
            this.tableLayoutPanel3.Controls.Add(this.checkBox35, 3, 15);
            this.tableLayoutPanel3.Controls.Add(this.checkBox34, 3, 14);
            this.tableLayoutPanel3.Controls.Add(this.checkBox33, 3, 13);
            this.tableLayoutPanel3.Controls.Add(this.checkBox32, 3, 12);
            this.tableLayoutPanel3.Controls.Add(this.checkBox31, 3, 11);
            this.tableLayoutPanel3.Controls.Add(this.checkBox30, 3, 10);
            this.tableLayoutPanel3.Controls.Add(this.checkBox29, 3, 9);
            this.tableLayoutPanel3.Controls.Add(this.checkBox28, 3, 8);
            this.tableLayoutPanel3.Controls.Add(this.checkBox27, 3, 7);
            this.tableLayoutPanel3.Controls.Add(this.checkBox26, 3, 6);
            this.tableLayoutPanel3.Controls.Add(this.checkBox25, 3, 5);
            this.tableLayoutPanel3.Controls.Add(this.checkBox24, 3, 4);
            this.tableLayoutPanel3.Controls.Add(this.checkBox23, 3, 3);
            this.tableLayoutPanel3.Controls.Add(this.checkBox22, 3, 2);
            this.tableLayoutPanel3.Controls.Add(this.checkBox21, 3, 1);
            this.tableLayoutPanel3.Controls.Add(this.label84, 0, 18);
            this.tableLayoutPanel3.Controls.Add(this.label59, 0, 18);
            this.tableLayoutPanel3.Controls.Add(this.link_locker, 2, 17);
            this.tableLayoutPanel3.Controls.Add(this.link_IdentificationCard, 2, 16);
            this.tableLayoutPanel3.Controls.Add(this.link_acceptablePolicy, 2, 15);
            this.tableLayoutPanel3.Controls.Add(this.linkLabel35, 2, 14);
            this.tableLayoutPanel3.Controls.Add(this.link_consent, 2, 13);
            this.tableLayoutPanel3.Controls.Add(this.link_acceptanceCOC, 2, 12);
            this.tableLayoutPanel3.Controls.Add(this.link_acceptance_COD, 2, 11);
            this.tableLayoutPanel3.Controls.Add(this.link_NSOmarriage, 2, 10);
            this.tableLayoutPanel3.Controls.Add(this.link_NSOdependent, 2, 9);
            this.tableLayoutPanel3.Controls.Add(this.link_cedula, 2, 8);
            this.tableLayoutPanel3.Controls.Add(this.link_OccupationalPermit, 2, 7);
            this.tableLayoutPanel3.Controls.Add(this.link_2316, 2, 6);
            this.tableLayoutPanel3.Controls.Add(this.link_2305, 2, 5);
            this.tableLayoutPanel3.Controls.Add(this.link_1905, 2, 4);
            this.tableLayoutPanel3.Controls.Add(this.link_bankForm, 2, 3);
            this.tableLayoutPanel3.Controls.Add(this.link_HMO, 2, 2);
            this.tableLayoutPanel3.Controls.Add(this.label60, 1, 17);
            this.tableLayoutPanel3.Controls.Add(this.label61, 0, 17);
            this.tableLayoutPanel3.Controls.Add(this.label62, 1, 16);
            this.tableLayoutPanel3.Controls.Add(this.label63, 0, 16);
            this.tableLayoutPanel3.Controls.Add(this.labs, 1, 15);
            this.tableLayoutPanel3.Controls.Add(this.label65, 0, 15);
            this.tableLayoutPanel3.Controls.Add(this.label66, 1, 14);
            this.tableLayoutPanel3.Controls.Add(this.label67, 0, 14);
            this.tableLayoutPanel3.Controls.Add(this.label68, 1, 13);
            this.tableLayoutPanel3.Controls.Add(this.label69, 0, 13);
            this.tableLayoutPanel3.Controls.Add(this.label70, 1, 12);
            this.tableLayoutPanel3.Controls.Add(this.label71, 0, 12);
            this.tableLayoutPanel3.Controls.Add(this.label72, 1, 11);
            this.tableLayoutPanel3.Controls.Add(this.label73, 0, 11);
            this.tableLayoutPanel3.Controls.Add(this.label74, 1, 10);
            this.tableLayoutPanel3.Controls.Add(this.label75, 0, 10);
            this.tableLayoutPanel3.Controls.Add(this.label76, 1, 9);
            this.tableLayoutPanel3.Controls.Add(this.label77, 0, 9);
            this.tableLayoutPanel3.Controls.Add(this.label78, 1, 8);
            this.tableLayoutPanel3.Controls.Add(this.label79, 0, 8);
            this.tableLayoutPanel3.Controls.Add(this.label80, 1, 7);
            this.tableLayoutPanel3.Controls.Add(this.label81, 1, 6);
            this.tableLayoutPanel3.Controls.Add(this.label82, 1, 5);
            this.tableLayoutPanel3.Controls.Add(this.label83, 1, 4);
            this.tableLayoutPanel3.Controls.Add(this.label85, 1, 3);
            this.tableLayoutPanel3.Controls.Add(this.label86, 1, 2);
            this.tableLayoutPanel3.Controls.Add(this.label87, 1, 1);
            this.tableLayoutPanel3.Controls.Add(this.label88, 2, 0);
            this.tableLayoutPanel3.Controls.Add(this.label89, 0, 0);
            this.tableLayoutPanel3.Controls.Add(this.label90, 1, 0);
            this.tableLayoutPanel3.Controls.Add(this.label91, 0, 1);
            this.tableLayoutPanel3.Controls.Add(this.label92, 0, 2);
            this.tableLayoutPanel3.Controls.Add(this.label93, 0, 3);
            this.tableLayoutPanel3.Controls.Add(this.label94, 0, 4);
            this.tableLayoutPanel3.Controls.Add(this.label95, 0, 5);
            this.tableLayoutPanel3.Controls.Add(this.label96, 0, 6);
            this.tableLayoutPanel3.Controls.Add(this.label97, 0, 7);
            this.tableLayoutPanel3.Controls.Add(this.link_payroll, 2, 1);
            this.tableLayoutPanel3.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tableLayoutPanel3.Location = new System.Drawing.Point(1020, 84);
            this.tableLayoutPanel3.Name = "tableLayoutPanel3";
            this.tableLayoutPanel3.RowCount = 19;
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel3.Size = new System.Drawing.Size(372, 423);
            this.tableLayoutPanel3.TabIndex = 85;
            // 
            // checkAll2
            // 
            this.checkAll2.AutoSize = true;
            this.checkAll2.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.checkAll2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.checkAll2.Location = new System.Drawing.Point(353, 5);
            this.checkAll2.Name = "checkAll2";
            this.checkAll2.Size = new System.Drawing.Size(29, 14);
            this.checkAll2.TabIndex = 148;
            this.checkAll2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.checkAll2.UseVisualStyleBackColor = false;
            // 
            // linkLabel21
            // 
            this.linkLabel21.AutoSize = true;
            this.linkLabel21.Dock = System.Windows.Forms.DockStyle.Fill;
            this.linkLabel21.Location = new System.Drawing.Point(301, 398);
            this.linkLabel21.Name = "linkLabel21";
            this.linkLabel21.Size = new System.Drawing.Size(44, 23);
            this.linkLabel21.TabIndex = 147;
            this.linkLabel21.TabStop = true;
            this.linkLabel21.Text = "File";
            this.linkLabel21.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // checkBox38
            // 
            this.checkBox38.AutoSize = true;
            this.checkBox38.Dock = System.Windows.Forms.DockStyle.Fill;
            this.checkBox38.Location = new System.Drawing.Point(353, 401);
            this.checkBox38.Name = "checkBox38";
            this.checkBox38.Size = new System.Drawing.Size(29, 17);
            this.checkBox38.TabIndex = 146;
            this.checkBox38.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.checkBox38.UseVisualStyleBackColor = true;
            // 
            // checkBox37
            // 
            this.checkBox37.AutoSize = true;
            this.checkBox37.Dock = System.Windows.Forms.DockStyle.Fill;
            this.checkBox37.Location = new System.Drawing.Point(353, 379);
            this.checkBox37.Name = "checkBox37";
            this.checkBox37.Size = new System.Drawing.Size(29, 14);
            this.checkBox37.TabIndex = 145;
            this.checkBox37.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.checkBox37.UseVisualStyleBackColor = true;
            // 
            // checkBox36
            // 
            this.checkBox36.AutoSize = true;
            this.checkBox36.Dock = System.Windows.Forms.DockStyle.Fill;
            this.checkBox36.Location = new System.Drawing.Point(353, 357);
            this.checkBox36.Name = "checkBox36";
            this.checkBox36.Size = new System.Drawing.Size(29, 14);
            this.checkBox36.TabIndex = 144;
            this.checkBox36.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.checkBox36.UseVisualStyleBackColor = true;
            // 
            // checkBox35
            // 
            this.checkBox35.AutoSize = true;
            this.checkBox35.Dock = System.Windows.Forms.DockStyle.Fill;
            this.checkBox35.Location = new System.Drawing.Point(353, 335);
            this.checkBox35.Name = "checkBox35";
            this.checkBox35.Size = new System.Drawing.Size(29, 14);
            this.checkBox35.TabIndex = 143;
            this.checkBox35.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.checkBox35.UseVisualStyleBackColor = true;
            // 
            // checkBox34
            // 
            this.checkBox34.AutoSize = true;
            this.checkBox34.Dock = System.Windows.Forms.DockStyle.Fill;
            this.checkBox34.Location = new System.Drawing.Point(353, 313);
            this.checkBox34.Name = "checkBox34";
            this.checkBox34.Size = new System.Drawing.Size(29, 14);
            this.checkBox34.TabIndex = 142;
            this.checkBox34.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.checkBox34.UseVisualStyleBackColor = true;
            // 
            // checkBox33
            // 
            this.checkBox33.AutoSize = true;
            this.checkBox33.Dock = System.Windows.Forms.DockStyle.Fill;
            this.checkBox33.Location = new System.Drawing.Point(353, 291);
            this.checkBox33.Name = "checkBox33";
            this.checkBox33.Size = new System.Drawing.Size(29, 14);
            this.checkBox33.TabIndex = 141;
            this.checkBox33.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.checkBox33.UseVisualStyleBackColor = true;
            // 
            // checkBox32
            // 
            this.checkBox32.AutoSize = true;
            this.checkBox32.Dock = System.Windows.Forms.DockStyle.Fill;
            this.checkBox32.Location = new System.Drawing.Point(353, 269);
            this.checkBox32.Name = "checkBox32";
            this.checkBox32.Size = new System.Drawing.Size(29, 14);
            this.checkBox32.TabIndex = 140;
            this.checkBox32.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.checkBox32.UseVisualStyleBackColor = true;
            // 
            // checkBox31
            // 
            this.checkBox31.AutoSize = true;
            this.checkBox31.Dock = System.Windows.Forms.DockStyle.Fill;
            this.checkBox31.Location = new System.Drawing.Point(353, 247);
            this.checkBox31.Name = "checkBox31";
            this.checkBox31.Size = new System.Drawing.Size(29, 14);
            this.checkBox31.TabIndex = 139;
            this.checkBox31.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.checkBox31.UseVisualStyleBackColor = true;
            // 
            // checkBox30
            // 
            this.checkBox30.AutoSize = true;
            this.checkBox30.Dock = System.Windows.Forms.DockStyle.Fill;
            this.checkBox30.Location = new System.Drawing.Point(353, 225);
            this.checkBox30.Name = "checkBox30";
            this.checkBox30.Size = new System.Drawing.Size(29, 14);
            this.checkBox30.TabIndex = 138;
            this.checkBox30.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.checkBox30.UseVisualStyleBackColor = true;
            // 
            // checkBox29
            // 
            this.checkBox29.AutoSize = true;
            this.checkBox29.Dock = System.Windows.Forms.DockStyle.Fill;
            this.checkBox29.Location = new System.Drawing.Point(353, 203);
            this.checkBox29.Name = "checkBox29";
            this.checkBox29.Size = new System.Drawing.Size(29, 14);
            this.checkBox29.TabIndex = 137;
            this.checkBox29.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.checkBox29.UseVisualStyleBackColor = true;
            // 
            // checkBox28
            // 
            this.checkBox28.AutoSize = true;
            this.checkBox28.Dock = System.Windows.Forms.DockStyle.Fill;
            this.checkBox28.Location = new System.Drawing.Point(353, 181);
            this.checkBox28.Name = "checkBox28";
            this.checkBox28.Size = new System.Drawing.Size(29, 14);
            this.checkBox28.TabIndex = 136;
            this.checkBox28.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.checkBox28.UseVisualStyleBackColor = true;
            // 
            // checkBox27
            // 
            this.checkBox27.AutoSize = true;
            this.checkBox27.Dock = System.Windows.Forms.DockStyle.Fill;
            this.checkBox27.Location = new System.Drawing.Point(353, 159);
            this.checkBox27.Name = "checkBox27";
            this.checkBox27.Size = new System.Drawing.Size(29, 14);
            this.checkBox27.TabIndex = 135;
            this.checkBox27.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.checkBox27.UseVisualStyleBackColor = true;
            // 
            // checkBox26
            // 
            this.checkBox26.AutoSize = true;
            this.checkBox26.Dock = System.Windows.Forms.DockStyle.Fill;
            this.checkBox26.Location = new System.Drawing.Point(353, 137);
            this.checkBox26.Name = "checkBox26";
            this.checkBox26.Size = new System.Drawing.Size(29, 14);
            this.checkBox26.TabIndex = 134;
            this.checkBox26.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.checkBox26.UseVisualStyleBackColor = true;
            // 
            // checkBox25
            // 
            this.checkBox25.AutoSize = true;
            this.checkBox25.Dock = System.Windows.Forms.DockStyle.Fill;
            this.checkBox25.Location = new System.Drawing.Point(353, 115);
            this.checkBox25.Name = "checkBox25";
            this.checkBox25.Size = new System.Drawing.Size(29, 14);
            this.checkBox25.TabIndex = 133;
            this.checkBox25.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.checkBox25.UseVisualStyleBackColor = true;
            // 
            // checkBox24
            // 
            this.checkBox24.AutoSize = true;
            this.checkBox24.Dock = System.Windows.Forms.DockStyle.Fill;
            this.checkBox24.Location = new System.Drawing.Point(353, 93);
            this.checkBox24.Name = "checkBox24";
            this.checkBox24.Size = new System.Drawing.Size(29, 14);
            this.checkBox24.TabIndex = 132;
            this.checkBox24.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.checkBox24.UseVisualStyleBackColor = true;
            // 
            // checkBox23
            // 
            this.checkBox23.AutoSize = true;
            this.checkBox23.Dock = System.Windows.Forms.DockStyle.Fill;
            this.checkBox23.Location = new System.Drawing.Point(353, 71);
            this.checkBox23.Name = "checkBox23";
            this.checkBox23.Size = new System.Drawing.Size(29, 14);
            this.checkBox23.TabIndex = 131;
            this.checkBox23.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.checkBox23.UseVisualStyleBackColor = true;
            // 
            // checkBox22
            // 
            this.checkBox22.AutoSize = true;
            this.checkBox22.Dock = System.Windows.Forms.DockStyle.Fill;
            this.checkBox22.Location = new System.Drawing.Point(353, 49);
            this.checkBox22.Name = "checkBox22";
            this.checkBox22.Size = new System.Drawing.Size(29, 14);
            this.checkBox22.TabIndex = 130;
            this.checkBox22.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.checkBox22.UseVisualStyleBackColor = true;
            // 
            // checkBox21
            // 
            this.checkBox21.AutoSize = true;
            this.checkBox21.Dock = System.Windows.Forms.DockStyle.Fill;
            this.checkBox21.Location = new System.Drawing.Point(353, 27);
            this.checkBox21.Name = "checkBox21";
            this.checkBox21.Size = new System.Drawing.Size(29, 14);
            this.checkBox21.TabIndex = 129;
            this.checkBox21.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.checkBox21.UseVisualStyleBackColor = true;
            // 
            // label84
            // 
            this.label84.AutoSize = true;
            this.label84.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label84.Location = new System.Drawing.Point(5, 398);
            this.label84.Name = "label84";
            this.label84.Size = new System.Drawing.Size(21, 23);
            this.label84.TabIndex = 98;
            this.label84.Text = "18";
            this.label84.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label59
            // 
            this.label59.AutoSize = true;
            this.label59.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label59.Location = new System.Drawing.Point(34, 398);
            this.label59.Name = "label59";
            this.label59.Size = new System.Drawing.Size(259, 23);
            this.label59.TabIndex = 97;
            this.label59.Text = "Data Privacy Consent";
            this.label59.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // link_locker
            // 
            this.link_locker.AutoSize = true;
            this.link_locker.Dock = System.Windows.Forms.DockStyle.Fill;
            this.link_locker.Location = new System.Drawing.Point(301, 376);
            this.link_locker.Name = "link_locker";
            this.link_locker.Size = new System.Drawing.Size(44, 20);
            this.link_locker.TabIndex = 94;
            this.link_locker.TabStop = true;
            this.link_locker.Text = "File";
            this.link_locker.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // link_IdentificationCard
            // 
            this.link_IdentificationCard.AutoSize = true;
            this.link_IdentificationCard.Dock = System.Windows.Forms.DockStyle.Fill;
            this.link_IdentificationCard.Location = new System.Drawing.Point(301, 354);
            this.link_IdentificationCard.Name = "link_IdentificationCard";
            this.link_IdentificationCard.Size = new System.Drawing.Size(44, 20);
            this.link_IdentificationCard.TabIndex = 93;
            this.link_IdentificationCard.TabStop = true;
            this.link_IdentificationCard.Text = "File";
            this.link_IdentificationCard.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // link_acceptablePolicy
            // 
            this.link_acceptablePolicy.AutoSize = true;
            this.link_acceptablePolicy.Dock = System.Windows.Forms.DockStyle.Fill;
            this.link_acceptablePolicy.Location = new System.Drawing.Point(301, 332);
            this.link_acceptablePolicy.Name = "link_acceptablePolicy";
            this.link_acceptablePolicy.Size = new System.Drawing.Size(44, 20);
            this.link_acceptablePolicy.TabIndex = 92;
            this.link_acceptablePolicy.TabStop = true;
            this.link_acceptablePolicy.Text = "File";
            this.link_acceptablePolicy.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // linkLabel35
            // 
            this.linkLabel35.AutoSize = true;
            this.linkLabel35.Dock = System.Windows.Forms.DockStyle.Fill;
            this.linkLabel35.Location = new System.Drawing.Point(301, 310);
            this.linkLabel35.Name = "linkLabel35";
            this.linkLabel35.Size = new System.Drawing.Size(44, 20);
            this.linkLabel35.TabIndex = 91;
            this.linkLabel35.TabStop = true;
            this.linkLabel35.Text = "File";
            this.linkLabel35.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // link_consent
            // 
            this.link_consent.AutoSize = true;
            this.link_consent.Dock = System.Windows.Forms.DockStyle.Fill;
            this.link_consent.Location = new System.Drawing.Point(301, 288);
            this.link_consent.Name = "link_consent";
            this.link_consent.Size = new System.Drawing.Size(44, 20);
            this.link_consent.TabIndex = 90;
            this.link_consent.TabStop = true;
            this.link_consent.Text = "File";
            this.link_consent.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // link_acceptanceCOC
            // 
            this.link_acceptanceCOC.AutoSize = true;
            this.link_acceptanceCOC.Dock = System.Windows.Forms.DockStyle.Fill;
            this.link_acceptanceCOC.Location = new System.Drawing.Point(301, 266);
            this.link_acceptanceCOC.Name = "link_acceptanceCOC";
            this.link_acceptanceCOC.Size = new System.Drawing.Size(44, 20);
            this.link_acceptanceCOC.TabIndex = 89;
            this.link_acceptanceCOC.TabStop = true;
            this.link_acceptanceCOC.Text = "File";
            this.link_acceptanceCOC.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // link_acceptance_COD
            // 
            this.link_acceptance_COD.AutoSize = true;
            this.link_acceptance_COD.Dock = System.Windows.Forms.DockStyle.Fill;
            this.link_acceptance_COD.Location = new System.Drawing.Point(301, 244);
            this.link_acceptance_COD.Name = "link_acceptance_COD";
            this.link_acceptance_COD.Size = new System.Drawing.Size(44, 20);
            this.link_acceptance_COD.TabIndex = 88;
            this.link_acceptance_COD.TabStop = true;
            this.link_acceptance_COD.Text = "File";
            this.link_acceptance_COD.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // link_NSOmarriage
            // 
            this.link_NSOmarriage.AutoSize = true;
            this.link_NSOmarriage.Dock = System.Windows.Forms.DockStyle.Fill;
            this.link_NSOmarriage.Location = new System.Drawing.Point(301, 222);
            this.link_NSOmarriage.Name = "link_NSOmarriage";
            this.link_NSOmarriage.Size = new System.Drawing.Size(44, 20);
            this.link_NSOmarriage.TabIndex = 87;
            this.link_NSOmarriage.TabStop = true;
            this.link_NSOmarriage.Text = "File";
            this.link_NSOmarriage.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // link_NSOdependent
            // 
            this.link_NSOdependent.AutoSize = true;
            this.link_NSOdependent.Dock = System.Windows.Forms.DockStyle.Fill;
            this.link_NSOdependent.Location = new System.Drawing.Point(301, 200);
            this.link_NSOdependent.Name = "link_NSOdependent";
            this.link_NSOdependent.Size = new System.Drawing.Size(44, 20);
            this.link_NSOdependent.TabIndex = 86;
            this.link_NSOdependent.TabStop = true;
            this.link_NSOdependent.Text = "File";
            this.link_NSOdependent.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // link_cedula
            // 
            this.link_cedula.AutoSize = true;
            this.link_cedula.Dock = System.Windows.Forms.DockStyle.Fill;
            this.link_cedula.Location = new System.Drawing.Point(301, 178);
            this.link_cedula.Name = "link_cedula";
            this.link_cedula.Size = new System.Drawing.Size(44, 20);
            this.link_cedula.TabIndex = 85;
            this.link_cedula.TabStop = true;
            this.link_cedula.Text = "File";
            this.link_cedula.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // link_OccupationalPermit
            // 
            this.link_OccupationalPermit.AutoSize = true;
            this.link_OccupationalPermit.Dock = System.Windows.Forms.DockStyle.Fill;
            this.link_OccupationalPermit.Location = new System.Drawing.Point(301, 156);
            this.link_OccupationalPermit.Name = "link_OccupationalPermit";
            this.link_OccupationalPermit.Size = new System.Drawing.Size(44, 20);
            this.link_OccupationalPermit.TabIndex = 84;
            this.link_OccupationalPermit.TabStop = true;
            this.link_OccupationalPermit.Text = "File";
            this.link_OccupationalPermit.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // link_2316
            // 
            this.link_2316.AutoSize = true;
            this.link_2316.Dock = System.Windows.Forms.DockStyle.Fill;
            this.link_2316.Location = new System.Drawing.Point(301, 134);
            this.link_2316.Name = "link_2316";
            this.link_2316.Size = new System.Drawing.Size(44, 20);
            this.link_2316.TabIndex = 83;
            this.link_2316.TabStop = true;
            this.link_2316.Text = "File";
            this.link_2316.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // link_2305
            // 
            this.link_2305.AutoSize = true;
            this.link_2305.Dock = System.Windows.Forms.DockStyle.Fill;
            this.link_2305.Location = new System.Drawing.Point(301, 112);
            this.link_2305.Name = "link_2305";
            this.link_2305.Size = new System.Drawing.Size(44, 20);
            this.link_2305.TabIndex = 82;
            this.link_2305.TabStop = true;
            this.link_2305.Text = "File";
            this.link_2305.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // link_1905
            // 
            this.link_1905.AutoSize = true;
            this.link_1905.Dock = System.Windows.Forms.DockStyle.Fill;
            this.link_1905.Location = new System.Drawing.Point(301, 90);
            this.link_1905.Name = "link_1905";
            this.link_1905.Size = new System.Drawing.Size(44, 20);
            this.link_1905.TabIndex = 81;
            this.link_1905.TabStop = true;
            this.link_1905.Text = "File";
            this.link_1905.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // link_bankForm
            // 
            this.link_bankForm.AutoSize = true;
            this.link_bankForm.Dock = System.Windows.Forms.DockStyle.Fill;
            this.link_bankForm.Location = new System.Drawing.Point(301, 68);
            this.link_bankForm.Name = "link_bankForm";
            this.link_bankForm.Size = new System.Drawing.Size(44, 20);
            this.link_bankForm.TabIndex = 80;
            this.link_bankForm.TabStop = true;
            this.link_bankForm.Text = "File";
            this.link_bankForm.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // link_HMO
            // 
            this.link_HMO.AutoSize = true;
            this.link_HMO.Dock = System.Windows.Forms.DockStyle.Fill;
            this.link_HMO.Location = new System.Drawing.Point(301, 46);
            this.link_HMO.Name = "link_HMO";
            this.link_HMO.Size = new System.Drawing.Size(44, 20);
            this.link_HMO.TabIndex = 79;
            this.link_HMO.TabStop = true;
            this.link_HMO.Text = "File";
            this.link_HMO.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label60
            // 
            this.label60.AutoSize = true;
            this.label60.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label60.Location = new System.Drawing.Point(34, 376);
            this.label60.Name = "label60";
            this.label60.Size = new System.Drawing.Size(259, 20);
            this.label60.TabIndex = 77;
            this.label60.Text = "Locker Accountability && Usage Policy";
            this.label60.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label61
            // 
            this.label61.AutoSize = true;
            this.label61.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label61.Location = new System.Drawing.Point(5, 376);
            this.label61.Name = "label61";
            this.label61.Size = new System.Drawing.Size(21, 20);
            this.label61.TabIndex = 76;
            this.label61.Text = "17";
            this.label61.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label62
            // 
            this.label62.AutoSize = true;
            this.label62.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label62.Location = new System.Drawing.Point(34, 354);
            this.label62.Name = "label62";
            this.label62.Size = new System.Drawing.Size(259, 20);
            this.label62.TabIndex = 75;
            this.label62.Text = "Identification Card && ID Badge";
            this.label62.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label63
            // 
            this.label63.AutoSize = true;
            this.label63.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label63.Location = new System.Drawing.Point(5, 354);
            this.label63.Name = "label63";
            this.label63.Size = new System.Drawing.Size(21, 20);
            this.label63.TabIndex = 74;
            this.label63.Text = "16";
            this.label63.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // labs
            // 
            this.labs.AutoSize = true;
            this.labs.Dock = System.Windows.Forms.DockStyle.Fill;
            this.labs.Location = new System.Drawing.Point(34, 332);
            this.labs.Name = "labs";
            this.labs.Size = new System.Drawing.Size(259, 20);
            this.labs.TabIndex = 73;
            this.labs.Text = "Acceptable Use Policy";
            this.labs.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label65
            // 
            this.label65.AutoSize = true;
            this.label65.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label65.Location = new System.Drawing.Point(5, 332);
            this.label65.Name = "label65";
            this.label65.Size = new System.Drawing.Size(21, 20);
            this.label65.TabIndex = 72;
            this.label65.Text = "15";
            this.label65.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label66
            // 
            this.label66.AutoSize = true;
            this.label66.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label66.Location = new System.Drawing.Point(34, 310);
            this.label66.Name = "label66";
            this.label66.Size = new System.Drawing.Size(259, 20);
            this.label66.TabIndex = 71;
            this.label66.Text = "Consent && Waiver for Call Recording";
            this.label66.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label67
            // 
            this.label67.AutoSize = true;
            this.label67.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label67.Location = new System.Drawing.Point(5, 310);
            this.label67.Name = "label67";
            this.label67.Size = new System.Drawing.Size(21, 20);
            this.label67.TabIndex = 70;
            this.label67.Text = "14";
            this.label67.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label68
            // 
            this.label68.AutoSize = true;
            this.label68.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label68.Location = new System.Drawing.Point(34, 288);
            this.label68.Name = "label68";
            this.label68.Size = new System.Drawing.Size(259, 20);
            this.label68.TabIndex = 69;
            this.label68.Text = "Confidentiality Agreement";
            this.label68.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label69
            // 
            this.label69.AutoSize = true;
            this.label69.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label69.Location = new System.Drawing.Point(5, 288);
            this.label69.Name = "label69";
            this.label69.Size = new System.Drawing.Size(21, 20);
            this.label69.TabIndex = 68;
            this.label69.Text = "13";
            this.label69.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label70
            // 
            this.label70.AutoSize = true;
            this.label70.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label70.Location = new System.Drawing.Point(34, 266);
            this.label70.Name = "label70";
            this.label70.Size = new System.Drawing.Size(259, 20);
            this.label70.TabIndex = 67;
            this.label70.Text = "Acceptance of Code of Conduct";
            this.label70.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label71
            // 
            this.label71.AutoSize = true;
            this.label71.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label71.Location = new System.Drawing.Point(5, 266);
            this.label71.Name = "label71";
            this.label71.Size = new System.Drawing.Size(21, 20);
            this.label71.TabIndex = 66;
            this.label71.Text = "12";
            this.label71.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label72
            // 
            this.label72.AutoSize = true;
            this.label72.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label72.Location = new System.Drawing.Point(34, 244);
            this.label72.Name = "label72";
            this.label72.Size = new System.Drawing.Size(259, 20);
            this.label72.TabIndex = 65;
            this.label72.Text = "Acceptance of Code of Discipline";
            this.label72.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label73
            // 
            this.label73.AutoSize = true;
            this.label73.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label73.Location = new System.Drawing.Point(5, 244);
            this.label73.Name = "label73";
            this.label73.Size = new System.Drawing.Size(21, 20);
            this.label73.TabIndex = 64;
            this.label73.Text = "11";
            this.label73.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label74
            // 
            this.label74.AutoSize = true;
            this.label74.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label74.Location = new System.Drawing.Point(34, 222);
            this.label74.Name = "label74";
            this.label74.Size = new System.Drawing.Size(259, 20);
            this.label74.TabIndex = 63;
            this.label74.Text = "NSO Marriage Certificate (4 copies)";
            this.label74.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label75
            // 
            this.label75.AutoSize = true;
            this.label75.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label75.Location = new System.Drawing.Point(5, 222);
            this.label75.Name = "label75";
            this.label75.Size = new System.Drawing.Size(21, 20);
            this.label75.TabIndex = 62;
            this.label75.Text = "10";
            this.label75.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label76
            // 
            this.label76.AutoSize = true;
            this.label76.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label76.Location = new System.Drawing.Point(34, 200);
            this.label76.Name = "label76";
            this.label76.Size = new System.Drawing.Size(259, 20);
            this.label76.TabIndex = 61;
            this.label76.Text = "NSO Dependent/s\' Birth Certificate (4 copies)";
            this.label76.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label77
            // 
            this.label77.AutoSize = true;
            this.label77.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label77.Location = new System.Drawing.Point(5, 200);
            this.label77.Name = "label77";
            this.label77.Size = new System.Drawing.Size(21, 20);
            this.label77.TabIndex = 60;
            this.label77.Text = "9";
            this.label77.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label78
            // 
            this.label78.AutoSize = true;
            this.label78.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label78.Location = new System.Drawing.Point(34, 178);
            this.label78.Name = "label78";
            this.label78.Size = new System.Drawing.Size(259, 20);
            this.label78.TabIndex = 59;
            this.label78.Text = "Cedula";
            this.label78.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label79
            // 
            this.label79.AutoSize = true;
            this.label79.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label79.Location = new System.Drawing.Point(5, 178);
            this.label79.Name = "label79";
            this.label79.Size = new System.Drawing.Size(21, 20);
            this.label79.TabIndex = 58;
            this.label79.Text = "8";
            this.label79.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label80
            // 
            this.label80.AutoSize = true;
            this.label80.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label80.Location = new System.Drawing.Point(34, 156);
            this.label80.Name = "label80";
            this.label80.Size = new System.Drawing.Size(259, 20);
            this.label80.TabIndex = 57;
            this.label80.Text = "Occupational Permit";
            this.label80.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label81
            // 
            this.label81.AutoSize = true;
            this.label81.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label81.Location = new System.Drawing.Point(34, 134);
            this.label81.Name = "label81";
            this.label81.Size = new System.Drawing.Size(259, 20);
            this.label81.TabIndex = 56;
            this.label81.Text = "BIR 2316 or BIR 2316 with waiver";
            this.label81.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label82
            // 
            this.label82.AutoSize = true;
            this.label82.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label82.Location = new System.Drawing.Point(34, 112);
            this.label82.Name = "label82";
            this.label82.Size = new System.Drawing.Size(259, 20);
            this.label82.TabIndex = 55;
            this.label82.Text = "BIR 2305";
            this.label82.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label83
            // 
            this.label83.AutoSize = true;
            this.label83.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label83.Location = new System.Drawing.Point(34, 90);
            this.label83.Name = "label83";
            this.label83.Size = new System.Drawing.Size(259, 20);
            this.label83.TabIndex = 54;
            this.label83.Text = "BIR 1905";
            this.label83.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label85
            // 
            this.label85.AutoSize = true;
            this.label85.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label85.Location = new System.Drawing.Point(34, 68);
            this.label85.Name = "label85";
            this.label85.Size = new System.Drawing.Size(259, 20);
            this.label85.TabIndex = 53;
            this.label85.Text = "Bank Forms";
            this.label85.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label86
            // 
            this.label86.AutoSize = true;
            this.label86.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label86.Location = new System.Drawing.Point(34, 46);
            this.label86.Name = "label86";
            this.label86.Size = new System.Drawing.Size(259, 20);
            this.label86.TabIndex = 52;
            this.label86.Text = "HMO/AXA Form";
            this.label86.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label87
            // 
            this.label87.AutoSize = true;
            this.label87.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label87.Location = new System.Drawing.Point(34, 24);
            this.label87.Name = "label87";
            this.label87.Size = new System.Drawing.Size(259, 20);
            this.label87.TabIndex = 51;
            this.label87.Text = "Payroll Data Form";
            this.label87.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label88
            // 
            this.label88.AutoSize = true;
            this.label88.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.label88.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label88.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label88.Location = new System.Drawing.Point(298, 2);
            this.label88.Margin = new System.Windows.Forms.Padding(0);
            this.label88.Name = "label88";
            this.label88.Size = new System.Drawing.Size(50, 20);
            this.label88.TabIndex = 2;
            this.label88.Text = "@@";
            this.label88.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label89
            // 
            this.label89.AutoSize = true;
            this.label89.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.label89.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label89.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label89.Location = new System.Drawing.Point(2, 2);
            this.label89.Margin = new System.Windows.Forms.Padding(0);
            this.label89.Name = "label89";
            this.label89.Size = new System.Drawing.Size(27, 20);
            this.label89.TabIndex = 1;
            this.label89.Text = "#";
            this.label89.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label90
            // 
            this.label90.AutoSize = true;
            this.label90.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.label90.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label90.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label90.Location = new System.Drawing.Point(31, 2);
            this.label90.Margin = new System.Windows.Forms.Padding(0);
            this.label90.Name = "label90";
            this.label90.Size = new System.Drawing.Size(265, 20);
            this.label90.TabIndex = 0;
            this.label90.Text = "Secondary Requirements";
            this.label90.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label91
            // 
            this.label91.AutoSize = true;
            this.label91.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label91.Location = new System.Drawing.Point(5, 24);
            this.label91.Name = "label91";
            this.label91.Size = new System.Drawing.Size(21, 20);
            this.label91.TabIndex = 44;
            this.label91.Text = "1";
            this.label91.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label92
            // 
            this.label92.AutoSize = true;
            this.label92.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label92.Location = new System.Drawing.Point(5, 46);
            this.label92.Name = "label92";
            this.label92.Size = new System.Drawing.Size(21, 20);
            this.label92.TabIndex = 45;
            this.label92.Text = "2";
            this.label92.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label93
            // 
            this.label93.AutoSize = true;
            this.label93.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label93.Location = new System.Drawing.Point(5, 68);
            this.label93.Name = "label93";
            this.label93.Size = new System.Drawing.Size(21, 20);
            this.label93.TabIndex = 46;
            this.label93.Text = "3";
            this.label93.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label94
            // 
            this.label94.AutoSize = true;
            this.label94.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label94.Location = new System.Drawing.Point(5, 90);
            this.label94.Name = "label94";
            this.label94.Size = new System.Drawing.Size(21, 20);
            this.label94.TabIndex = 47;
            this.label94.Text = "4";
            this.label94.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label95
            // 
            this.label95.AutoSize = true;
            this.label95.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label95.Location = new System.Drawing.Point(5, 112);
            this.label95.Name = "label95";
            this.label95.Size = new System.Drawing.Size(21, 20);
            this.label95.TabIndex = 48;
            this.label95.Text = "5";
            this.label95.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label96
            // 
            this.label96.AutoSize = true;
            this.label96.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label96.Location = new System.Drawing.Point(5, 134);
            this.label96.Name = "label96";
            this.label96.Size = new System.Drawing.Size(21, 20);
            this.label96.TabIndex = 49;
            this.label96.Text = "6";
            this.label96.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label97
            // 
            this.label97.AutoSize = true;
            this.label97.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label97.Location = new System.Drawing.Point(5, 156);
            this.label97.Name = "label97";
            this.label97.Size = new System.Drawing.Size(21, 20);
            this.label97.TabIndex = 50;
            this.label97.Text = "7";
            this.label97.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // link_payroll
            // 
            this.link_payroll.AutoSize = true;
            this.link_payroll.Dock = System.Windows.Forms.DockStyle.Fill;
            this.link_payroll.Location = new System.Drawing.Point(301, 24);
            this.link_payroll.Name = "link_payroll";
            this.link_payroll.Size = new System.Drawing.Size(44, 20);
            this.link_payroll.TabIndex = 78;
            this.link_payroll.TabStop = true;
            this.link_payroll.Text = "File";
            this.link_payroll.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tableLayoutPanel2
            // 
            this.tableLayoutPanel2.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Inset;
            this.tableLayoutPanel2.ColumnCount = 4;
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 27F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 264F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 51F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 36F));
            this.tableLayoutPanel2.Controls.Add(this.checkAll1, 3, 0);
            this.tableLayoutPanel2.Controls.Add(this.checkBox20, 3, 20);
            this.tableLayoutPanel2.Controls.Add(this.checkBox19, 3, 19);
            this.tableLayoutPanel2.Controls.Add(this.checkBox18, 3, 18);
            this.tableLayoutPanel2.Controls.Add(this.checkBox17, 3, 17);
            this.tableLayoutPanel2.Controls.Add(this.checkBox16, 3, 16);
            this.tableLayoutPanel2.Controls.Add(this.checkBox15, 3, 15);
            this.tableLayoutPanel2.Controls.Add(this.checkBox14, 3, 14);
            this.tableLayoutPanel2.Controls.Add(this.checkBox13, 3, 13);
            this.tableLayoutPanel2.Controls.Add(this.checkBox12, 3, 12);
            this.tableLayoutPanel2.Controls.Add(this.checkBox11, 3, 11);
            this.tableLayoutPanel2.Controls.Add(this.checkBox10, 3, 10);
            this.tableLayoutPanel2.Controls.Add(this.checkBox9, 3, 9);
            this.tableLayoutPanel2.Controls.Add(this.checkBox8, 3, 8);
            this.tableLayoutPanel2.Controls.Add(this.checkBox7, 3, 7);
            this.tableLayoutPanel2.Controls.Add(this.checkBox6, 3, 6);
            this.tableLayoutPanel2.Controls.Add(this.checkBox5, 3, 5);
            this.tableLayoutPanel2.Controls.Add(this.checkBox4, 3, 4);
            this.tableLayoutPanel2.Controls.Add(this.checkBox3, 3, 3);
            this.tableLayoutPanel2.Controls.Add(this.checkBox2, 3, 2);
            this.tableLayoutPanel2.Controls.Add(this.linkLabel20, 2, 20);
            this.tableLayoutPanel2.Controls.Add(this.label10, 0, 20);
            this.tableLayoutPanel2.Controls.Add(this.label21, 1, 3);
            this.tableLayoutPanel2.Controls.Add(this.label22, 1, 4);
            this.tableLayoutPanel2.Controls.Add(this.label23, 1, 5);
            this.tableLayoutPanel2.Controls.Add(this.label24, 1, 6);
            this.tableLayoutPanel2.Controls.Add(this.label25, 1, 7);
            this.tableLayoutPanel2.Controls.Add(this.label27, 1, 8);
            this.tableLayoutPanel2.Controls.Add(this.label29, 1, 9);
            this.tableLayoutPanel2.Controls.Add(this.label31, 1, 10);
            this.tableLayoutPanel2.Controls.Add(this.label33, 1, 11);
            this.tableLayoutPanel2.Controls.Add(this.label35, 1, 12);
            this.tableLayoutPanel2.Controls.Add(this.label37, 1, 13);
            this.tableLayoutPanel2.Controls.Add(this.label39, 1, 14);
            this.tableLayoutPanel2.Controls.Add(this.label41, 1, 15);
            this.tableLayoutPanel2.Controls.Add(this.label43, 1, 16);
            this.tableLayoutPanel2.Controls.Add(this.label45, 1, 17);
            this.tableLayoutPanel2.Controls.Add(this.label47, 1, 18);
            this.tableLayoutPanel2.Controls.Add(this.label49, 1, 19);
            this.tableLayoutPanel2.Controls.Add(this.label51, 1, 20);
            this.tableLayoutPanel2.Controls.Add(this.linkLabel19, 2, 19);
            this.tableLayoutPanel2.Controls.Add(this.linkLabel18, 2, 18);
            this.tableLayoutPanel2.Controls.Add(this.link_informationForm, 2, 17);
            this.tableLayoutPanel2.Controls.Add(this.link_backgroundResult, 2, 16);
            this.tableLayoutPanel2.Controls.Add(this.link_backgroundCheck, 2, 15);
            this.tableLayoutPanel2.Controls.Add(this.link_resume, 2, 14);
            this.tableLayoutPanel2.Controls.Add(this.link_InterviewDocs, 2, 13);
            this.tableLayoutPanel2.Controls.Add(this.link_NDA, 2, 12);
            this.tableLayoutPanel2.Controls.Add(this.link_NewHire, 2, 11);
            this.tableLayoutPanel2.Controls.Add(this.link_SNO, 2, 10);
            this.tableLayoutPanel2.Controls.Add(this.link_TOR, 2, 9);
            this.tableLayoutPanel2.Controls.Add(this.link_COE, 2, 8);
            this.tableLayoutPanel2.Controls.Add(this.link_NBI, 2, 7);
            this.tableLayoutPanel2.Controls.Add(this.lin_IDPicture, 2, 6);
            this.tableLayoutPanel2.Controls.Add(this.link_validID, 2, 5);
            this.tableLayoutPanel2.Controls.Add(this.link_ProofOfPagibig, 2, 4);
            this.tableLayoutPanel2.Controls.Add(this.link_proofOfPhilHealth, 2, 3);
            this.tableLayoutPanel2.Controls.Add(this.link_proofOfSSS, 2, 2);
            this.tableLayoutPanel2.Controls.Add(this.label48, 0, 19);
            this.tableLayoutPanel2.Controls.Add(this.label46, 0, 18);
            this.tableLayoutPanel2.Controls.Add(this.label44, 0, 17);
            this.tableLayoutPanel2.Controls.Add(this.label42, 0, 16);
            this.tableLayoutPanel2.Controls.Add(this.label40, 0, 15);
            this.tableLayoutPanel2.Controls.Add(this.label38, 0, 14);
            this.tableLayoutPanel2.Controls.Add(this.label36, 0, 13);
            this.tableLayoutPanel2.Controls.Add(this.label34, 0, 12);
            this.tableLayoutPanel2.Controls.Add(this.label32, 0, 11);
            this.tableLayoutPanel2.Controls.Add(this.label30, 0, 10);
            this.tableLayoutPanel2.Controls.Add(this.label28, 0, 9);
            this.tableLayoutPanel2.Controls.Add(this.label26, 0, 8);
            this.tableLayoutPanel2.Controls.Add(this.label20, 1, 2);
            this.tableLayoutPanel2.Controls.Add(this.label18, 1, 1);
            this.tableLayoutPanel2.Controls.Add(this.label14, 2, 0);
            this.tableLayoutPanel2.Controls.Add(this.label19, 0, 0);
            this.tableLayoutPanel2.Controls.Add(this.label50, 1, 0);
            this.tableLayoutPanel2.Controls.Add(this.label52, 0, 1);
            this.tableLayoutPanel2.Controls.Add(this.label53, 0, 2);
            this.tableLayoutPanel2.Controls.Add(this.label54, 0, 3);
            this.tableLayoutPanel2.Controls.Add(this.label55, 0, 4);
            this.tableLayoutPanel2.Controls.Add(this.label56, 0, 5);
            this.tableLayoutPanel2.Controls.Add(this.label57, 0, 6);
            this.tableLayoutPanel2.Controls.Add(this.label58, 0, 7);
            this.tableLayoutPanel2.Controls.Add(this.link_proofOftin, 2, 1);
            this.tableLayoutPanel2.Controls.Add(this.checkBox1, 3, 1);
            this.tableLayoutPanel2.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tableLayoutPanel2.Location = new System.Drawing.Point(622, 84);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            this.tableLayoutPanel2.RowCount = 21;
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel2.Size = new System.Drawing.Size(371, 464);
            this.tableLayoutPanel2.TabIndex = 84;
            // 
            // checkAll1
            // 
            this.checkAll1.AutoSize = true;
            this.checkAll1.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.checkAll1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.checkAll1.Location = new System.Drawing.Point(353, 5);
            this.checkAll1.Name = "checkAll1";
            this.checkAll1.Size = new System.Drawing.Size(30, 14);
            this.checkAll1.TabIndex = 148;
            this.checkAll1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.checkAll1.UseVisualStyleBackColor = false;
            // 
            // checkBox20
            // 
            this.checkBox20.AutoSize = true;
            this.checkBox20.Dock = System.Windows.Forms.DockStyle.Fill;
            this.checkBox20.Location = new System.Drawing.Point(353, 445);
            this.checkBox20.Name = "checkBox20";
            this.checkBox20.Size = new System.Drawing.Size(30, 14);
            this.checkBox20.TabIndex = 147;
            this.checkBox20.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.checkBox20.UseVisualStyleBackColor = true;
            // 
            // checkBox19
            // 
            this.checkBox19.AutoSize = true;
            this.checkBox19.Dock = System.Windows.Forms.DockStyle.Fill;
            this.checkBox19.Location = new System.Drawing.Point(353, 423);
            this.checkBox19.Name = "checkBox19";
            this.checkBox19.Size = new System.Drawing.Size(30, 14);
            this.checkBox19.TabIndex = 146;
            this.checkBox19.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.checkBox19.UseVisualStyleBackColor = true;
            // 
            // checkBox18
            // 
            this.checkBox18.AutoSize = true;
            this.checkBox18.Dock = System.Windows.Forms.DockStyle.Fill;
            this.checkBox18.Location = new System.Drawing.Point(353, 401);
            this.checkBox18.Name = "checkBox18";
            this.checkBox18.Size = new System.Drawing.Size(30, 14);
            this.checkBox18.TabIndex = 145;
            this.checkBox18.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.checkBox18.UseVisualStyleBackColor = true;
            // 
            // checkBox17
            // 
            this.checkBox17.AutoSize = true;
            this.checkBox17.Dock = System.Windows.Forms.DockStyle.Fill;
            this.checkBox17.Location = new System.Drawing.Point(353, 379);
            this.checkBox17.Name = "checkBox17";
            this.checkBox17.Size = new System.Drawing.Size(30, 14);
            this.checkBox17.TabIndex = 144;
            this.checkBox17.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.checkBox17.UseVisualStyleBackColor = true;
            // 
            // checkBox16
            // 
            this.checkBox16.AutoSize = true;
            this.checkBox16.Dock = System.Windows.Forms.DockStyle.Fill;
            this.checkBox16.Location = new System.Drawing.Point(353, 357);
            this.checkBox16.Name = "checkBox16";
            this.checkBox16.Size = new System.Drawing.Size(30, 14);
            this.checkBox16.TabIndex = 143;
            this.checkBox16.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.checkBox16.UseVisualStyleBackColor = true;
            // 
            // checkBox15
            // 
            this.checkBox15.AutoSize = true;
            this.checkBox15.Dock = System.Windows.Forms.DockStyle.Fill;
            this.checkBox15.Location = new System.Drawing.Point(353, 335);
            this.checkBox15.Name = "checkBox15";
            this.checkBox15.Size = new System.Drawing.Size(30, 14);
            this.checkBox15.TabIndex = 142;
            this.checkBox15.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.checkBox15.UseVisualStyleBackColor = true;
            // 
            // checkBox14
            // 
            this.checkBox14.AutoSize = true;
            this.checkBox14.Dock = System.Windows.Forms.DockStyle.Fill;
            this.checkBox14.Location = new System.Drawing.Point(353, 313);
            this.checkBox14.Name = "checkBox14";
            this.checkBox14.Size = new System.Drawing.Size(30, 14);
            this.checkBox14.TabIndex = 141;
            this.checkBox14.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.checkBox14.UseVisualStyleBackColor = true;
            // 
            // checkBox13
            // 
            this.checkBox13.AutoSize = true;
            this.checkBox13.Dock = System.Windows.Forms.DockStyle.Fill;
            this.checkBox13.Location = new System.Drawing.Point(353, 291);
            this.checkBox13.Name = "checkBox13";
            this.checkBox13.Size = new System.Drawing.Size(30, 14);
            this.checkBox13.TabIndex = 140;
            this.checkBox13.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.checkBox13.UseVisualStyleBackColor = true;
            // 
            // checkBox12
            // 
            this.checkBox12.AutoSize = true;
            this.checkBox12.Dock = System.Windows.Forms.DockStyle.Fill;
            this.checkBox12.Location = new System.Drawing.Point(353, 269);
            this.checkBox12.Name = "checkBox12";
            this.checkBox12.Size = new System.Drawing.Size(30, 14);
            this.checkBox12.TabIndex = 139;
            this.checkBox12.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.checkBox12.UseVisualStyleBackColor = true;
            // 
            // checkBox11
            // 
            this.checkBox11.AutoSize = true;
            this.checkBox11.Dock = System.Windows.Forms.DockStyle.Fill;
            this.checkBox11.Location = new System.Drawing.Point(353, 247);
            this.checkBox11.Name = "checkBox11";
            this.checkBox11.Size = new System.Drawing.Size(30, 14);
            this.checkBox11.TabIndex = 138;
            this.checkBox11.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.checkBox11.UseVisualStyleBackColor = true;
            // 
            // checkBox10
            // 
            this.checkBox10.AutoSize = true;
            this.checkBox10.Dock = System.Windows.Forms.DockStyle.Fill;
            this.checkBox10.Location = new System.Drawing.Point(353, 225);
            this.checkBox10.Name = "checkBox10";
            this.checkBox10.Size = new System.Drawing.Size(30, 14);
            this.checkBox10.TabIndex = 137;
            this.checkBox10.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.checkBox10.UseVisualStyleBackColor = true;
            // 
            // checkBox9
            // 
            this.checkBox9.AutoSize = true;
            this.checkBox9.Dock = System.Windows.Forms.DockStyle.Fill;
            this.checkBox9.Location = new System.Drawing.Point(353, 203);
            this.checkBox9.Name = "checkBox9";
            this.checkBox9.Size = new System.Drawing.Size(30, 14);
            this.checkBox9.TabIndex = 136;
            this.checkBox9.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.checkBox9.UseVisualStyleBackColor = true;
            // 
            // checkBox8
            // 
            this.checkBox8.AutoSize = true;
            this.checkBox8.Dock = System.Windows.Forms.DockStyle.Fill;
            this.checkBox8.Location = new System.Drawing.Point(353, 181);
            this.checkBox8.Name = "checkBox8";
            this.checkBox8.Size = new System.Drawing.Size(30, 14);
            this.checkBox8.TabIndex = 135;
            this.checkBox8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.checkBox8.UseVisualStyleBackColor = true;
            // 
            // checkBox7
            // 
            this.checkBox7.AutoSize = true;
            this.checkBox7.Dock = System.Windows.Forms.DockStyle.Fill;
            this.checkBox7.Location = new System.Drawing.Point(353, 159);
            this.checkBox7.Name = "checkBox7";
            this.checkBox7.Size = new System.Drawing.Size(30, 14);
            this.checkBox7.TabIndex = 134;
            this.checkBox7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.checkBox7.UseVisualStyleBackColor = true;
            // 
            // checkBox6
            // 
            this.checkBox6.AutoSize = true;
            this.checkBox6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.checkBox6.Location = new System.Drawing.Point(353, 137);
            this.checkBox6.Name = "checkBox6";
            this.checkBox6.Size = new System.Drawing.Size(30, 14);
            this.checkBox6.TabIndex = 133;
            this.checkBox6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.checkBox6.UseVisualStyleBackColor = true;
            // 
            // checkBox5
            // 
            this.checkBox5.AutoSize = true;
            this.checkBox5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.checkBox5.Location = new System.Drawing.Point(353, 115);
            this.checkBox5.Name = "checkBox5";
            this.checkBox5.Size = new System.Drawing.Size(30, 14);
            this.checkBox5.TabIndex = 132;
            this.checkBox5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.checkBox5.UseVisualStyleBackColor = true;
            // 
            // checkBox4
            // 
            this.checkBox4.AutoSize = true;
            this.checkBox4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.checkBox4.Location = new System.Drawing.Point(353, 93);
            this.checkBox4.Name = "checkBox4";
            this.checkBox4.Size = new System.Drawing.Size(30, 14);
            this.checkBox4.TabIndex = 131;
            this.checkBox4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.checkBox4.UseVisualStyleBackColor = true;
            // 
            // checkBox3
            // 
            this.checkBox3.AutoSize = true;
            this.checkBox3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.checkBox3.Location = new System.Drawing.Point(353, 71);
            this.checkBox3.Name = "checkBox3";
            this.checkBox3.Size = new System.Drawing.Size(30, 14);
            this.checkBox3.TabIndex = 130;
            this.checkBox3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.checkBox3.UseVisualStyleBackColor = true;
            // 
            // checkBox2
            // 
            this.checkBox2.AutoSize = true;
            this.checkBox2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.checkBox2.Location = new System.Drawing.Point(353, 49);
            this.checkBox2.Name = "checkBox2";
            this.checkBox2.Size = new System.Drawing.Size(30, 14);
            this.checkBox2.TabIndex = 129;
            this.checkBox2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.checkBox2.UseVisualStyleBackColor = true;
            // 
            // linkLabel20
            // 
            this.linkLabel20.AutoSize = true;
            this.linkLabel20.Dock = System.Windows.Forms.DockStyle.Fill;
            this.linkLabel20.Location = new System.Drawing.Point(300, 442);
            this.linkLabel20.Name = "linkLabel20";
            this.linkLabel20.Size = new System.Drawing.Size(45, 20);
            this.linkLabel20.TabIndex = 126;
            this.linkLabel20.TabStop = true;
            this.linkLabel20.Text = "File";
            this.linkLabel20.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label10.Location = new System.Drawing.Point(5, 442);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(21, 20);
            this.label10.TabIndex = 125;
            this.label10.Text = "20";
            this.label10.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label21.Location = new System.Drawing.Point(34, 68);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(258, 20);
            this.label21.TabIndex = 124;
            this.label21.Text = "Proof of PhilHealth/PMRF";
            this.label21.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label22.Location = new System.Drawing.Point(34, 90);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(258, 20);
            this.label22.TabIndex = 123;
            this.label22.Text = "Proof of Pag-Ibig";
            this.label22.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label23.Location = new System.Drawing.Point(34, 112);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(258, 20);
            this.label23.TabIndex = 122;
            this.label23.Text = "2 Valid ID\'s";
            this.label23.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label24.Location = new System.Drawing.Point(34, 134);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(258, 20);
            this.label24.TabIndex = 121;
            this.label24.Text = "ID Pictures (6 pieces 1 x 1 with nameplate)";
            this.label24.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label25.Location = new System.Drawing.Point(34, 156);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(258, 20);
            this.label25.TabIndex = 120;
            this.label25.Text = "NBI Clearance (Receipt is not acceptable)";
            this.label25.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label27.Location = new System.Drawing.Point(34, 178);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(258, 20);
            this.label27.TabIndex = 119;
            this.label27.Text = "COE (Proof of Employment)";
            this.label27.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label29.Location = new System.Drawing.Point(34, 200);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(258, 20);
            this.label29.TabIndex = 118;
            this.label29.Text = "TOR/Diploma (School Records)";
            this.label29.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label31.Location = new System.Drawing.Point(34, 222);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(258, 20);
            this.label31.TabIndex = 117;
            this.label31.Text = "NSO Birth Certificate (4 copies)";
            this.label31.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label33.Location = new System.Drawing.Point(34, 244);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(258, 20);
            this.label33.TabIndex = 116;
            this.label33.Text = "New Hire Acknowledgement";
            this.label33.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label35.Location = new System.Drawing.Point(34, 266);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(258, 20);
            this.label35.TabIndex = 115;
            this.label35.Text = "NDA";
            this.label35.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label37.Location = new System.Drawing.Point(34, 288);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(258, 20);
            this.label37.TabIndex = 114;
            this.label37.Text = "Interview/Assesment Docs";
            this.label37.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label39.Location = new System.Drawing.Point(34, 310);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(258, 20);
            this.label39.TabIndex = 113;
            this.label39.Text = "Resume/CV";
            this.label39.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label41.Location = new System.Drawing.Point(34, 332);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(258, 20);
            this.label41.TabIndex = 112;
            this.label41.Text = "Background Investigation Check Form";
            this.label41.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label43
            // 
            this.label43.AutoSize = true;
            this.label43.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label43.Location = new System.Drawing.Point(34, 354);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(258, 20);
            this.label43.TabIndex = 111;
            this.label43.Text = "Background Investigation Result";
            this.label43.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label45
            // 
            this.label45.AutoSize = true;
            this.label45.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label45.Location = new System.Drawing.Point(34, 376);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(258, 20);
            this.label45.TabIndex = 110;
            this.label45.Text = "Employee Information Form";
            this.label45.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label47
            // 
            this.label47.AutoSize = true;
            this.label47.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label47.Location = new System.Drawing.Point(34, 398);
            this.label47.Name = "label47";
            this.label47.Size = new System.Drawing.Size(258, 20);
            this.label47.TabIndex = 108;
            this.label47.Text = "Job Description";
            this.label47.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label49
            // 
            this.label49.AutoSize = true;
            this.label49.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label49.Location = new System.Drawing.Point(34, 420);
            this.label49.Name = "label49";
            this.label49.Size = new System.Drawing.Size(258, 20);
            this.label49.TabIndex = 107;
            this.label49.Text = "Employee Contract";
            this.label49.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label51
            // 
            this.label51.AutoSize = true;
            this.label51.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label51.Location = new System.Drawing.Point(34, 442);
            this.label51.Name = "label51";
            this.label51.Size = new System.Drawing.Size(258, 20);
            this.label51.TabIndex = 106;
            this.label51.Text = "PEME Slip";
            this.label51.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // linkLabel19
            // 
            this.linkLabel19.AutoSize = true;
            this.linkLabel19.Dock = System.Windows.Forms.DockStyle.Fill;
            this.linkLabel19.Location = new System.Drawing.Point(300, 420);
            this.linkLabel19.Name = "linkLabel19";
            this.linkLabel19.Size = new System.Drawing.Size(45, 20);
            this.linkLabel19.TabIndex = 100;
            this.linkLabel19.TabStop = true;
            this.linkLabel19.Text = "File";
            this.linkLabel19.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // linkLabel18
            // 
            this.linkLabel18.AutoSize = true;
            this.linkLabel18.Dock = System.Windows.Forms.DockStyle.Fill;
            this.linkLabel18.Location = new System.Drawing.Point(300, 398);
            this.linkLabel18.Name = "linkLabel18";
            this.linkLabel18.Size = new System.Drawing.Size(45, 20);
            this.linkLabel18.TabIndex = 99;
            this.linkLabel18.TabStop = true;
            this.linkLabel18.Text = "File";
            this.linkLabel18.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // link_informationForm
            // 
            this.link_informationForm.AutoSize = true;
            this.link_informationForm.Dock = System.Windows.Forms.DockStyle.Fill;
            this.link_informationForm.Location = new System.Drawing.Point(300, 376);
            this.link_informationForm.Name = "link_informationForm";
            this.link_informationForm.Size = new System.Drawing.Size(45, 20);
            this.link_informationForm.TabIndex = 98;
            this.link_informationForm.TabStop = true;
            this.link_informationForm.Text = "File";
            this.link_informationForm.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // link_backgroundResult
            // 
            this.link_backgroundResult.AutoSize = true;
            this.link_backgroundResult.Dock = System.Windows.Forms.DockStyle.Fill;
            this.link_backgroundResult.Location = new System.Drawing.Point(300, 354);
            this.link_backgroundResult.Name = "link_backgroundResult";
            this.link_backgroundResult.Size = new System.Drawing.Size(45, 20);
            this.link_backgroundResult.TabIndex = 97;
            this.link_backgroundResult.TabStop = true;
            this.link_backgroundResult.Text = "File";
            this.link_backgroundResult.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // link_backgroundCheck
            // 
            this.link_backgroundCheck.AutoSize = true;
            this.link_backgroundCheck.Dock = System.Windows.Forms.DockStyle.Fill;
            this.link_backgroundCheck.Location = new System.Drawing.Point(300, 332);
            this.link_backgroundCheck.Name = "link_backgroundCheck";
            this.link_backgroundCheck.Size = new System.Drawing.Size(45, 20);
            this.link_backgroundCheck.TabIndex = 96;
            this.link_backgroundCheck.TabStop = true;
            this.link_backgroundCheck.Text = "File";
            this.link_backgroundCheck.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // link_resume
            // 
            this.link_resume.AutoSize = true;
            this.link_resume.Dock = System.Windows.Forms.DockStyle.Fill;
            this.link_resume.Location = new System.Drawing.Point(300, 310);
            this.link_resume.Name = "link_resume";
            this.link_resume.Size = new System.Drawing.Size(45, 20);
            this.link_resume.TabIndex = 95;
            this.link_resume.TabStop = true;
            this.link_resume.Text = "File";
            this.link_resume.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // link_InterviewDocs
            // 
            this.link_InterviewDocs.AutoSize = true;
            this.link_InterviewDocs.Dock = System.Windows.Forms.DockStyle.Fill;
            this.link_InterviewDocs.Location = new System.Drawing.Point(300, 288);
            this.link_InterviewDocs.Name = "link_InterviewDocs";
            this.link_InterviewDocs.Size = new System.Drawing.Size(45, 20);
            this.link_InterviewDocs.TabIndex = 94;
            this.link_InterviewDocs.TabStop = true;
            this.link_InterviewDocs.Text = "File";
            this.link_InterviewDocs.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // link_NDA
            // 
            this.link_NDA.AutoSize = true;
            this.link_NDA.Dock = System.Windows.Forms.DockStyle.Fill;
            this.link_NDA.Location = new System.Drawing.Point(300, 266);
            this.link_NDA.Name = "link_NDA";
            this.link_NDA.Size = new System.Drawing.Size(45, 20);
            this.link_NDA.TabIndex = 93;
            this.link_NDA.TabStop = true;
            this.link_NDA.Text = "File";
            this.link_NDA.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // link_NewHire
            // 
            this.link_NewHire.AutoSize = true;
            this.link_NewHire.Dock = System.Windows.Forms.DockStyle.Fill;
            this.link_NewHire.Location = new System.Drawing.Point(300, 244);
            this.link_NewHire.Name = "link_NewHire";
            this.link_NewHire.Size = new System.Drawing.Size(45, 20);
            this.link_NewHire.TabIndex = 92;
            this.link_NewHire.TabStop = true;
            this.link_NewHire.Text = "File";
            this.link_NewHire.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // link_SNO
            // 
            this.link_SNO.AutoSize = true;
            this.link_SNO.Dock = System.Windows.Forms.DockStyle.Fill;
            this.link_SNO.Location = new System.Drawing.Point(300, 222);
            this.link_SNO.Name = "link_SNO";
            this.link_SNO.Size = new System.Drawing.Size(45, 20);
            this.link_SNO.TabIndex = 91;
            this.link_SNO.TabStop = true;
            this.link_SNO.Text = "File";
            this.link_SNO.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // link_TOR
            // 
            this.link_TOR.AutoSize = true;
            this.link_TOR.Dock = System.Windows.Forms.DockStyle.Fill;
            this.link_TOR.Location = new System.Drawing.Point(300, 200);
            this.link_TOR.Name = "link_TOR";
            this.link_TOR.Size = new System.Drawing.Size(45, 20);
            this.link_TOR.TabIndex = 90;
            this.link_TOR.TabStop = true;
            this.link_TOR.Text = "File";
            this.link_TOR.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // link_COE
            // 
            this.link_COE.AutoSize = true;
            this.link_COE.Dock = System.Windows.Forms.DockStyle.Fill;
            this.link_COE.Location = new System.Drawing.Point(300, 178);
            this.link_COE.Name = "link_COE";
            this.link_COE.Size = new System.Drawing.Size(45, 20);
            this.link_COE.TabIndex = 89;
            this.link_COE.TabStop = true;
            this.link_COE.Text = "File";
            this.link_COE.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // link_NBI
            // 
            this.link_NBI.AutoSize = true;
            this.link_NBI.Dock = System.Windows.Forms.DockStyle.Fill;
            this.link_NBI.Location = new System.Drawing.Point(300, 156);
            this.link_NBI.Name = "link_NBI";
            this.link_NBI.Size = new System.Drawing.Size(45, 20);
            this.link_NBI.TabIndex = 88;
            this.link_NBI.TabStop = true;
            this.link_NBI.Text = "File";
            this.link_NBI.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lin_IDPicture
            // 
            this.lin_IDPicture.AutoSize = true;
            this.lin_IDPicture.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lin_IDPicture.Location = new System.Drawing.Point(300, 134);
            this.lin_IDPicture.Name = "lin_IDPicture";
            this.lin_IDPicture.Size = new System.Drawing.Size(45, 20);
            this.lin_IDPicture.TabIndex = 87;
            this.lin_IDPicture.TabStop = true;
            this.lin_IDPicture.Text = "File";
            this.lin_IDPicture.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // link_validID
            // 
            this.link_validID.AutoSize = true;
            this.link_validID.Dock = System.Windows.Forms.DockStyle.Fill;
            this.link_validID.Location = new System.Drawing.Point(300, 112);
            this.link_validID.Name = "link_validID";
            this.link_validID.Size = new System.Drawing.Size(45, 20);
            this.link_validID.TabIndex = 86;
            this.link_validID.TabStop = true;
            this.link_validID.Text = "File";
            this.link_validID.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // link_ProofOfPagibig
            // 
            this.link_ProofOfPagibig.AutoSize = true;
            this.link_ProofOfPagibig.Dock = System.Windows.Forms.DockStyle.Fill;
            this.link_ProofOfPagibig.Location = new System.Drawing.Point(300, 90);
            this.link_ProofOfPagibig.Name = "link_ProofOfPagibig";
            this.link_ProofOfPagibig.Size = new System.Drawing.Size(45, 20);
            this.link_ProofOfPagibig.TabIndex = 85;
            this.link_ProofOfPagibig.TabStop = true;
            this.link_ProofOfPagibig.Text = "File";
            this.link_ProofOfPagibig.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // link_proofOfPhilHealth
            // 
            this.link_proofOfPhilHealth.AutoSize = true;
            this.link_proofOfPhilHealth.Dock = System.Windows.Forms.DockStyle.Fill;
            this.link_proofOfPhilHealth.Location = new System.Drawing.Point(300, 68);
            this.link_proofOfPhilHealth.Name = "link_proofOfPhilHealth";
            this.link_proofOfPhilHealth.Size = new System.Drawing.Size(45, 20);
            this.link_proofOfPhilHealth.TabIndex = 84;
            this.link_proofOfPhilHealth.TabStop = true;
            this.link_proofOfPhilHealth.Text = "File";
            this.link_proofOfPhilHealth.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // link_proofOfSSS
            // 
            this.link_proofOfSSS.AutoSize = true;
            this.link_proofOfSSS.Dock = System.Windows.Forms.DockStyle.Fill;
            this.link_proofOfSSS.Location = new System.Drawing.Point(300, 46);
            this.link_proofOfSSS.Name = "link_proofOfSSS";
            this.link_proofOfSSS.Size = new System.Drawing.Size(45, 20);
            this.link_proofOfSSS.TabIndex = 83;
            this.link_proofOfSSS.TabStop = true;
            this.link_proofOfSSS.Text = "File";
            this.link_proofOfSSS.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label48
            // 
            this.label48.AutoSize = true;
            this.label48.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label48.Location = new System.Drawing.Point(5, 420);
            this.label48.Name = "label48";
            this.label48.Size = new System.Drawing.Size(21, 20);
            this.label48.TabIndex = 80;
            this.label48.Text = "19";
            this.label48.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label46
            // 
            this.label46.AutoSize = true;
            this.label46.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label46.Location = new System.Drawing.Point(5, 398);
            this.label46.Name = "label46";
            this.label46.Size = new System.Drawing.Size(21, 20);
            this.label46.TabIndex = 78;
            this.label46.Text = "18";
            this.label46.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.label44.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label44.Location = new System.Drawing.Point(5, 376);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(21, 20);
            this.label44.TabIndex = 76;
            this.label44.Text = "17";
            this.label44.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label42
            // 
            this.label42.AutoSize = true;
            this.label42.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label42.Location = new System.Drawing.Point(5, 354);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(21, 20);
            this.label42.TabIndex = 74;
            this.label42.Text = "16";
            this.label42.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label40.Location = new System.Drawing.Point(5, 332);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(21, 20);
            this.label40.TabIndex = 72;
            this.label40.Text = "15";
            this.label40.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label38.Location = new System.Drawing.Point(5, 310);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(21, 20);
            this.label38.TabIndex = 70;
            this.label38.Text = "14";
            this.label38.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label36.Location = new System.Drawing.Point(5, 288);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(21, 20);
            this.label36.TabIndex = 68;
            this.label36.Text = "13";
            this.label36.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label34.Location = new System.Drawing.Point(5, 266);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(21, 20);
            this.label34.TabIndex = 66;
            this.label34.Text = "12";
            this.label34.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label32.Location = new System.Drawing.Point(5, 244);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(21, 20);
            this.label32.TabIndex = 64;
            this.label32.Text = "11";
            this.label32.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label30.Location = new System.Drawing.Point(5, 222);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(21, 20);
            this.label30.TabIndex = 62;
            this.label30.Text = "10";
            this.label30.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label28.Location = new System.Drawing.Point(5, 200);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(21, 20);
            this.label28.TabIndex = 60;
            this.label28.Text = "9";
            this.label28.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label26.Location = new System.Drawing.Point(5, 178);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(21, 20);
            this.label26.TabIndex = 58;
            this.label26.Text = "8";
            this.label26.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label20.Location = new System.Drawing.Point(34, 46);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(258, 20);
            this.label20.TabIndex = 52;
            this.label20.Text = "Proof of SSS";
            this.label20.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label18.Location = new System.Drawing.Point(34, 24);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(258, 20);
            this.label18.TabIndex = 51;
            this.label18.Text = "Proof of TIN/BIR 1902";
            this.label18.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.label14.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label14.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(297, 2);
            this.label14.Margin = new System.Windows.Forms.Padding(0);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(51, 20);
            this.label14.TabIndex = 2;
            this.label14.Text = "@@";
            this.label14.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.label19.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label19.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.Location = new System.Drawing.Point(2, 2);
            this.label19.Margin = new System.Windows.Forms.Padding(0);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(27, 20);
            this.label19.TabIndex = 1;
            this.label19.Text = "#";
            this.label19.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label50
            // 
            this.label50.AutoSize = true;
            this.label50.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.label50.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label50.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label50.Location = new System.Drawing.Point(31, 2);
            this.label50.Margin = new System.Windows.Forms.Padding(0);
            this.label50.Name = "label50";
            this.label50.Size = new System.Drawing.Size(264, 20);
            this.label50.TabIndex = 0;
            this.label50.Text = "Primary Requirements";
            this.label50.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label52
            // 
            this.label52.AutoSize = true;
            this.label52.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label52.Location = new System.Drawing.Point(5, 24);
            this.label52.Name = "label52";
            this.label52.Size = new System.Drawing.Size(21, 20);
            this.label52.TabIndex = 44;
            this.label52.Text = "1";
            this.label52.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label53
            // 
            this.label53.AutoSize = true;
            this.label53.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label53.Location = new System.Drawing.Point(5, 46);
            this.label53.Name = "label53";
            this.label53.Size = new System.Drawing.Size(21, 20);
            this.label53.TabIndex = 45;
            this.label53.Text = "2";
            this.label53.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label54
            // 
            this.label54.AutoSize = true;
            this.label54.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label54.Location = new System.Drawing.Point(5, 68);
            this.label54.Name = "label54";
            this.label54.Size = new System.Drawing.Size(21, 20);
            this.label54.TabIndex = 46;
            this.label54.Text = "3";
            this.label54.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label55
            // 
            this.label55.AutoSize = true;
            this.label55.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label55.Location = new System.Drawing.Point(5, 90);
            this.label55.Name = "label55";
            this.label55.Size = new System.Drawing.Size(21, 20);
            this.label55.TabIndex = 47;
            this.label55.Text = "4";
            this.label55.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label56
            // 
            this.label56.AutoSize = true;
            this.label56.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label56.Location = new System.Drawing.Point(5, 112);
            this.label56.Name = "label56";
            this.label56.Size = new System.Drawing.Size(21, 20);
            this.label56.TabIndex = 48;
            this.label56.Text = "5";
            this.label56.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label57
            // 
            this.label57.AutoSize = true;
            this.label57.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label57.Location = new System.Drawing.Point(5, 134);
            this.label57.Name = "label57";
            this.label57.Size = new System.Drawing.Size(21, 20);
            this.label57.TabIndex = 49;
            this.label57.Text = "6";
            this.label57.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label58
            // 
            this.label58.AutoSize = true;
            this.label58.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label58.Location = new System.Drawing.Point(5, 156);
            this.label58.Name = "label58";
            this.label58.Size = new System.Drawing.Size(21, 20);
            this.label58.TabIndex = 50;
            this.label58.Text = "7";
            this.label58.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // link_proofOftin
            // 
            this.link_proofOftin.AutoSize = true;
            this.link_proofOftin.Dock = System.Windows.Forms.DockStyle.Fill;
            this.link_proofOftin.Location = new System.Drawing.Point(300, 24);
            this.link_proofOftin.Name = "link_proofOftin";
            this.link_proofOftin.Size = new System.Drawing.Size(45, 20);
            this.link_proofOftin.TabIndex = 82;
            this.link_proofOftin.TabStop = true;
            this.link_proofOftin.Text = "File";
            this.link_proofOftin.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // checkBox1
            // 
            this.checkBox1.AutoSize = true;
            this.checkBox1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.checkBox1.Location = new System.Drawing.Point(353, 27);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Size = new System.Drawing.Size(30, 14);
            this.checkBox1.TabIndex = 128;
            this.checkBox1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.checkBox1.UseVisualStyleBackColor = true;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1194, 479);
            this.Controls.Add(this.tableLayoutPanel3);
            this.Controls.Add(this.tableLayoutPanel2);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.tableLayoutPanel6);
            this.Name = "Form1";
            this.Text = "Form1";
            this.tableLayoutPanel6.ResumeLayout(false);
            this.tableLayoutPanel6.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.main.ResumeLayout(false);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.view_education)).EndInit();
            this.tableLayoutPanel3.ResumeLayout(false);
            this.tableLayoutPanel3.PerformLayout();
            this.tableLayoutPanel2.ResumeLayout(false);
            this.tableLayoutPanel2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel6;
        private System.Windows.Forms.DateTimePicker date_to;
        private System.Windows.Forms.Label lbl_fromdate;
        private System.Windows.Forms.TextBox tbx_course;
        private System.Windows.Forms.Label lbl_course;
        private System.Windows.Forms.Label lbl_school;
        private System.Windows.Forms.Label lbl_location;
        private System.Windows.Forms.Label lbl_degree;
        private System.Windows.Forms.TextBox tbx_school;
        private System.Windows.Forms.TextBox tbx_location;
        private System.Windows.Forms.ComboBox cbx_degree;
        private System.Windows.Forms.Label lbl_todate;
        private System.Windows.Forms.DateTimePicker date_from;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel main;
        private System.Windows.Forms.Button btn_cancel;
        private System.Windows.Forms.Button btn_save;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.DateTimePicker dateTimePicker2;
        private System.Windows.Forms.DataGridView view_education;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel3;
        private System.Windows.Forms.CheckBox checkAll2;
        private System.Windows.Forms.LinkLabel linkLabel21;
        private System.Windows.Forms.CheckBox checkBox38;
        private System.Windows.Forms.CheckBox checkBox37;
        private System.Windows.Forms.CheckBox checkBox36;
        private System.Windows.Forms.CheckBox checkBox35;
        private System.Windows.Forms.CheckBox checkBox34;
        private System.Windows.Forms.CheckBox checkBox33;
        private System.Windows.Forms.CheckBox checkBox32;
        private System.Windows.Forms.CheckBox checkBox31;
        private System.Windows.Forms.CheckBox checkBox30;
        private System.Windows.Forms.CheckBox checkBox29;
        private System.Windows.Forms.CheckBox checkBox28;
        private System.Windows.Forms.CheckBox checkBox27;
        private System.Windows.Forms.CheckBox checkBox26;
        private System.Windows.Forms.CheckBox checkBox25;
        private System.Windows.Forms.CheckBox checkBox24;
        private System.Windows.Forms.CheckBox checkBox23;
        private System.Windows.Forms.CheckBox checkBox22;
        private System.Windows.Forms.CheckBox checkBox21;
        private System.Windows.Forms.Label label84;
        private System.Windows.Forms.Label label59;
        private System.Windows.Forms.LinkLabel link_locker;
        private System.Windows.Forms.LinkLabel link_IdentificationCard;
        private System.Windows.Forms.LinkLabel link_acceptablePolicy;
        private System.Windows.Forms.LinkLabel linkLabel35;
        private System.Windows.Forms.LinkLabel link_consent;
        private System.Windows.Forms.LinkLabel link_acceptanceCOC;
        private System.Windows.Forms.LinkLabel link_acceptance_COD;
        private System.Windows.Forms.LinkLabel link_NSOmarriage;
        private System.Windows.Forms.LinkLabel link_NSOdependent;
        private System.Windows.Forms.LinkLabel link_cedula;
        private System.Windows.Forms.LinkLabel link_OccupationalPermit;
        private System.Windows.Forms.LinkLabel link_2316;
        private System.Windows.Forms.LinkLabel link_2305;
        private System.Windows.Forms.LinkLabel link_1905;
        private System.Windows.Forms.LinkLabel link_bankForm;
        private System.Windows.Forms.LinkLabel link_HMO;
        private System.Windows.Forms.Label label60;
        private System.Windows.Forms.Label label61;
        private System.Windows.Forms.Label label62;
        private System.Windows.Forms.Label label63;
        private System.Windows.Forms.Label labs;
        private System.Windows.Forms.Label label65;
        private System.Windows.Forms.Label label66;
        private System.Windows.Forms.Label label67;
        private System.Windows.Forms.Label label68;
        private System.Windows.Forms.Label label69;
        private System.Windows.Forms.Label label70;
        private System.Windows.Forms.Label label71;
        private System.Windows.Forms.Label label72;
        private System.Windows.Forms.Label label73;
        private System.Windows.Forms.Label label74;
        private System.Windows.Forms.Label label75;
        private System.Windows.Forms.Label label76;
        private System.Windows.Forms.Label label77;
        private System.Windows.Forms.Label label78;
        private System.Windows.Forms.Label label79;
        private System.Windows.Forms.Label label80;
        private System.Windows.Forms.Label label81;
        private System.Windows.Forms.Label label82;
        private System.Windows.Forms.Label label83;
        private System.Windows.Forms.Label label85;
        private System.Windows.Forms.Label label86;
        private System.Windows.Forms.Label label87;
        private System.Windows.Forms.Label label88;
        private System.Windows.Forms.Label label89;
        private System.Windows.Forms.Label label90;
        private System.Windows.Forms.Label label91;
        private System.Windows.Forms.Label label92;
        private System.Windows.Forms.Label label93;
        private System.Windows.Forms.Label label94;
        private System.Windows.Forms.Label label95;
        private System.Windows.Forms.Label label96;
        private System.Windows.Forms.Label label97;
        private System.Windows.Forms.LinkLabel link_payroll;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel2;
        private System.Windows.Forms.CheckBox checkAll1;
        private System.Windows.Forms.CheckBox checkBox20;
        private System.Windows.Forms.CheckBox checkBox19;
        private System.Windows.Forms.CheckBox checkBox18;
        private System.Windows.Forms.CheckBox checkBox17;
        private System.Windows.Forms.CheckBox checkBox16;
        private System.Windows.Forms.CheckBox checkBox15;
        private System.Windows.Forms.CheckBox checkBox14;
        private System.Windows.Forms.CheckBox checkBox13;
        private System.Windows.Forms.CheckBox checkBox12;
        private System.Windows.Forms.CheckBox checkBox11;
        private System.Windows.Forms.CheckBox checkBox10;
        private System.Windows.Forms.CheckBox checkBox9;
        private System.Windows.Forms.CheckBox checkBox8;
        private System.Windows.Forms.CheckBox checkBox7;
        private System.Windows.Forms.CheckBox checkBox6;
        private System.Windows.Forms.CheckBox checkBox5;
        private System.Windows.Forms.CheckBox checkBox4;
        private System.Windows.Forms.CheckBox checkBox3;
        private System.Windows.Forms.CheckBox checkBox2;
        private System.Windows.Forms.LinkLabel linkLabel20;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.Label label45;
        private System.Windows.Forms.Label label47;
        private System.Windows.Forms.Label label49;
        private System.Windows.Forms.Label label51;
        private System.Windows.Forms.LinkLabel linkLabel19;
        private System.Windows.Forms.LinkLabel linkLabel18;
        private System.Windows.Forms.LinkLabel link_informationForm;
        private System.Windows.Forms.LinkLabel link_backgroundResult;
        private System.Windows.Forms.LinkLabel link_backgroundCheck;
        private System.Windows.Forms.LinkLabel link_resume;
        private System.Windows.Forms.LinkLabel link_InterviewDocs;
        private System.Windows.Forms.LinkLabel link_NDA;
        private System.Windows.Forms.LinkLabel link_NewHire;
        private System.Windows.Forms.LinkLabel link_SNO;
        private System.Windows.Forms.LinkLabel link_TOR;
        private System.Windows.Forms.LinkLabel link_COE;
        private System.Windows.Forms.LinkLabel link_NBI;
        private System.Windows.Forms.LinkLabel lin_IDPicture;
        private System.Windows.Forms.LinkLabel link_validID;
        private System.Windows.Forms.LinkLabel link_ProofOfPagibig;
        private System.Windows.Forms.LinkLabel link_proofOfPhilHealth;
        private System.Windows.Forms.LinkLabel link_proofOfSSS;
        private System.Windows.Forms.Label label48;
        private System.Windows.Forms.Label label46;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label50;
        private System.Windows.Forms.Label label52;
        private System.Windows.Forms.Label label53;
        private System.Windows.Forms.Label label54;
        private System.Windows.Forms.Label label55;
        private System.Windows.Forms.Label label56;
        private System.Windows.Forms.Label label57;
        private System.Windows.Forms.Label label58;
        private System.Windows.Forms.LinkLabel link_proofOftin;
        private System.Windows.Forms.CheckBox checkBox1;
    }
}